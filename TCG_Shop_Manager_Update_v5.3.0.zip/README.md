# TCG Shop Manager v5.3.0 — Commercial RC

상용 배포 전 고객 경험을 정리한 Commercial Release Candidate입니다.

- 공식 업데이트 서버 기본 연결: https://raw.githubusercontent.com/b61181463-eng/tcg-shop-manager-updates/main/manifest.json
- 신규 매장 빠른 시작 가이드
- 설치 ID 원클릭 복사
- 평가판 종료 후 라이선스 등록/데이터 내보내기 동선 개선
- 제품 정보/로컬 데이터 소유 정책 표시
- v5.2.1 Fast Update + Ed25519 업데이트 서명 + 자동 롤백 유지
- 고객용 EXE 바이트 연속성 유지

정식 일반 고객 배포는 향후 Microsoft Store/MSIX 경로를 별도 검증합니다.
