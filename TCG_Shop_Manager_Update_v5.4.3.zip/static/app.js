function openModal(id){ document.getElementById(id)?.classList.add('open'); }
function closeModal(m){ m?.classList.remove('open'); }
document.querySelectorAll('[data-open]').forEach(b=>b.addEventListener('click',()=>openModal(b.dataset.open)));
document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>closeModal(b.closest('.modal'))));
document.querySelectorAll('.modal').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)closeModal(m)}));
document.addEventListener('keydown',e=>{if(e.key==='Escape')document.querySelectorAll('.modal.open').forEach(closeModal)});
function money(n){ return Math.round(Number(n||0)).toLocaleString('ko-KR')+'원'; }

document.querySelectorAll('[data-copy-target]').forEach(btn=>btn.addEventListener('click',async()=>{
  const el=document.getElementById(btn.dataset.copyTarget);
  if(!el)return;
  const text=(el.textContent||'').trim();
  try{
    await navigator.clipboard.writeText(text);
    const before=btn.textContent;
    btn.textContent='복사됨';
    setTimeout(()=>btn.textContent=before,1200);
  }catch(e){
    window.prompt('아래 내용을 복사해주세요.',text);
  }
}));
