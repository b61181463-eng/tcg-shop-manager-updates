# TCG Shop Manager v5.4.0 — Visual Identity RC

v5.3의 기능/데이터 구조를 유지하면서 Card Vault / Collector Terminal 컨셉으로 UI를 재설계한 후속 RC입니다.
