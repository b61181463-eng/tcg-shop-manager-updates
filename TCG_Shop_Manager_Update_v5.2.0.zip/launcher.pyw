from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import socket
import subprocess
import sys
import time
import urllib.request
import webbrowser
from datetime import datetime
from pathlib import Path

BASE = Path(__file__).resolve().parent
REQ = BASE / "requirements.txt"
MANIFEST = BASE / "MANIFEST.json"
HOST = "127.0.0.1"
PORT_FIRST = 8765
PORT_LAST = 8795
EXPECTED_VERSION = "5.2.0"
APP_ID = "tcg-shop-manager"


def get_data_dir() -> Path:
    if os.name == "nt":
        root = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "TCGShopManager"
    else:
        root = Path.home() / ".local" / "share" / "tcg-shop-manager"
    (root / "logs").mkdir(parents=True, exist_ok=True)
    (root / "runtime").mkdir(parents=True, exist_ok=True)
    return root


def log_path() -> Path:
    return get_data_dir() / "logs" / "launcher.log"


def write_log(text: str) -> None:
    try:
        with log_path().open("a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().isoformat(timespec='seconds')}] {text}\n")
    except Exception:
        pass


def message(title: str, text: str, error: bool = False) -> None:
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        (messagebox.showerror if error else messagebox.showinfo)(title, text, parent=root)
        root.destroy()
    except Exception:
        pass


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def validate_installation() -> bool:
    required = [BASE / "app.py", REQ, BASE / "templates", BASE / "static", MANIFEST, BASE / "VERSION"]
    missing = [p.name for p in required if not p.exists()]
    if missing:
        text = (
            "프로그램 파일 일부를 찾을 수 없습니다.\n\n"
            "ZIP 안에서 직접 실행하지 말고 '모두 압축 풀기' 후 실행해주세요.\n\n"
            f"누락: {', '.join(missing)}"
        )
        write_log("Installation validation failed: " + ", ".join(missing))
        message("TCG Shop Manager", text, True)
        return False

    try:
        manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
        if manifest.get("version") != EXPECTED_VERSION:
            raise ValueError(f"manifest version={manifest.get('version')!r}")
        version_text = (BASE / "VERSION").read_text(encoding="utf-8").strip()
        if version_text != EXPECTED_VERSION:
            raise ValueError(f"VERSION file={version_text!r}")
        bad = []
        for rel, expected in manifest.get("files", {}).items():
            path = BASE / rel
            if not path.is_file() or sha256_file(path) != expected:
                bad.append(rel)
        if bad:
            raise ValueError("hash mismatch: " + ", ".join(bad[:8]))
    except Exception as exc:
        write_log(f"Package consistency check failed: {exc!r}")
        message(
            "TCG Shop Manager 업데이트 오류",
            "서로 다른 버전의 프로그램 파일이 한 폴더에 섞여 있습니다.\n\n"
            "기존 폴더에 일부 파일만 덮어쓰지 말고, 새 ZIP을 별도 폴더에 완전히 압축 해제한 뒤 실행해주세요.\n"
            "매장 데이터는 별도 저장되므로 새 폴더를 사용해도 그대로 유지됩니다.\n\n"
            f"상세: {exc}\n로그: {log_path()}",
            True,
        )
        return False
    return True


def ensure_deps() -> bool:
    needed = ["fastapi", "uvicorn", "jinja2", "multipart", "itsdangerous", "cryptography"]
    if all(importlib.util.find_spec(x) for x in needed):
        return True
    try:
        message("TCG Shop Manager", "처음 실행에 필요한 구성 요소를 설치합니다.\n잠시 기다려주세요.")
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-r", str(REQ)],
            cwd=str(BASE), capture_output=True, text=True, creationflags=flags,
        )
        write_log(f"pip exit={result.returncode}\nstdout={result.stdout[-4000:]}\nstderr={result.stderr[-4000:]}")
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "pip 설치 실패")
        return all(importlib.util.find_spec(x) for x in needed)
    except Exception as exc:
        write_log(f"Dependency installation failed: {exc!r}")
        message("TCG Shop Manager 실행 실패", f"필수 구성 요소 설치에 실패했습니다.\n\n{exc}\n\n로그: {log_path()}", True)
        return False


def launcher_log_tail(max_chars: int = 3000) -> str:
    try:
        return log_path().read_text(encoding="utf-8", errors="replace")[-max_chars:]
    except Exception:
        return ""


def url_for(port: int, path: str = "") -> str:
    return f"http://{HOST}:{port}{path}"


def health_info(port: int, timeout: float = 0.35) -> dict | None:
    try:
        with urllib.request.urlopen(url_for(port, "/health"), timeout=timeout) as r:
            if r.status != 200:
                return None
            data = json.loads(r.read().decode("utf-8"))
            return data if isinstance(data, dict) else None
    except Exception:
        return None


def is_tcg_server(info: dict | None) -> bool:
    if not info or not info.get("ok"):
        return False
    if info.get("app_id") == APP_ID:
        return True
    # Compatibility with v1.0-v1.2, whose /health did not expose app_id.
    db_path = str(info.get("db", "")).replace("/", "\\").lower()
    return "tcgshopmanager" in db_path and bool(info.get("version"))


def port_is_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind((HOST, port))
            return True
        except OSError:
            return False



def listener_pid_for_port_windows(port: int) -> int | None:
    """Return the PID listening on a confirmed local port on Windows."""
    if os.name != "nt":
        return None
    try:
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        result = subprocess.run(
            ["netstat", "-ano", "-p", "tcp"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="ignore",
            creationflags=flags,
            timeout=6,
        )
        needle = f":{port}"
        for raw in result.stdout.splitlines():
            line = raw.strip()
            if not line or needle not in line:
                continue
            parts = line.split()
            if len(parts) < 5:
                continue
            local = parts[1]
            if not local.endswith(needle):
                continue
            try:
                return int(parts[-1])
            except ValueError:
                continue
    except Exception as exc:
        write_log(f"netstat PID lookup failed for port {port}: {exc!r}")
    return None


def stop_confirmed_tcg_server(port: int, info: dict) -> bool:
    """Stop only a server whose /health response was already confirmed as this app."""
    pid = None
    try:
        if info.get("pid"):
            pid = int(info["pid"])
    except Exception:
        pid = None
    if pid is None:
        pid = listener_pid_for_port_windows(port)
    if not pid or pid == os.getpid():
        write_log(f"Could not resolve safe PID for old TCG server on port {port}")
        return False

    try:
        if os.name == "nt":
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            result = subprocess.run(
                ["taskkill", "/PID", str(pid), "/T", "/F"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="ignore",
                creationflags=flags,
                timeout=8,
            )
            write_log(
                f"Stopping old TCG server port={port} pid={pid} version={info.get('version')} "
                f"taskkill_rc={result.returncode} stdout={result.stdout[-500:]} stderr={result.stderr[-500:]}"
            )
            if result.returncode != 0:
                return False
        else:
            import signal
            os.kill(pid, signal.SIGTERM)

        deadline = time.time() + 5
        while time.time() < deadline:
            if port_is_free(port):
                return True
            time.sleep(0.15)
        return port_is_free(port)
    except Exception as exc:
        write_log(f"Failed to stop old TCG server on port {port}, pid={pid}: {exc!r}")
        return False


def cleanup_older_tcg_servers() -> list[tuple[int, str, bool]]:
    results = []
    for port in range(PORT_FIRST, PORT_LAST + 1):
        info = health_info(port)
        if not is_tcg_server(info):
            continue
        version = str(info.get("version", "?"))
        if version == EXPECTED_VERSION:
            continue
        ok = stop_confirmed_tcg_server(port, info)
        results.append((port, version, ok))
    return results


def find_existing_current() -> int | None:
    for port in range(PORT_FIRST, PORT_LAST + 1):
        info = health_info(port)
        if is_tcg_server(info) and str(info.get("version")) == EXPECTED_VERSION:
            return port
    return None


def find_free_port() -> int | None:
    for port in range(PORT_FIRST, PORT_LAST + 1):
        if port_is_free(port):
            return port
    return None


def start_server(port: int) -> subprocess.Popen:
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    flags |= getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env["TCG_SHOP_OPEN_BROWSER"] = "0"
    env["TCG_SHOP_PORT"] = str(port)
    log = log_path().open("ab", buffering=0)
    write_log(f"Starting v{EXPECTED_VERSION} server with Python={sys.executable}, base={BASE}, port={port}")
    proc = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "app:app", "--host", HOST, "--port", str(port), "--log-level", "info"],
        cwd=str(BASE), env=env, stdout=log, stderr=subprocess.STDOUT, creationflags=flags,
    )
    log.close()
    return proc


def wait_for_server(proc: subprocess.Popen, port: int, seconds: float = 25.0) -> bool:
    deadline = time.time() + seconds
    while time.time() < deadline:
        info = health_info(port, timeout=0.8)
        if is_tcg_server(info) and str(info.get("version")) == EXPECTED_VERSION:
            return True
        if proc.poll() is not None:
            write_log(f"Server exited early with code {proc.returncode}")
            return False
        time.sleep(0.25)
    write_log("Server startup timeout")
    return False


def save_runtime(port: int, pid: int) -> None:
    try:
        payload = {
            "app_id": APP_ID,
            "version": EXPECTED_VERSION,
            "port": port,
            "pid": pid,
            "base": str(BASE),
            "started_at": datetime.now().isoformat(timespec="seconds"),
        }
        (get_data_dir() / "runtime" / "server.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as exc:
        write_log(f"Runtime metadata write failed: {exc!r}")


def main() -> None:
    write_log(f"Launcher v{EXPECTED_VERSION} invoked from {BASE}")
    if not validate_installation() or not ensure_deps():
        return

    existing = find_existing_current()
    if existing is not None:
        write_log(f"Existing matching v{EXPECTED_VERSION} server detected on port {existing}")
        webbrowser.open(url_for(existing))
        return

    cleanup_results = cleanup_older_tcg_servers()
    if cleanup_results:
        write_log("Old server cleanup results: " + ", ".join(
            f"{p}=v{v}:{'stopped' if ok else 'still-running'}" for p, v, ok in cleanup_results
        ))

    port = find_free_port()
    if port is None:
        message("TCG Shop Manager 실행 실패", f"사용 가능한 로컬 포트를 찾지 못했습니다 ({PORT_FIRST}-{PORT_LAST}).\n로그: {log_path()}", True)
        return

    try:
        proc = start_server(port)
        if wait_for_server(proc, port):
            save_runtime(port, proc.pid)
            write_log(f"Server v{EXPECTED_VERSION} health PASS on port {port}; opening browser")
            webbrowser.open(url_for(port))
            return
        try:
            if proc.poll() is None:
                proc.terminate()
        except Exception:
            pass
        tail = launcher_log_tail()
        detail = (
            "프로그램 서버가 정상적으로 시작되지 않았습니다.\n\n"
            "새 ZIP을 별도 폴더에 완전히 압축 해제했는지 확인해주세요.\n\n"
            f"로그 위치:\n{log_path()}"
        )
        if tail:
            detail += "\n\n최근 오류:\n" + tail[-1600:]
        message("TCG Shop Manager 실행 실패", detail, True)
    except Exception as exc:
        write_log(f"Unhandled launcher error: {exc!r}")
        message("TCG Shop Manager 실행 실패", f"{exc}\n\n로그 위치:\n{log_path()}", True)


if __name__ == "__main__":
    main()
