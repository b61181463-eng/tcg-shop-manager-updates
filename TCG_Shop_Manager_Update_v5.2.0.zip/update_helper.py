from __future__ import annotations
import argparse
import hashlib
import json
import os
import shutil
import signal
import sqlite3
import subprocess
import tempfile
import time
import urllib.request
import webbrowser
import zipfile
from datetime import datetime
from pathlib import Path

APP_ID = "tcg-shop-manager"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_status(path: Path, state: str, message: str, old_version: str, target_version: str, extra: dict | None = None) -> None:
    payload = {"state": state, "message": message, "old_version": old_version, "target_version": target_version, "updated_at": datetime.now().isoformat(timespec="seconds")}
    if extra:
        payload.update(extra)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def stop_pid(pid: int) -> None:
    if not pid or pid == os.getpid():
        return
    try:
        if os.name == "nt":
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, creationflags=flags, timeout=12)
        else:
            os.kill(pid, signal.SIGTERM)
    except Exception:
        pass


def port_free(port: int) -> bool:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def wait_port_free(port: int, seconds: float = 12.0) -> bool:
    end = time.time() + seconds
    while time.time() < end:
        if port_free(port):
            return True
        time.sleep(.2)
    return port_free(port)


def health(port: int) -> dict | None:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=.7) as r:
            data = json.loads(r.read().decode("utf-8"))
            return data if isinstance(data, dict) else None
    except Exception:
        return None


def wait_health(proc: subprocess.Popen, port: int, version: str, seconds: float = 35.0) -> bool:
    end = time.time() + seconds
    while time.time() < end:
        info = health(port)
        if info and info.get("ok") and info.get("app_id") == APP_ID and str(info.get("version")) == version:
            return True
        if proc.poll() is not None:
            return False
        time.sleep(.3)
    return False


def extract_and_validate(package: Path, target_version: str, expected_sha: str, staging_parent: Path) -> tuple[Path, Path]:
    if sha256_file(package).lower() != expected_sha.lower():
        raise ValueError("package sha256 mismatch")
    staging = Path(tempfile.mkdtemp(prefix=".tcg_update_stage_", dir=str(staging_parent)))
    try:
        with zipfile.ZipFile(package, "r") as z:
            bad = z.testzip()
            if bad:
                raise ValueError(f"zip damaged: {bad}")
            for name in z.namelist():
                p = Path(name)
                if p.is_absolute() or ".." in p.parts:
                    raise ValueError("unsafe zip path")
            z.extractall(staging)
        if (staging / "app.py").exists():
            roots = [staging]
        else:
            roots = [p for p in staging.iterdir() if p.is_dir() and (p / "app.py").exists()]
        if len(roots) != 1:
            raise ValueError("program root not unique")
        root = roots[0]
        version = (root / "VERSION").read_text(encoding="utf-8").strip()
        if version != target_version:
            raise ValueError(f"target version mismatch: {version}")
        manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
        if manifest.get("version") != target_version:
            raise ValueError("manifest version mismatch")
        files = manifest.get("files", {})
        if not isinstance(files, dict) or not files:
            raise ValueError("manifest files missing")
        bad_files = []
        for rel, expected in files.items():
            p = root / rel
            if not p.is_file() or sha256_file(p) != expected:
                bad_files.append(rel)
            if len(bad_files) >= 8:
                break
        if bad_files:
            raise ValueError("manifest hash mismatch: " + ", ".join(bad_files))
        return staging, root
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise


def ensure_dependencies(python_exe: str, root: Path) -> None:
    if os.environ.get("TCG_UPDATE_SKIP_PIP") == "1":
        return
    req = root / "requirements.txt"
    if not req.exists():
        return
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    result = subprocess.run([python_exe, "-m", "pip", "install", "--disable-pip-version-check", "-r", str(req)], cwd=str(root), capture_output=True, text=True, creationflags=flags, timeout=240)
    if result.returncode != 0:
        raise RuntimeError("dependency install failed: " + (result.stderr[-1500:] or result.stdout[-1500:]))


def start_server(python_exe: str, base: Path, data_dir: Path, port: int) -> subprocess.Popen:
    env = os.environ.copy()
    env["TCG_SHOP_DATA_DIR"] = str(data_dir)
    env["TCG_SHOP_PORT"] = str(port)
    env["TCG_SHOP_OPEN_BROWSER"] = "0"
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    log_dir = data_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log = (log_dir / "update_server.log").open("ab", buffering=0)
    proc = subprocess.Popen([python_exe, "-m", "uvicorn", "app:app", "--host", "127.0.0.1", "--port", str(port), "--log-level", "info"], cwd=str(base), env=env, stdout=log, stderr=subprocess.STDOUT, creationflags=flags)
    log.close()
    return proc


def restore_data_backup(backup: Path, data_dir: Path) -> None:
    if not backup.exists():
        raise FileNotFoundError(backup)
    tmp = Path(tempfile.mkdtemp(prefix="tcg_update_data_restore_"))
    try:
        with zipfile.ZipFile(backup, "r") as z:
            names = set(z.namelist())
            if "shop.db" not in names:
                raise ValueError("pre-update backup missing shop.db")
            z.extract("shop.db", tmp)
            image_names = [n for n in names if n.startswith("product_images/") and not n.endswith("/")]
            img_dir = tmp / "product_images"
            img_dir.mkdir(exist_ok=True)
            for n in image_names:
                leaf = Path(n).name
                if leaf:
                    (img_dir / leaf).write_bytes(z.read(n))
        db_path = tmp / "shop.db"
        conn = sqlite3.connect(db_path)
        try:
            check = conn.execute("PRAGMA integrity_check").fetchone()
            if not check or str(check[0]).lower() != "ok":
                raise ValueError("backup db integrity failed")
        finally:
            conn.close()
        live = data_dir / "shop.db"
        for extra in [Path(str(live) + "-wal"), Path(str(live) + "-shm")]:
            try:
                extra.unlink()
            except OSError:
                pass
        replacement = data_dir / "shop.rollback.tmp"
        shutil.copy2(db_path, replacement)
        os.replace(replacement, live)
        product_dir = data_dir / "product_images"
        product_dir.mkdir(parents=True, exist_ok=True)
        if image_names:
            for old in product_dir.iterdir():
                if old.is_file():
                    try:
                        old.unlink()
                    except OSError:
                        pass
            for p in img_dir.iterdir():
                if p.is_file():
                    shutil.copy2(p, product_dir / p.name)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main() -> int:
    ap = argparse.ArgumentParser()
    for name in ["base", "package", "target-version", "expected-sha256", "data-dir", "backup", "status", "python"]:
        ap.add_argument("--" + name, required=True)
    ap.add_argument("--port", required=True, type=int)
    ap.add_argument("--old-pid", required=True, type=int)
    a = ap.parse_args()
    base = Path(a.base).resolve()
    package = Path(a.package).resolve()
    data_dir = Path(a.data_dir).resolve()
    backup = Path(a.backup).resolve()
    status = Path(a.status).resolve()
    target = a.target_version
    old_version = (base / "VERSION").read_text(encoding="utf-8").strip() if (base / "VERSION").exists() else "unknown"
    staging = root = rollback = None
    new_proc = None
    swapped = False
    try:
        write_status(status, "preflight", f"v{target} 패키지를 최종 검증하고 있습니다.", old_version, target)
        staging, root = extract_and_validate(package, target, a.expected_sha256, base.parent)
        ensure_dependencies(a.python, root)
        write_status(status, "stopping", f"v{old_version}을 종료하고 업데이트를 적용합니다.", old_version, target)
        time.sleep(1.2)
        stop_pid(a.old_pid)
        wait_port_free(a.port, 15)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        rollback = base.parent / f".{base.name}.rollback_{stamp}"
        if rollback.exists():
            shutil.rmtree(rollback, ignore_errors=True)
        os.replace(base, rollback)
        os.replace(root, base)
        swapped = True
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
        staging = root = None
        write_status(status, "verifying", f"v{target}을 실행해 정상 기동을 확인하고 있습니다.", old_version, target)
        new_proc = start_server(a.python, base, data_dir, a.port)
        if not wait_health(new_proc, a.port, target, 40):
            raise RuntimeError("new version health check failed")
        write_status(status, "success", f"v{target} 업데이트가 완료되었습니다.", old_version, target, {"port": a.port})
        if rollback.exists():
            shutil.rmtree(rollback, ignore_errors=True)
        try:
            webbrowser.open(f"http://127.0.0.1:{a.port}/update-center")
        except Exception:
            pass
        return 0
    except Exception as exc:
        reason = str(exc)
        try:
            if new_proc and new_proc.poll() is None:
                stop_pid(new_proc.pid)
                wait_port_free(a.port, 8)
            if swapped:
                failed = base.parent / f".{base.name}.failed_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                if base.exists():
                    try:
                        os.replace(base, failed)
                    except Exception:
                        shutil.rmtree(base, ignore_errors=True)
                if rollback and rollback.exists():
                    os.replace(rollback, base)
                restore_data_backup(backup, data_dir)
                old_proc = start_server(a.python, base, data_dir, a.port)
                rollback_ok = wait_health(old_proc, a.port, old_version, 35)
                if rollback_ok:
                    if failed.exists():
                        shutil.rmtree(failed, ignore_errors=True)
                    write_status(status, "rolled_back", f"새 버전 확인에 실패해 v{old_version}과 업데이트 직전 데이터로 자동 복구했습니다. 원인: {reason}", old_version, target, {"port": a.port})
                    try:
                        webbrowser.open(f"http://127.0.0.1:{a.port}/update-center")
                    except Exception:
                        pass
                else:
                    write_status(status, "rollback_failed", f"업데이트 실패 후 자동 복구 서버 확인도 실패했습니다. 데이터 백업은 보존되어 있습니다. 원인: {reason}", old_version, target)
            else:
                if port_free(a.port) and base.exists():
                    old_proc = start_server(a.python, base, data_dir, a.port)
                    wait_health(old_proc, a.port, old_version, 25)
                write_status(status, "error", f"프로그램 파일을 교체하기 전에 업데이트가 중단되었습니다. 기존 버전은 유지됩니다. 원인: {reason}", old_version, target)
        except Exception as rollback_exc:
            write_status(status, "rollback_failed", f"업데이트/복구 처리 중 오류: {reason}; 복구 오류: {rollback_exc}", old_version, target)
        finally:
            if staging and staging.exists():
                shutil.rmtree(staging, ignore_errors=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
