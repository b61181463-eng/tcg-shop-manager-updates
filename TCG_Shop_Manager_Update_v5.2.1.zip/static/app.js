function openModal(id){ document.getElementById(id)?.classList.add('open'); }
function closeModal(m){ m?.classList.remove('open'); }
document.querySelectorAll('[data-open]').forEach(b=>b.addEventListener('click',()=>openModal(b.dataset.open)));
document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>closeModal(b.closest('.modal'))));
document.querySelectorAll('.modal').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)closeModal(m)}));
document.addEventListener('keydown',e=>{if(e.key==='Escape')document.querySelectorAll('.modal.open').forEach(closeModal)});
function money(n){ return Math.round(Number(n||0)).toLocaleString('ko-KR')+'원'; }
