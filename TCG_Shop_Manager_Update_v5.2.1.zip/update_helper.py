from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import shutil
import signal
import sqlite3
import subprocess
import tempfile
import time
import urllib.request
import webbrowser
import zipfile
from datetime import datetime
from pathlib import Path

APP_ID = "tcg-shop-manager"
START_MONO = time.monotonic()

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def write_status(path: Path, state: str, message: str, old_version: str, target_version: str, progress: int = 0, phase: str = "", extra: dict | None = None) -> None:
    payload = {
        "state": state, "message": message, "old_version": old_version,
        "target_version": target_version, "progress": max(0,min(100,int(progress))),
        "phase": phase or state, "elapsed_seconds": round(time.monotonic()-START_MONO,1),
        "updated_at": datetime.now().isoformat(timespec="seconds"),
    }
    if extra: payload.update(extra)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp,path)

def stop_pid(pid: int) -> None:
    """Stop only the requested process. Never use taskkill /T on Windows."""
    if not pid or pid == os.getpid(): return
    try:
        if os.name == "nt":
            flags = getattr(subprocess,"CREATE_NO_WINDOW",0)
            subprocess.run(["taskkill","/PID",str(pid),"/F"], capture_output=True, creationflags=flags, timeout=12)
        else:
            os.kill(pid, signal.SIGTERM)
    except Exception:
        pass

def port_free(port: int) -> bool:
    """Return True when no process is accepting connections on the app port."""
    import socket
    with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as s:
        s.settimeout(.25)
        return s.connect_ex(("127.0.0.1",port)) != 0

def wait_port_free(port: int, seconds: float=12.0) -> bool:
    end=time.time()+seconds
    while time.time()<end:
        if port_free(port): return True
        time.sleep(.2)
    return port_free(port)

def health(port:int) -> dict|None:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/health",timeout=.7) as r:
            data=json.loads(r.read().decode("utf-8")); return data if isinstance(data,dict) else None
    except Exception: return None

def wait_health(proc: subprocess.Popen, port:int, version:str, seconds:float=35.0) -> bool:
    end=time.time()+seconds
    while time.time()<end:
        info=health(port)
        if info and info.get("ok") and info.get("app_id")==APP_ID and str(info.get("version"))==version: return True
        if proc.poll() is not None: return False
        time.sleep(.3)
    return False

def extract_and_validate(package:Path,target_version:str,expected_sha:str,staging_parent:Path)->tuple[Path,Path]:
    if sha256_file(package).lower()!=expected_sha.lower(): raise ValueError("package sha256 mismatch")
    staging=Path(tempfile.mkdtemp(prefix=".tcg_update_stage_",dir=str(staging_parent)))
    try:
        with zipfile.ZipFile(package,"r") as z:
            bad=z.testzip()
            if bad: raise ValueError(f"zip damaged: {bad}")
            for name in z.namelist():
                p=Path(name)
                if p.is_absolute() or ".." in p.parts: raise ValueError("unsafe zip path")
            z.extractall(staging)
        roots=[staging] if (staging/"app.py").exists() else [p for p in staging.iterdir() if p.is_dir() and (p/"app.py").exists()]
        if len(roots)!=1: raise ValueError("program root not unique")
        root=roots[0]
        version=(root/"VERSION").read_text(encoding="utf-8").strip()
        if version!=target_version: raise ValueError(f"target version mismatch: {version}")
        manifest=json.loads((root/"MANIFEST.json").read_text(encoding="utf-8"))
        if manifest.get("version")!=target_version: raise ValueError("manifest version mismatch")
        files=manifest.get("files",{})
        if not isinstance(files,dict) or not files: raise ValueError("manifest files missing")
        bad_files=[]
        for rel,expected in files.items():
            p=root/rel
            if not p.is_file() or sha256_file(p)!=expected: bad_files.append(rel)
            if len(bad_files)>=8: break
        if bad_files: raise ValueError("manifest hash mismatch: "+", ".join(bad_files))
        return staging,root
    except Exception:
        shutil.rmtree(staging,ignore_errors=True); raise

def _requirement_map(path:Path)->dict[str,str]|None:
    if not path.exists(): return {}
    result={}
    for raw in path.read_text(encoding="utf-8",errors="replace").splitlines():
        line=raw.strip()
        if not line or line.startswith("#"): continue
        if line.startswith("-") or " @ " in line or line.startswith((".","/","\\")): return None
        package_part=line.split(";",1)[0].strip()
        m=re.match(r"^([A-Za-z0-9_.-]+)",package_part)
        if not m: return None
        result[m.group(1).lower().replace("_","-")]=line
    return result

def ensure_dependencies(python_exe:str,old_root:Path,new_root:Path,status:Path,old_version:str,target_version:str)->dict:
    if os.environ.get("TCG_UPDATE_SKIP_PIP")=="1":
        write_status(status,"dependencies_skipped","테스트 설정으로 의존성 단계를 건너뜁니다.",old_version,target_version,34,"dependencies")
        return {"mode":"skip_env","changed":[]}
    old_req=old_root/"requirements.txt"; new_req=new_root/"requirements.txt"
    if not new_req.exists():
        write_status(status,"dependencies_skipped","새 의존성 파일이 없어 설치 단계를 건너뜁니다.",old_version,target_version,34,"dependencies")
        return {"mode":"no_requirements","changed":[]}
    if old_req.exists() and sha256_file(old_req)==sha256_file(new_req):
        write_status(status,"dependencies_skipped","필수 구성요소가 이전 버전과 동일하여 재설치를 건너뜁니다.",old_version,target_version,34,"dependencies",{"requirements_unchanged":True})
        return {"mode":"unchanged","changed":[]}
    old_map=_requirement_map(old_req); new_map=_requirement_map(new_req); changed=None
    if old_map is not None and new_map is not None:
        changed=[line for key,line in new_map.items() if old_map.get(key)!=line]
        if not changed:
            write_status(status,"dependencies_skipped","필수 구성요소 변경이 없어 설치 단계를 건너뜁니다.",old_version,target_version,34,"dependencies")
            return {"mode":"semantic_unchanged","changed":[]}
    flags=getattr(subprocess,"CREATE_NO_WINDOW",0)
    cmd=[python_exe,"-m","pip","install","--disable-pip-version-check"]
    if changed is None:
        cmd += ["-r",str(new_req)]; mode="full"; desc="필수 구성요소 변경을 적용하고 있습니다."
    else:
        cmd += changed; mode="delta"; desc=f"변경된 필수 구성요소 {len(changed)}개만 적용하고 있습니다."
    write_status(status,"dependencies",desc,old_version,target_version,26,"dependencies",{"dependency_mode":mode})
    log_path=new_root/".update_pip.log"; started=time.monotonic()
    with log_path.open("wb") as log:
        proc=subprocess.Popen(cmd,cwd=str(new_root),stdout=log,stderr=subprocess.STDOUT,creationflags=flags)
        while proc.poll() is None:
            elapsed=time.monotonic()-started
            if elapsed>180: proc.kill(); raise RuntimeError("dependency install timed out")
            write_status(status,"dependencies",desc,old_version,target_version,min(33,26+int(elapsed//10)),"dependencies",{"dependency_mode":mode,"dependency_elapsed_seconds":round(elapsed,1)})
            time.sleep(1.5)
    if proc.returncode!=0:
        tail=log_path.read_text(encoding="utf-8",errors="replace")[-1800:]
        raise RuntimeError("dependency install failed: "+tail)
    try: log_path.unlink()
    except OSError: pass
    write_status(status,"dependencies_ready","필수 구성요소 확인을 완료했습니다.",old_version,target_version,35,"dependencies",{"dependency_mode":mode})
    return {"mode":mode,"changed":changed or []}

def start_server(python_exe:str,base:Path,data_dir:Path,port:int)->subprocess.Popen:
    env=os.environ.copy(); env["TCG_SHOP_DATA_DIR"]=str(data_dir); env["TCG_SHOP_PORT"]=str(port); env["TCG_SHOP_OPEN_BROWSER"]="0"; env["PYTHONUTF8"]="1"; env["PYTHONIOENCODING"]="utf-8"
    flags=getattr(subprocess,"CREATE_NO_WINDOW",0)|getattr(subprocess,"CREATE_NEW_PROCESS_GROUP",0)
    log_dir=data_dir/"logs"; log_dir.mkdir(parents=True,exist_ok=True)
    log=(log_dir/"update_server.log").open("ab",buffering=0)
    proc=subprocess.Popen([python_exe,"-m","uvicorn","app:app","--host","127.0.0.1","--port",str(port),"--log-level","info"],cwd=str(base),env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=flags)
    log.close(); return proc

def restore_data_backup(backup:Path,data_dir:Path)->None:
    if not backup.exists(): raise FileNotFoundError(backup)
    tmp=Path(tempfile.mkdtemp(prefix="tcg_update_data_restore_"))
    try:
        with zipfile.ZipFile(backup,"r") as z:
            names=set(z.namelist())
            if "shop.db" not in names: raise ValueError("pre-update backup missing shop.db")
            z.extract("shop.db",tmp)
            image_names=[n for n in names if n.startswith("product_images/") and not n.endswith("/")]
            img_dir=tmp/"product_images"; img_dir.mkdir(exist_ok=True)
            for n in image_names:
                leaf=Path(n).name
                if leaf: (img_dir/leaf).write_bytes(z.read(n))
        db_path=tmp/"shop.db"; conn=sqlite3.connect(db_path)
        try:
            check=conn.execute("PRAGMA integrity_check").fetchone()
            if not check or str(check[0]).lower()!="ok": raise ValueError("backup db integrity failed")
        finally: conn.close()
        live=data_dir/"shop.db"
        for extra in [Path(str(live)+"-wal"),Path(str(live)+"-shm")]:
            try: extra.unlink()
            except OSError: pass
        replacement=data_dir/"shop.rollback.tmp"; shutil.copy2(db_path,replacement); os.replace(replacement,live)
        product_dir=data_dir/"product_images"; product_dir.mkdir(parents=True,exist_ok=True)
        if image_names:
            for old in product_dir.iterdir():
                if old.is_file():
                    try: old.unlink()
                    except OSError: pass
            for p in img_dir.iterdir():
                if p.is_file(): shutil.copy2(p,product_dir/p.name)
    finally: shutil.rmtree(tmp,ignore_errors=True)

def main()->int:
    ap=argparse.ArgumentParser()
    for name in ["base","package","target-version","expected-sha256","data-dir","backup","status","python"]: ap.add_argument("--"+name,required=True)
    ap.add_argument("--port",required=True,type=int); ap.add_argument("--old-pid",required=True,type=int); a=ap.parse_args()
    base=Path(a.base).resolve(); package=Path(a.package).resolve(); data_dir=Path(a.data_dir).resolve(); backup=Path(a.backup).resolve(); status=Path(a.status).resolve(); target=a.target_version
    old_version=(base/"VERSION").read_text(encoding="utf-8").strip() if (base/"VERSION").exists() else "unknown"
    staging=root=rollback=None; new_proc=None; swapped=False
    try:
        write_status(status,"preflight",f"v{target} 패키지를 최종 검증하고 있습니다.",old_version,target,10,"preflight")
        staging,root=extract_and_validate(package,target,a.expected_sha256,base.parent)
        write_status(status,"preflight_done","업데이트 패키지 검증을 완료했습니다.",old_version,target,20,"preflight")
        dep=ensure_dependencies(a.python,base,root,status,old_version,target)
        write_status(status,"stopping",f"v{old_version}을 안전하게 종료하고 있습니다.",old_version,target,45,"stopping",{"dependency_mode":dep["mode"]})
        time.sleep(.8); stop_pid(a.old_pid)
        if not wait_port_free(a.port,15): raise RuntimeError("old server did not release the local port")
        stamp=datetime.now().strftime("%Y%m%d_%H%M%S"); rollback=base.parent/f".{base.name}.rollback_{stamp}"
        if rollback.exists(): shutil.rmtree(rollback,ignore_errors=True)
        write_status(status,"swapping","프로그램 파일을 새 버전으로 교체하고 있습니다.",old_version,target,62,"swapping")
        os.replace(base,rollback); os.replace(root,base); swapped=True
        if staging.exists(): shutil.rmtree(staging,ignore_errors=True)
        staging=root=None
        write_status(status,"launching",f"v{target}을 시작하고 있습니다.",old_version,target,78,"launching")
        new_proc=start_server(a.python,base,data_dir,a.port)
        write_status(status,"verifying",f"v{target} 정상 기동을 확인하고 있습니다.",old_version,target,88,"verifying")
        if not wait_health(new_proc,a.port,target,40): raise RuntimeError("new version health check failed")
        write_status(status,"success",f"v{target} 업데이트가 완료되었습니다.",old_version,target,100,"success",{"port":a.port,"dependency_mode":dep["mode"]})
        if rollback.exists(): shutil.rmtree(rollback,ignore_errors=True)
        try: webbrowser.open(f"http://127.0.0.1:{a.port}/update-center")
        except Exception: pass
        return 0
    except Exception as exc:
        reason=str(exc)
        try:
            if new_proc and new_proc.poll() is None: stop_pid(new_proc.pid); wait_port_free(a.port,8)
            if swapped:
                write_status(status,"rollback","문제를 감지해 이전 버전과 데이터를 복구하고 있습니다.",old_version,target,92,"rollback",{"reason":reason})
                failed=base.parent/f".{base.name}.failed_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                if base.exists():
                    try: os.replace(base,failed)
                    except Exception: shutil.rmtree(base,ignore_errors=True)
                if rollback and rollback.exists(): os.replace(rollback,base)
                restore_data_backup(backup,data_dir)
                old_proc=start_server(a.python,base,data_dir,a.port); rollback_ok=wait_health(old_proc,a.port,old_version,35)
                if rollback_ok:
                    if failed.exists(): shutil.rmtree(failed,ignore_errors=True)
                    write_status(status,"rolled_back",f"새 버전 확인에 실패해 v{old_version}과 업데이트 직전 데이터로 자동 복구했습니다. 원인: {reason}",old_version,target,100,"rolled_back",{"port":a.port})
                    try: webbrowser.open(f"http://127.0.0.1:{a.port}/update-center")
                    except Exception: pass
                else: write_status(status,"rollback_failed",f"업데이트 실패 후 자동 복구 서버 확인도 실패했습니다. 데이터 백업은 보존되어 있습니다. 원인: {reason}",old_version,target,100,"rollback_failed")
            else:
                if port_free(a.port) and base.exists():
                    old_proc=start_server(a.python,base,data_dir,a.port); wait_health(old_proc,a.port,old_version,25)
                write_status(status,"error",f"프로그램 파일을 교체하기 전에 업데이트가 중단되었습니다. 기존 버전은 유지됩니다. 원인: {reason}",old_version,target,100,"error")
        except Exception as rollback_exc:
            write_status(status,"rollback_failed",f"업데이트/복구 처리 중 오류: {reason}; 복구 오류: {rollback_exc}",old_version,target,100,"rollback_failed")
        finally:
            if staging and staging.exists(): shutil.rmtree(staging,ignore_errors=True)
        return 1

if __name__=="__main__": raise SystemExit(main())
