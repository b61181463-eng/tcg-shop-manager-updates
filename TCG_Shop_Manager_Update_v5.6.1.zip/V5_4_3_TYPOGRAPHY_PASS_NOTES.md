# TCG Shop Manager v5.4.3 — Typography Pass

Goal: keep the v5.4.2 layout and visual identity while making information easier to read.

Main changes:
- Larger sidebar labels and shop identity
- Larger dashboard titles, queue text, KPI values, notes, chart labels
- Larger Single Card Workstation labels, fields, controls, card metadata, pricing readouts
- Larger Vault Gate login copy, field labels, inputs, and button text
- Responsive typography tiers for large desktop / tablet / narrow layouts
- No database schema change
- No route or business-rule change
- Boot splash and WinLock updater fixes preserved
