# TCG Shop Manager v5.4.2 — Card Lab + Boot RC

## Native Boot Splash
The Windows launcher now shows a native, borderless startup sequence with real states:
- package validation
- runtime dependency check
- existing session check
- old-session cleanup
- data vault / port preparation
- FastAPI engine start
- health check
- ready

The splash is not a fake fixed-delay loader. It follows actual launcher work and only enforces
a short ~0.85 second minimum visibility so fast starts still have a visible product identity.

## Single Card Lab
The old modal-first singles screen is replaced with:
- permanent Intake Console
- live Card Identity preview
- live Price Intelligence / margin signal
- target-margin recommended buy price
- Card Vault inventory rows
- Recent Slot
- Language Deck

No card-scanning/camera capability is claimed or added in this version.
No database schema change.
