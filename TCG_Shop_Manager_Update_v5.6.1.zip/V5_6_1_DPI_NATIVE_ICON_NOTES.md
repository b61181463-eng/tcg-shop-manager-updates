# v5.6.1 DPI + Native Icon RC

Fixes:
- Native Host enables Per-Monitor DPI Awareness V2 before creating windows.
- Prevents 150% Windows scaling from making the embedded WebView fill only ~2/3 of the host.
- Repeats child sizing after re-parenting/first paint.
- Initial host size is centered and based on the Windows work area.
- App icon is loaded before RegisterClassEx and assigned to HIcon/HIconSm.
- WM_SETICON and class icons are applied again after window creation.
- ExtractIconEx fallback added.
- Runtime EXE/ICO names are versioned to avoid stale Explorer icon-cache identity reuse.
- WS_EX_APPWINDOW explicitly owns the taskbar entry.

Gallery Navy UI and previous updater/CWD/scroll fixes are preserved.
