# v5.6.0 Native Host RC

The running taskbar/top-level window is now owned by a native Windows PE executable named TCGShopManager.exe rather than pythonw.exe.

Transition path:
- Existing shortcut may continue launching launcher.pyw.
- launcher.pyw stages TCGShopManager.exe into the persistent runtime directory and delegates immediately.
- Native host starts launcher.pyw with --native-child, waits for the pywebview window, strips its top-level chrome, reparents it as a child, and owns the visible Windows frame/taskbar identity.
- Native host executable lives outside the swappable program folder at runtime, preserving in-app update folder renames.

No DB schema/business-rule changes. Gallery Navy UI is unchanged.
