# v5.5.1 Desktop Shell CWD Hotfix

The long-lived WebView2 launcher now changes its current working directory to:

`%LOCALAPPDATA%\TCGShopManager\runtime\desktop-shell`

before the native window is created.

The taskbar/window icon is mirrored to the same persistent runtime directory.

Reason: Windows cannot rename the application program directory while a long-lived
process uses that directory as its CWD. v5.5.0 introduced a persistent desktop-shell
process, exposing this Windows directory-lock behavior during in-app updates.

This fix allows the updater to rename the program directory while the WebView shell
remains open and reconnects to the restarted backend.
