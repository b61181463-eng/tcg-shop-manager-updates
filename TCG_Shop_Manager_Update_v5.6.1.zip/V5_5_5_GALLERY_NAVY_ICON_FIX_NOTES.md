# v5.5.5 Gallery Navy + Native Icon Fix

1. Dashboard Single Card button:
   cockpit-deck-art and decorative deck cards now use pointer-events:none.
   Dashboard actions are raised above decoration with explicit z-index.

2. Design:
   Returns to the darker Vault direction that was positively received in v5.4.1,
   but removes gradients/glow/neon. Palette:
   Deep Navy, Warm Cream, Muted Sapphire, Terracotta.
   Hero/sidebar are dark, operating surfaces remain warm and readable.

3. Taskbar icon:
   Win32 ctypes signatures are explicitly pointer-sized/x64-safe.
   LoadImageW returns HANDLE instead of default 32-bit c_int.
   SendMessageW / SetClassLongPtrW use pointer-sized WPARAM/LPARAM/LONG_PTR.
   Repeated injection remains for WebView2 re-parenting.

Previous scroll/clipping/CWD/update fixes remain.
