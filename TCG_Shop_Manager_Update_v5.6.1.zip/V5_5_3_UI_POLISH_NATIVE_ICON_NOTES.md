# v5.5.3 UI Polish + Native Icon

Real-Windows fixes:
1. Card Lab right-side clipping:
   - Columns use minmax(0, ...) and earlier 1360px collapse.
   - All right-column panels explicitly max-width:100% / min-width:0.
   - Main horizontal overflow remains disabled.

2. Palette:
   - Removed grid backgrounds, glow, gold-heavy and holographic treatment.
   - Flat retail palette: Graphite, Soft Ivory, Muted Blue, Brick.
   - Intended to feel like mature POS/retail software rather than AI dashboard art.

3. Sidebar position:
   - Sidebar scrollTop is stored in sessionStorage.
   - Clicking a sidebar menu and navigating to another page restores the same sidebar position.

4. Windows icon:
   - Keeps AppUserModelID.
   - After WebView2 loads, finds the real top-level Win32 window by title.
   - Applies both big/small WM_SETICON icons and class icons.
   - This addresses pythonw.exe icon leakage in taskbar/titlebar.

All previous Desktop Shell CWD isolation, updater lock fixes, and data behavior are retained.
