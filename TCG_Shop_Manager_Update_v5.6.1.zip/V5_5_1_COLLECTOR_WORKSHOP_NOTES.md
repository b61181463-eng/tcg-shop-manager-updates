# v5.5.1 Collector Workshop Pass

## Single Card Workstation
- Removed the third horizontal Price Intelligence column.
- Card registration stays on the left.
- Card preview stays on the right.
- Price Intelligence now occupies the previously empty area directly below preview.
- Horizontal overflow is explicitly prevented on the Singles screen.
- At narrower widths the two-column desk collapses to one column.

## Scroll position
Same-screen interactions on Singles preserve the user's vertical work position for up to 30 seconds:
- inventory filter
- recent-card selection
- reset
- card intake POST/redirect

This prevents the page from jumping back to the top after routine workstation actions.

## Palette
The cyan/purple/holographic "AI SaaS" palette was replaced with a grounded Collector Workshop palette:
- charcoal / dark olive
- warm ivory paper
- brass / copper accents
- muted green status colors

Rainbow gradients and glowing neon effects were removed or reduced.
No DB schema/business rule changes.
