# v5.5.2 Premium TCG Desk

Fixes from real Windows screenshots:
- Price Intelligence no longer overlaps/compresses text.
- Margin meter centered; readouts 2x2; recommendation + signal full width.
- Explicit Windows AppUserModelID for pythonw-hosted shell.
- Multi-size ICO generation path.
- New premium palette: Midnight Ink, Warm Paper, Amber Gold, Steel Blue.
- Desktop shell CWD isolation, updater, scroll preservation retained.
