from __future__ import annotations

import csv
import base64
import hashlib
import hmac
import secrets
import io
import json
import os
import re
import shutil
import signal
import sys
import subprocess
import sqlite3
import tempfile
import threading
import time
import zipfile
import math
import platform
import uuid
import urllib.request
import urllib.error
import traceback
from contextlib import asynccontextmanager
from contextvars import ContextVar
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Iterable

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from starlette.exceptions import HTTPException as StarletteHTTPException
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

APP_NAME = "TCG Shop Manager"
VERSION = "5.6.1"
BASE_DIR = Path(__file__).resolve().parent
UPDATE_PUBLIC_KEY = BASE_DIR / "update_public_key.pem"
BOOTSTRAP_VERSION = "5.0.5"
OFFICIAL_UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/b61181463-eng/tcg-shop-manager-updates/main/manifest.json"
COMMERCIAL_EDITION = "DPI + Native Icon RC"


def get_data_dir() -> Path:
    override = os.environ.get("TCG_SHOP_DATA_DIR")
    if override:
        p = Path(override)
    elif os.name == "nt":
        p = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "TCGShopManager"
    else:
        p = Path.home() / ".local" / "share" / "tcg-shop-manager"
    p.mkdir(parents=True, exist_ok=True)
    (p / "backups").mkdir(exist_ok=True)
    (p / "logs").mkdir(exist_ok=True)
    (p / "product_images").mkdir(exist_ok=True)
    (p / "plugins").mkdir(exist_ok=True)
    (p / "updates").mkdir(exist_ok=True)
    (p / "support").mkdir(exist_ok=True)
    return p

DATA_DIR = get_data_dir()
DB_PATH = DATA_DIR / "shop.db"
BACKUP_DIR = DATA_DIR / "backups"
PRODUCT_IMAGE_DIR = DATA_DIR / "product_images"
PLUGIN_DIR = DATA_DIR / "plugins"
UPDATE_DIR = DATA_DIR / "updates"
SUPPORT_DIR = DATA_DIR / "support"
LICENSE_PUBLIC_KEY_FILE = BASE_DIR / "license_public_key.pem"
TRIAL_DAYS = 14

COURIERS = [
    "CJ대한통운", "한진택배", "롯데택배", "우체국택배", "로젠택배",
    "GS25 반값택배", "CU 알뜰택배", "직접전달", "기타"
]
ORDER_STATUSES = ["결제완료", "포장중", "발송완료", "거래완료"]


PERMISSIONS = [
    ("dashboard", "대시보드"),
    ("products", "상품 · 재고"),
    ("purchases", "발주 · 입고"),
    ("orders", "주문 · 배송"),
    ("expenses", "운영비"),
    ("returns", "반품 · 환불"),
    ("buybacks", "고객 카드 매입"),
    ("singles", "싱글카드 작업대"),
    ("reports", "사업 분석"),
    ("cashflow", "현금흐름"),
    ("alerts", "알림센터"),
    ("simulation", "시뮬레이션"),
    ("inventory", "재고 이력"),
    ("connections", "판매채널 연결"),
    ("settings", "설정 · 백업"),
    ("update", "업데이트 센터"),
    ("data_health", "데이터 점검"),
    ("staff", "직원 · 권한"),
    ("plugins", "기능팩 관리"),
]
PERMISSION_KEYS = {k for k, _ in PERMISSIONS}
ROLE_PRESETS = {
    "owner": set(PERMISSION_KEYS),
    "manager": {"dashboard","products","purchases","orders","expenses","returns","buybacks","singles","reports","cashflow","alerts","simulation","inventory","connections","plugins"},
    "staff": {"dashboard","products","orders","singles","alerts"},
}
ROLE_LABELS = {"owner":"소유자", "manager":"매니저", "staff":"직원"}
CURRENT_ACTOR = ContextVar("tcg_current_actor", default={"id": None, "username": "system"})


def _session_secret() -> str:
    path = DATA_DIR / "session_secret.txt"
    if path.exists():
        value = path.read_text(encoding="utf-8").strip()
        if len(value) >= 32:
            return value
    value = secrets.token_urlsafe(48)
    path.write_text(value, encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return value


def _password_hash(password: str, salt: bytes | None = None) -> tuple[str, str]:
    if salt is None:
        salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 240_000)
    return salt.hex(), digest.hex()


def _verify_password(password: str, salt_hex: str, digest_hex: str) -> bool:
    try:
        salt = bytes.fromhex(salt_hex)
        _, actual = _password_hash(password, salt)
        return hmac.compare_digest(actual, digest_hex)
    except Exception:
        return False


def _user_permissions(conn: sqlite3.Connection, user_id: int, role: str) -> set[str]:
    base = set(ROLE_PRESETS.get(role, ROLE_PRESETS["staff"]))
    base |= _plugin_role_defaults(conn, role)
    valid = {k for k,_ in _all_permissions(conn)}
    rows = conn.execute("SELECT permission,allowed FROM staff_permissions WHERE user_id=?", (user_id,)).fetchall()
    for row in rows:
        key = str(row["permission"])
        if key not in valid:
            continue
        if int(row["allowed"]):
            base.add(key)
        else:
            base.discard(key)
    return base


def _route_permission(path: str) -> str | None:
    if path == "/export/products.csv": return "products"
    if path == "/export/all.zip": return "settings"
    pairs = [
        ("/products", "products"), ("/purchases", "purchases"), ("/suppliers", "purchases"),
        ("/orders", "orders"), ("/expenses", "expenses"), ("/returns", "returns"),
        ("/buybacks", "buybacks"), ("/singles", "singles"), ("/reports", "reports"),
        ("/cashflow", "cashflow"), ("/capital", "cashflow"), ("/alerts", "alerts"),
        ("/simulation", "simulation"), ("/inventory-log", "inventory"),
        ("/connections", "connections"), ("/channels", "connections"),
        ("/settings", "settings"), ("/backup", "settings"), ("/license", "settings"), ("/support", "settings"),
        ("/export", "settings"), ("/import", "products"),
        ("/update-center", "update"), ("/data-health", "data_health"), ("/staff", "staff"), ("/plugins", "plugins"),
    ]
    if path == "/": return "dashboard"
    for prefix, permission in pairs:
        if path.startswith(prefix): return permission
    return None


def _version_tuple(value: str) -> tuple[int, ...]:
    nums = re.findall(r"\d+", str(value or ""))
    return tuple(int(x) for x in nums[:4]) or (0,)


def _plugin_manifest_path(plugin_id: str) -> Path:
    return PLUGIN_DIR / plugin_id / "manifest.json"


def _safe_plugin_id(value: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9_.-]+", "-", (value or "").strip()).strip(".-").lower()
    if not value or len(value) > 64:
        raise ValueError("올바르지 않은 기능팩 ID입니다.")
    return value


def _plugin_permission(plugin_id: str) -> str:
    return f"plugin:{plugin_id}"


def _plugin_registry(conn: sqlite3.Connection, enabled_only: bool = False):
    sql = "SELECT * FROM plugin_registry"
    if enabled_only:
        sql += " WHERE enabled=1 AND status='정상'"
    sql += " ORDER BY display_name COLLATE NOCASE"
    return conn.execute(sql).fetchall()


def _dynamic_permissions(conn: sqlite3.Connection) -> list[tuple[str, str]]:
    rows = _plugin_registry(conn)
    return [(_plugin_permission(str(r["plugin_id"])), f"기능팩 · {r['display_name']}") for r in rows]


def _all_permissions(conn: sqlite3.Connection) -> list[tuple[str, str]]:
    return list(PERMISSIONS) + _dynamic_permissions(conn)


def _plugin_role_defaults(conn: sqlite3.Connection, role: str) -> set[str]:
    if role == "owner":
        return {_plugin_permission(str(r["plugin_id"])) for r in _plugin_registry(conn)}
    if role == "manager":
        return {
            _plugin_permission(str(r["plugin_id"]))
            for r in _plugin_registry(conn)
            if str(r["default_roles"] or "").find("manager") >= 0
        }
    return {
        _plugin_permission(str(r["plugin_id"]))
        for r in _plugin_registry(conn)
        if str(r["default_roles"] or "").find("staff") >= 0
    }


def _plugin_fields(manifest: dict) -> list[dict]:
    fields = manifest.get("fields", [])
    if not isinstance(fields, list):
        return []
    result = []
    for raw in fields[:20]:
        if not isinstance(raw, dict):
            continue
        key = re.sub(r"[^a-zA-Z0-9_]+", "_", str(raw.get("key","")).strip())[:48]
        if not key:
            continue
        ftype = str(raw.get("type","text"))
        if ftype not in {"text","number","date","textarea","select"}:
            ftype = "text"
        opts = raw.get("options", [])
        if not isinstance(opts, list):
            opts = []
        result.append({
            "key": key,
            "label": str(raw.get("label",key))[:80],
            "type": ftype,
            "required": bool(raw.get("required",False)),
            "options": [str(x)[:80] for x in opts[:30]],
            "placeholder": str(raw.get("placeholder",""))[:150],
        })
    return result


def _load_plugin_manifest(plugin_id: str) -> dict:
    path = _plugin_manifest_path(plugin_id)
    if not path.exists():
        raise FileNotFoundError(path)
    doc = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(doc, dict):
        raise ValueError("manifest.json 형식 오류")
    return doc



def ensure_column(conn: sqlite3.Connection, table: str, column: str, definition: str) -> None:
    columns = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    if column not in columns:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")


def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


def now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def init_db() -> None:
    database_existed = DB_PATH.exists()
    conn = db()
    settings_existed_before = False
    previous_schema_version = ""
    if database_existed:
        try:
            settings_existed_before = conn.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='settings'"
            ).fetchone() is not None
            if settings_existed_before:
                row = conn.execute("SELECT value FROM settings WHERE key='schema_app_version'").fetchone()
                previous_schema_version = str(row["value"]) if row else ""
        except sqlite3.Error:
            settings_existed_before = False

    # Before changing an existing database, keep one SQLite-safe migration snapshot.
    if database_existed and settings_existed_before and previous_schema_version != VERSION:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_version = VERSION.replace(".", "_")
        migration_backup = BACKUP_DIR / f"pre_migration_to_v{safe_version}_{stamp}.db"
        backup_conn = sqlite3.connect(migration_backup)
        try:
            conn.backup(backup_conn)
        finally:
            backup_conn.close()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      set_name TEXT NOT NULL DEFAULT '',
      category TEXT NOT NULL DEFAULT 'BOX',
      language TEXT NOT NULL DEFAULT '한국어',
      sku TEXT NOT NULL DEFAULT '',
      barcode TEXT NOT NULL DEFAULT '',
      card_number TEXT NOT NULL DEFAULT '',
      rarity TEXT NOT NULL DEFAULT '',
      card_condition TEXT NOT NULL DEFAULT '',
      avg_cost REAL NOT NULL DEFAULT 0,
      sale_price INTEGER NOT NULL DEFAULT 0,
      stock INTEGER NOT NULL DEFAULT 0,
      low_stock_threshold INTEGER NOT NULL DEFAULT 2,
      notes TEXT NOT NULL DEFAULT '',
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS inventory_movements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      movement_type TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      unit_cost REAL NOT NULL DEFAULT 0,
      reference_type TEXT NOT NULL DEFAULT '',
      reference_id INTEGER,
      reason TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      FOREIGN KEY(product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS suppliers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      contact TEXT NOT NULL DEFAULT '',
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS purchases (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      supplier_id INTEGER,
      supplier_name TEXT NOT NULL DEFAULT '',
      order_date TEXT NOT NULL,
      received_date TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT '발주',
      shipping_cost INTEGER NOT NULL DEFAULT 0,
      other_cost INTEGER NOT NULL DEFAULT 0,
      item_subtotal INTEGER NOT NULL DEFAULT 0,
      total_cost INTEGER NOT NULL DEFAULT 0,
      memo TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      FOREIGN KEY(supplier_id) REFERENCES suppliers(id)
    );

    CREATE TABLE IF NOT EXISTS purchase_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      purchase_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      product_name TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      unit_cost INTEGER NOT NULL,
      line_cost INTEGER NOT NULL,
      allocated_extra REAL NOT NULL DEFAULT 0,
      landed_unit_cost REAL NOT NULL DEFAULT 0,
      FOREIGN KEY(purchase_id) REFERENCES purchases(id) ON DELETE CASCADE,
      FOREIGN KEY(product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS channel_profiles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      fee_rate REAL NOT NULL DEFAULT 0,
      fixed_fee INTEGER NOT NULL DEFAULT 0,
      default_shipping_cost INTEGER NOT NULL DEFAULT 0,
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      channel TEXT NOT NULL DEFAULT '직접입력',
      external_order_no TEXT NOT NULL DEFAULT '',
      order_date TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT '결제완료',
      items_revenue INTEGER NOT NULL DEFAULT 0,
      discount INTEGER NOT NULL DEFAULT 0,
      shipping_charged INTEGER NOT NULL DEFAULT 0,
      gross_revenue INTEGER NOT NULL DEFAULT 0,
      cogs REAL NOT NULL DEFAULT 0,
      platform_fee INTEGER NOT NULL DEFAULT 0,
      shipping_paid INTEGER NOT NULL DEFAULT 0,
      other_cost INTEGER NOT NULL DEFAULT 0,
      gross_profit REAL NOT NULL DEFAULT 0,
      net_profit REAL NOT NULL DEFAULT 0,
      fee_rate REAL NOT NULL DEFAULT 0,
      fixed_fee INTEGER NOT NULL DEFAULT 0,
      memo TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      product_name TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      unit_sale_price INTEGER NOT NULL,
      unit_cost REAL NOT NULL,
      revenue INTEGER NOT NULL,
      cogs REAL NOT NULL,
      gross_profit REAL NOT NULL,
      FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,
      FOREIGN KEY(product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      expense_date TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT '기타',
      description TEXT NOT NULL,
      amount INTEGER NOT NULL,
      memo TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      action TEXT NOT NULL,
      detail TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS capital_transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      tx_date TEXT NOT NULL,
      tx_type TEXT NOT NULL DEFAULT '투입',
      amount INTEGER NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS refunds (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      refund_date TEXT NOT NULL,
      refund_type TEXT NOT NULL DEFAULT '부분환불',
      refund_amount INTEGER NOT NULL DEFAULT 0,
      shipping_deduction INTEGER NOT NULL DEFAULT 0,
      restock INTEGER NOT NULL DEFAULT 0,
      memo TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      FOREIGN KEY(order_id) REFERENCES orders(id)
    );

    CREATE TABLE IF NOT EXISTS buybacks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      buyback_date TEXT NOT NULL,
      seller_alias TEXT NOT NULL DEFAULT '',
      total_paid INTEGER NOT NULL DEFAULT 0,
      expected_sales INTEGER NOT NULL DEFAULT 0,
      expected_profit INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT '완료',
      memo TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS buyback_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      buyback_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      product_name TEXT NOT NULL,
      quantity INTEGER NOT NULL DEFAULT 1,
      unit_paid INTEGER NOT NULL DEFAULT 0,
      expected_sale_price INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY(buyback_id) REFERENCES buybacks(id) ON DELETE CASCADE,
      FOREIGN KEY(product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS staff_users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE COLLATE NOCASE,
      display_name TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'staff',
      password_salt TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      last_login_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS staff_permissions (
      user_id INTEGER NOT NULL,
      permission TEXT NOT NULL,
      allowed INTEGER NOT NULL DEFAULT 1,
      PRIMARY KEY(user_id, permission),
      FOREIGN KEY(user_id) REFERENCES staff_users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS staff_activity (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      username TEXT NOT NULL DEFAULT 'system',
      action TEXT NOT NULL,
      detail TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      FOREIGN KEY(user_id) REFERENCES staff_users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS plugin_registry (
      plugin_id TEXT PRIMARY KEY,
      display_name TEXT NOT NULL,
      version TEXT NOT NULL DEFAULT '1.0.0',
      description TEXT NOT NULL DEFAULT '',
      menu_label TEXT NOT NULL DEFAULT '',
      icon TEXT NOT NULL DEFAULT '◆',
      min_app_version TEXT NOT NULL DEFAULT '',
      max_app_version TEXT NOT NULL DEFAULT '',
      default_roles TEXT NOT NULL DEFAULT 'owner,manager',
      enabled INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT '정상',
      last_error TEXT NOT NULL DEFAULT '',
      installed_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS plugin_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      plugin_id TEXT NOT NULL,
      payload_json TEXT NOT NULL DEFAULT '{}',
      created_by TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY(plugin_id) REFERENCES plugin_registry(plugin_id) ON DELETE CASCADE
    );
    """)

    # v3.5 product-master / multi-channel mapping foundation.
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS channel_product_mappings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      channel_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      external_product_id TEXT NOT NULL DEFAULT '',
      external_sku TEXT NOT NULL DEFAULT '',
      remote_name TEXT NOT NULL DEFAULT '',
      remote_stock INTEGER NOT NULL DEFAULT -1,
      sync_mode TEXT NOT NULL DEFAULT 'stock',
      active INTEGER NOT NULL DEFAULT 1,
      last_snapshot_at TEXT NOT NULL DEFAULT '',
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(channel_id, product_id),
      FOREIGN KEY(channel_id) REFERENCES channel_profiles(id),
      FOREIGN KEY(product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS channel_sync_runs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      channel_id INTEGER NOT NULL,
      source_name TEXT NOT NULL DEFAULT '',
      mapped_count INTEGER NOT NULL DEFAULT 0,
      unmatched_count INTEGER NOT NULL DEFAULT 0,
      difference_count INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      FOREIGN KEY(channel_id) REFERENCES channel_profiles(id)
    );
    """)

    # v1.2 fulfillment migration. Existing v1.1.x databases are upgraded in-place.
    ensure_column(conn, "orders", "courier", "TEXT NOT NULL DEFAULT ''")
    ensure_column(conn, "orders", "tracking_number", "TEXT NOT NULL DEFAULT ''")
    ensure_column(conn, "orders", "shipped_at", "TEXT NOT NULL DEFAULT ''")
    ensure_column(conn, "orders", "completed_at", "TEXT NOT NULL DEFAULT ''")
    ensure_column(conn, "orders", "updated_at", "TEXT NOT NULL DEFAULT ''")
    ensure_column(conn, "products", "image_filename", "TEXT NOT NULL DEFAULT ''")
    # v2.0 channel connector foundation
    ensure_column(conn, "channel_profiles", "adapter_mode", "TEXT NOT NULL DEFAULT 'manual'")
    ensure_column(conn, "channel_profiles", "connector_status", "TEXT NOT NULL DEFAULT '수동 운영'")
    ensure_column(conn, "channel_profiles", "external_shop_id", "TEXT NOT NULL DEFAULT ''")
    ensure_column(conn, "channel_profiles", "last_sync_at", "TEXT NOT NULL DEFAULT ''")
    ensure_column(conn, "channel_profiles", "connector_notes", "TEXT NOT NULL DEFAULT ''")
    # v4.2 login abuse protection
    ensure_column(conn, "staff_users", "failed_login_count", "INTEGER NOT NULL DEFAULT 0")
    ensure_column(conn, "staff_users", "locked_until", "TEXT NOT NULL DEFAULT ''")
    conn.execute("UPDATE orders SET status='포장중' WHERE status='상품준비'")
    conn.execute("UPDATE orders SET status='발송완료' WHERE status='배송중'")
    conn.execute("UPDATE orders SET updated_at=created_at WHERE updated_at='' OR updated_at IS NULL")

    defaults = {
      "shop_name": "내 TCG 온라인샵",
      "owner_name": "",
      "currency": "KRW",
      "auto_backup": "1",
      "last_backup_date": "",
      "update_manifest_url": OFFICIAL_UPDATE_MANIFEST_URL,
      "update_channel": "stable",
      "auto_update_check": "1",
      "auto_update_check_hours": "6",
      "last_update_auto_error": "",
      "last_update_check": "",
      "latest_known_version": "",
      "latest_update_notes": "",
      "latest_update_severity": "",
      "latest_update_package_url": "",
      "latest_update_sha256": "",
      "latest_update_rollout": "",
      "latest_update_channel": "",
      "latest_update_required": "0",
      "last_update_apply_status": "",
      "last_update_apply_version": "",
      "last_update_apply_at": "",
      "reorder_target_days": "21",
      "stale_stock_days": "60",
      "install_id": "",
      "license_holder": "",
      "license_key": "",
      "license_status": "미등록",
      "license_id": "",
      "license_issued_at": "",
      "license_verified_at": "",
      "license_enforcement": "0" if database_existed else "1",
      "trial_started_at": now(),
      "target_margin_rate": "25",
      "default_buyback_margin": "30",
      "cashflow_start_date": "",
      "auth_enabled": "0",
      "onboarding_completed": "0" if not database_existed else "1",
      "getting_started_dismissed": "1" if database_existed else "0",
      "schema_app_version": VERSION,
      "last_startup_db_check": "",
    }
    for k, v in defaults.items():
        conn.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))
    if not setting(conn, "install_id", ""):
        set_setting(conn, "install_id", str(uuid.uuid4()))
    if not setting(conn, "update_manifest_url", "").strip():
        set_setting(conn, "update_manifest_url", OFFICIAL_UPDATE_MANIFEST_URL)
    set_setting(conn, "schema_app_version", VERSION)

    # Lightweight startup integrity signal. It does not mutate business rows.
    try:
        quick = conn.execute("PRAGMA quick_check").fetchone()
        quick_result = str(quick[0]) if quick else "unknown"
    except sqlite3.Error as exc:
        quick_result = f"error:{exc}"
    set_setting(conn, "last_startup_db_check", quick_result[:300])

    active_owner_count = int(conn.execute(
        "SELECT COUNT(*) c FROM staff_users WHERE role='owner' AND active=1"
    ).fetchone()["c"])
    if setting(conn, "auth_enabled", "0") == "1" and active_owner_count == 0:
        set_setting(conn, "auth_enabled", "0")
        conn.execute(
            "INSERT INTO staff_activity(user_id,username,action,detail,created_at) VALUES(NULL,'system','AUTH_RECOVERY','활성 소유자가 없어 로그인 잠금을 자동 해제함',?)",
            (now(),),
        )

    for name, rate, fixed, ship in [
      ("네이버 스마트스토어", 0.0, 0, 0),
      ("자사몰", 0.0, 0, 0),
      ("번개장터", 0.0, 0, 0),
      ("크림", 0.0, 0, 0),
      ("직접입력", 0.0, 0, 0),
    ]:
        conn.execute("INSERT OR IGNORE INTO channel_profiles(name,fee_rate,fixed_fee,default_shipping_cost,created_at) VALUES(?,?,?,?,?)", (name, rate, fixed, ship, now()))
    conn.commit(); conn.close()


def setting(conn: sqlite3.Connection, key: str, default: str = "") -> str:
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(conn: sqlite3.Connection, key: str, value: str) -> None:
    conn.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))


def audit(conn: sqlite3.Connection, action: str, detail: str = "") -> None:
    stamp = now()
    conn.execute("INSERT INTO audit_log(action,detail,created_at) VALUES(?,?,?)", (action, detail, stamp))
    actor = CURRENT_ACTOR.get()
    conn.execute("INSERT INTO staff_activity(user_id,username,action,detail,created_at) VALUES(?,?,?,?,?)",
                 (actor.get("id"), actor.get("username") or "system", action, detail, stamp))


def _snapshot_database(target: Path) -> None:
    src = db(); dst = sqlite3.connect(target)
    try:
        with dst:
            src.backup(dst)
    finally:
        src.close(); dst.close()


def create_backup(label: str = "auto") -> Path:
    """Create a full portable backup containing DB + product images."""
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    target = BACKUP_DIR / f"shop_{label}_{stamp}.tcgbak"
    tmp_db = Path(tempfile.mkstemp(prefix="tcg_backup_", suffix=".db")[1])
    try:
        _snapshot_database(tmp_db)
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as z:
            z.write(tmp_db, "shop.db")
            if PRODUCT_IMAGE_DIR.exists():
                for image in sorted(PRODUCT_IMAGE_DIR.iterdir()):
                    if image.is_file():
                        z.write(image, f"product_images/{image.name}")
            z.writestr("metadata.json", json.dumps({
                "app": APP_NAME, "version": VERSION, "created_at": now(), "format": 1
            }, ensure_ascii=False, indent=2))
    finally:
        try: tmp_db.unlink()
        except OSError: pass
    _validate_backup_archive(target)
    return target


def _validate_sqlite(path: Path) -> None:
    conn = sqlite3.connect(path)
    try:
        result = conn.execute("PRAGMA integrity_check").fetchone()
        if not result or str(result[0]).lower() != "ok":
            raise ValueError("백업 데이터베이스 무결성 검사에 실패했습니다.")
        tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "products" not in tables or "orders" not in tables:
            raise ValueError("TCG Shop Manager 백업 데이터베이스가 아닙니다.")
        fk_errors = conn.execute("PRAGMA foreign_key_check").fetchall()
        if fk_errors:
            raise ValueError(f"백업 데이터베이스 관계 무결성 오류가 {len(fk_errors)}건 있습니다.")
    finally:
        conn.close()


def _validate_backup_archive(path: Path) -> None:
    if path.suffix.lower() == ".db":
        _validate_sqlite(path)
        return
    tmp_dir = Path(tempfile.mkdtemp(prefix="tcg_backup_verify_"))
    try:
        with zipfile.ZipFile(path, "r") as z:
            bad = z.testzip()
            if bad:
                raise ValueError(f"백업 압축 파일 손상: {bad}")
            names = set(z.namelist())
            if "shop.db" not in names:
                raise ValueError("백업에 shop.db가 없습니다.")
            z.extract("shop.db", tmp_dir)
        _validate_sqlite(tmp_dir / "shop.db")
    except zipfile.BadZipFile as exc:
        raise ValueError("백업 압축 파일이 손상되었습니다.") from exc
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


def restore_backup_file(path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(path)
    tmp_dir = Path(tempfile.mkdtemp(prefix="tcg_restore_"))
    try:
        restore_db = tmp_dir / "shop.db"
        has_images = False
        if path.suffix.lower() == ".db":
            shutil.copy2(path, restore_db)
        else:
            try:
                with zipfile.ZipFile(path, "r") as z:
                    names = set(z.namelist())
                    if "shop.db" not in names:
                        raise ValueError("백업 안에 shop.db가 없습니다.")
                    if "metadata.json" in names:
                        try:
                            meta = json.loads(z.read("metadata.json").decode("utf-8"))
                            backup_version = str(meta.get("version", "")).strip()
                            if backup_version and _version_tuple(backup_version) > _version_tuple(VERSION):
                                raise ValueError(
                                    f"이 백업은 더 새로운 TCG Shop Manager v{backup_version}에서 생성되었습니다."
                                )
                        except ValueError:
                            raise
                        except Exception as exc:
                            raise ValueError("백업 metadata.json을 확인할 수 없습니다.") from exc
                    z.extract("shop.db", tmp_dir)
                    image_names = [n for n in names if n.startswith("product_images/") and not n.endswith("/")]
                    for name in image_names:
                        # Block path traversal in user-supplied backup archives.
                        leaf = Path(name).name
                        if not leaf:
                            continue
                        data = z.read(name)
                        (tmp_dir / "product_images").mkdir(exist_ok=True)
                        (tmp_dir / "product_images" / leaf).write_bytes(data)
                    has_images = bool(image_names)
            except zipfile.BadZipFile as exc:
                raise ValueError("백업 파일 형식이 올바르지 않습니다.") from exc

        _validate_sqlite(restore_db)
        # Safety net before replacing live data.
        create_backup("pre_restore")
        try:
            conn = db(); conn.execute("PRAGMA wal_checkpoint(TRUNCATE)"); conn.close()
        except Exception:
            pass
        for extra in [Path(str(DB_PATH) + "-wal"), Path(str(DB_PATH) + "-shm")]:
            try: extra.unlink()
            except OSError: pass
        tmp_live = DATA_DIR / "shop.restore.tmp"
        shutil.copy2(restore_db, tmp_live)
        os.replace(tmp_live, DB_PATH)

        if has_images:
            restored_images = tmp_dir / "product_images"
            PRODUCT_IMAGE_DIR.mkdir(parents=True, exist_ok=True)
            for old in PRODUCT_IMAGE_DIR.iterdir():
                if old.is_file():
                    try: old.unlink()
                    except OSError: pass
            for img in restored_images.iterdir():
                if img.is_file():
                    shutil.copy2(img, PRODUCT_IMAGE_DIR / img.name)
        init_db()
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


def maybe_auto_backup() -> None:
    conn = db()
    enabled = setting(conn, "auto_backup", "1") == "1"
    last = setting(conn, "last_backup_date", "")
    today = date.today().isoformat()
    conn.close()
    if enabled and last != today:
        create_backup("daily")
        conn = db(); set_setting(conn, "last_backup_date", today); conn.commit(); conn.close()
        backups = sorted(BACKUP_DIR.glob("shop_daily_*"), reverse=True)
        for old in backups[14:]:
            try: old.unlink()
            except OSError: pass



def _sku_piece(value: str, fallback: str, length: int = 4) -> str:
    cleaned = "".join(ch for ch in (value or "").upper() if ch.isalnum())
    return (cleaned[:length] or fallback)


def generate_sku(conn: sqlite3.Connection, category: str, language: str, set_name: str = "") -> str:
    lang_map = {"한국어": "KR", "일본어": "JP", "영어": "EN", "기타": "ETC"}
    cat_map = {"BOX": "BX", "팩": "PK", "싱글카드": "SG", "굿즈": "GD", "기타": "ET"}
    prefix = f"{lang_map.get(language, 'ETC')}-{cat_map.get(category, 'ET')}-{_sku_piece(set_name, 'TCG')}"
    for _ in range(50):
        candidate = f"{prefix}-{uuid.uuid4().hex[:6].upper()}"
        if not conn.execute("SELECT 1 FROM products WHERE sku=? LIMIT 1", (candidate,)).fetchone():
            return candidate
    return f"{prefix}-{datetime.now().strftime('%H%M%S')}"


def _version_tuple(value: str) -> tuple[int, ...]:
    nums = re.findall(r"\d+", value or "")
    return tuple(int(x) for x in nums[:4]) or (0,)


def product_velocity(conn: sqlite3.Connection, days: int = 30) -> dict[int, int]:
    cutoff = (date.today() - timedelta(days=max(1, days)-1)).isoformat()
    rows = conn.execute("""
      SELECT oi.product_id, COALESCE(SUM(oi.quantity),0) qty
      FROM order_items oi JOIN orders o ON o.id=oi.order_id
      WHERE o.status!='취소' AND o.order_date>=?
      GROUP BY oi.product_id
    """, (cutoff,)).fetchall()
    return {int(r['product_id']): int(r['qty'] or 0) for r in rows}


def enrich_products(conn: sqlite3.Connection, rows, days: int = 30):
    sold = product_velocity(conn, days)
    try: target = max(7, min(90, int(setting(conn, 'reorder_target_days', '21'))))
    except Exception: target = 21
    out = []
    for row in rows:
        d = dict(row)
        qty = sold.get(int(d['id']), 0)
        daily = qty / float(days)
        if daily > 0:
            cover = float(d['stock']) / daily
            suggestion = max(0, math.ceil(daily * target + int(d['low_stock_threshold']) - int(d['stock'])))
        else:
            cover = None
            suggestion = max(0, int(d['low_stock_threshold']) + 1 - int(d['stock'])) if int(d['stock']) <= int(d['low_stock_threshold']) else 0
        d.update(sold_30d=qty, daily_sales=daily, days_cover=cover, reorder_qty=suggestion)
        out.append(d)
    return out

def _save_product_image(pid: int, upload: UploadFile | None) -> str:
    if upload is None or not getattr(upload, "filename", ""):
        return ""
    suffix = Path(upload.filename).suffix.lower()
    allowed = {".jpg", ".jpeg", ".png", ".webp"}
    if suffix not in allowed:
        raise HTTPException(400, "상품 이미지는 JPG, PNG, WEBP만 지원합니다.")
    data = upload.file.read(5 * 1024 * 1024 + 1)
    if len(data) > 5 * 1024 * 1024:
        raise HTTPException(400, "상품 이미지는 5MB 이하만 지원합니다.")
    if not data:
        return ""
    PRODUCT_IMAGE_DIR.mkdir(parents=True, exist_ok=True)
    filename = f"product_{pid}_{datetime.now().strftime('%Y%m%d%H%M%S%f')}{suffix}"
    (PRODUCT_IMAGE_DIR / filename).write_bytes(data)
    return filename


def _delete_product_image(filename: str) -> None:
    if not filename:
        return
    safe = Path(filename).name
    try:
        (PRODUCT_IMAGE_DIR / safe).unlink()
    except OSError:
        pass


def won(v) -> str:
    return f"{int(round(float(v or 0))):,}원"


def pct(v) -> str:
    return f"{float(v or 0):.2f}%"



def cashflow_summary(conn: sqlite3.Connection) -> dict:
    capital = int(conn.execute("SELECT COALESCE(SUM(CASE WHEN tx_type='투입' THEN amount ELSE -amount END),0) v FROM capital_transactions").fetchone()['v'] or 0)
    order_cash = conn.execute("""
      SELECT COALESCE(SUM(gross_revenue),0) gross_sales,
             COALESCE(SUM(platform_fee + shipping_paid + other_cost),0) selling_costs
      FROM orders WHERE status!='취소'
    """).fetchone()
    sales = int(order_cash['gross_sales'] or 0)
    selling_costs = int(order_cash['selling_costs'] or 0)
    sales_cash = sales - selling_costs
    refunds = int(conn.execute("SELECT COALESCE(SUM(refund_amount),0) v FROM refunds").fetchone()['v'] or 0)
    purchases = int(conn.execute("SELECT COALESCE(SUM(total_cost),0) v FROM purchases WHERE status!='취소'").fetchone()['v'] or 0)
    expenses = int(conn.execute("SELECT COALESCE(SUM(amount),0) v FROM expenses").fetchone()['v'] or 0)
    buybacks = int(conn.execute("SELECT COALESCE(SUM(total_paid),0) v FROM buybacks WHERE status!='취소'").fetchone()['v'] or 0)
    inventory = float(conn.execute("SELECT COALESCE(SUM(stock*avg_cost),0) v FROM products WHERE active=1").fetchone()['v'] or 0)
    available = capital + sales_cash - refunds - purchases - expenses - buybacks
    return dict(capital=capital,sales=sales,selling_costs=selling_costs,sales_cash=sales_cash,refunds=refunds,purchases=purchases,expenses=expenses,buybacks=buybacks,inventory=inventory,available=available)

def alert_items(conn: sqlite3.Connection):
    alerts=[]
    low=conn.execute("SELECT COUNT(*) c FROM products WHERE active=1 AND stock<=low_stock_threshold").fetchone()['c']
    if low: alerts.append({'level':'danger','title':'재고 부족','detail':f'{low}종 상품이 재고 부족 기준 이하입니다.','href':'/products?only_low=1'})
    packing=conn.execute("SELECT COUNT(*) c FROM orders WHERE status IN ('결제완료','포장중')").fetchone()['c']
    if packing: alerts.append({'level':'warn','title':'처리할 주문','detail':f'{packing}건의 주문이 포장 또는 발송 대기 중입니다.','href':'/orders'})
    waiting=conn.execute("SELECT COUNT(*) c FROM purchases WHERE status='발주'").fetchone()['c']
    if waiting: alerts.append({'level':'info','title':'미입고 발주','detail':f'{waiting}건의 발주가 아직 입고되지 않았습니다.','href':'/purchases'})
    cutoff=(date.today()-timedelta(days=60)).isoformat()
    stale=conn.execute("""SELECT COUNT(*) c FROM products p WHERE p.active=1 AND p.stock>0 AND NOT EXISTS(SELECT 1 FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.product_id=p.id AND o.status!='취소' AND o.order_date>=?)""",(cutoff,)).fetchone()['c']
    if stale: alerts.append({'level':'muted','title':'장기 미판매 재고','detail':f'{stale}종이 60일 이상 판매 기록이 없습니다.','href':'/reports'})
    return alerts

def run_what_if(*, starting_cash:int, purchase_qty:int, unit_cost:int, unit_sale_price:int,
                expected_monthly_units:float, fee_rate:float, shipping_per_order:int,
                fixed_monthly_cost:int, horizon_days:int=30) -> dict:
    """Single-product management what-if model. This is a planning estimate, not an accounting forecast."""
    starting_cash=max(0,int(starting_cash)); purchase_qty=max(0,int(purchase_qty))
    unit_cost=max(0,int(unit_cost)); unit_sale_price=max(0,int(unit_sale_price))
    expected_monthly_units=max(0.0,float(expected_monthly_units)); fee_rate=max(0.0,min(100.0,float(fee_rate)))
    shipping_per_order=max(0,int(shipping_per_order)); fixed_monthly_cost=max(0,int(fixed_monthly_cost))
    horizon_days=max(1,min(365,int(horizon_days)))

    capital_required=purchase_qty*unit_cost
    cash_after_purchase=starting_cash-capital_required
    demand_units=expected_monthly_units*horizon_days/30.0
    sold_units=min(float(purchase_qty), demand_units)
    fee_per_unit=unit_sale_price*fee_rate/100.0
    unit_profit=unit_sale_price-unit_cost-fee_per_unit-shipping_per_order
    revenue=sold_units*unit_sale_price
    fees=sold_units*fee_per_unit
    shipping=sold_units*shipping_per_order
    cogs=sold_units*unit_cost
    net_profit=revenue-cogs-fees-shipping-fixed_monthly_cost
    ending_cash=starting_cash-capital_required+revenue-fees-shipping-fixed_monthly_cost
    leftover_units=max(0.0,purchase_qty-sold_units)
    leftover_cost=leftover_units*unit_cost
    sell_through=(sold_units/purchase_qty*100.0) if purchase_qty else 0.0
    contribution=unit_sale_price-unit_cost-fee_per_unit-shipping_per_order
    breakeven_units=math.ceil(fixed_monthly_cost/contribution) if contribution>0 else None

    risks=[]
    if purchase_qty == 0: risks.append("매입 수량이 0개라 비교할 재고 투입이 없습니다.")
    if capital_required>starting_cash: risks.append("필요 매입자금이 현재 가용현금을 초과합니다.")
    elif starting_cash and capital_required>starting_cash*.60: risks.append("현재 현금의 60% 이상이 한 상품 재고에 묶이는 조건입니다.")
    if purchase_qty and sell_through<50: risks.append("예상 판매율이 50% 미만이라 장기재고 위험이 있습니다.")
    if unit_profit<=0: risks.append("예상 단위이익이 0원 이하입니다. 판매할수록 손실이 날 수 있습니다.")
    if starting_cash and ending_cash<starting_cash*.20: risks.append("예상 종료 현금이 시작 현금의 20% 아래로 내려갑니다.")
    if not risks: risks.append("입력한 가정 기준으로 큰 현금·마진 경고는 없습니다.")

    scenarios=[]
    for label, price_mult, demand_mult in [("가격 -10%",.90,1.25),("현재 가격",1.0,1.0),("가격 +10%",1.10,.80)]:
        price=round(unit_sale_price*price_mult)
        sold=min(float(purchase_qty), demand_units*demand_mult)
        fee=price*fee_rate/100.0
        profit=(price-unit_cost-fee-shipping_per_order)*sold-fixed_monthly_cost
        scenarios.append({
            "label":label,"price":price,"sold_units":round(sold,1),
            "revenue":round(price*sold),"net_profit":round(profit),
            "sell_through":round((sold/purchase_qty*100) if purchase_qty else 0,1)
        })

    return {
        "starting_cash":starting_cash,"purchase_qty":purchase_qty,"unit_cost":unit_cost,"unit_sale_price":unit_sale_price,
        "expected_monthly_units":expected_monthly_units,"fee_rate":fee_rate,"shipping_per_order":shipping_per_order,
        "fixed_monthly_cost":fixed_monthly_cost,"horizon_days":horizon_days,"capital_required":round(capital_required),"cash_after_purchase":round(cash_after_purchase),
        "expected_sold_units":round(sold_units,1),"revenue":round(revenue),"fees":round(fees),"shipping":round(shipping),
        "cogs":round(cogs),"net_profit":round(net_profit),"ending_cash":round(ending_cash),
        "leftover_units":round(leftover_units,1),"leftover_cost":round(leftover_cost),"sell_through":round(sell_through,1),
        "unit_profit":round(unit_profit),"breakeven_units":breakeven_units,"risk":risks,"scenarios":scenarios,"created_at":now()
    }


STORE_SIM_PROFILES = {
    "solo_online": {
        "label": "1인 온라인샵",
        "description": "소규모 재고와 제한된 운전자금으로 혼자 주문·발주를 처리하는 매장",
        "days": 180,
        "starting_cash": 8_000_000,
        "product_count": 42,
        "inventory_ratio": 0.50,
        "daily_orders": (2, 8),
        "cost_range": (7_000, 65_000),
        "margin_range": (0.20, 0.40),
        "fee_range": (0.025, 0.055),
        "shipping": 3_000,
        "refund_rate": 0.035,
        "monthly_fixed_cost": 220_000,
        "buyback_chance": 0.008,
        "cash_reserve": 550_000,
        "category_weights": {"BOX": 0.35, "팩": 0.35, "싱글카드": 0.30},
        "channels": ["자사몰"],
    },
    "singles_specialist": {
        "label": "싱글카드 전문점",
        "description": "싱글카드 비중과 고객 매입 빈도가 높은 전문 매장",
        "days": 180,
        "starting_cash": 10_000_000,
        "product_count": 95,
        "inventory_ratio": 0.52,
        "daily_orders": (3, 11),
        "cost_range": (3_000, 55_000),
        "margin_range": (0.28, 0.58),
        "fee_range": (0.020, 0.050),
        "shipping": 3_000,
        "refund_rate": 0.025,
        "monthly_fixed_cost": 300_000,
        "buyback_chance": 0.045,
        "cash_reserve": 700_000,
        "category_weights": {"BOX": 0.10, "팩": 0.10, "싱글카드": 0.80},
        "channels": ["자사몰", "오프라인"],
    },
    "sealed_box": {
        "label": "BOX 중심 판매점",
        "description": "단가가 높은 미개봉 BOX 재고를 중심으로 운영하는 매장",
        "days": 150,
        "starting_cash": 14_000_000,
        "product_count": 38,
        "inventory_ratio": 0.58,
        "daily_orders": (1, 6),
        "cost_range": (28_000, 115_000),
        "margin_range": (0.14, 0.30),
        "fee_range": (0.025, 0.055),
        "shipping": 3_500,
        "refund_rate": 0.028,
        "monthly_fixed_cost": 330_000,
        "buyback_chance": 0.002,
        "cash_reserve": 1_200_000,
        "category_weights": {"BOX": 0.78, "팩": 0.17, "싱글카드": 0.05},
        "channels": ["자사몰", "네이버"],
    },
    "team_store": {
        "label": "직원 3명 운영점",
        "description": "주문량과 고정비가 커지고 여러 직원이 운영에 참여하는 성장 매장",
        "days": 180,
        "starting_cash": 22_000_000,
        "product_count": 78,
        "inventory_ratio": 0.50,
        "daily_orders": (6, 18),
        "cost_range": (6_000, 85_000),
        "margin_range": (0.20, 0.42),
        "fee_range": (0.025, 0.055),
        "shipping": 3_000,
        "refund_rate": 0.040,
        "monthly_fixed_cost": 1_250_000,
        "buyback_chance": 0.018,
        "cash_reserve": 1_800_000,
        "category_weights": {"BOX": 0.30, "팩": 0.25, "싱글카드": 0.45},
        "channels": ["자사몰", "오프라인"],
    },
    "multichannel": {
        "label": "멀티채널 판매점",
        "description": "자사몰·오픈마켓 등 여러 판매채널을 동시에 운영하는 매장",
        "days": 180,
        "starting_cash": 18_000_000,
        "product_count": 72,
        "inventory_ratio": 0.52,
        "daily_orders": (5, 16),
        "cost_range": (6_000, 90_000),
        "margin_range": (0.18, 0.40),
        "fee_range": (0.025, 0.075),
        "shipping": 3_000,
        "refund_rate": 0.043,
        "monthly_fixed_cost": 650_000,
        "buyback_chance": 0.015,
        "cash_reserve": 1_400_000,
        "category_weights": {"BOX": 0.35, "팩": 0.20, "싱글카드": 0.45},
        "channels": ["자사몰", "네이버", "오픈마켓"],
    },
}


def _weighted_choice(rng, weights: dict[str, float]) -> str:
    items = list(weights.items())
    x = rng.random() * sum(max(0.0, float(w)) for _, w in items)
    acc = 0.0
    for key, weight in items:
        acc += max(0.0, float(weight))
        if x <= acc:
            return key
    return items[-1][0]


def run_store_profile_simulation(profile_key: str, seed: int) -> dict:
    """Synthetic long-run operations integrity simulation.

    This validates bookkeeping/state invariants under realistic-ish workload.
    It is not a sales-demand forecast, accounting statement, or guarantee of profitability.
    """
    import random

    if profile_key not in STORE_SIM_PROFILES:
        raise ValueError("unknown store profile")
    cfg = dict(STORE_SIM_PROFILES[profile_key])
    rng = random.Random(int(seed))

    days = int(cfg["days"])
    starting_cash = float(cfg["starting_cash"])
    product_count = int(cfg["product_count"])
    inventory_budget = starting_cash * float(cfg["inventory_ratio"])

    products = []
    low_cost, high_cost = cfg["cost_range"]
    low_margin, high_margin = cfg["margin_range"]

    for i in range(product_count):
        category = _weighted_choice(rng, cfg["category_weights"])
        cost = float(rng.randrange(int(low_cost // 1000), int(high_cost // 1000) + 1) * 1000)
        margin = rng.uniform(float(low_margin), float(high_margin))
        sale = max(cost + 1000, round(cost * (1.0 + margin) / 1000) * 1000)
        demand = rng.uniform(0.55, 1.60)
        products.append({
            "id": i + 1,
            "category": category,
            "cost": cost,
            "sale": float(sale),
            "stock": 1,
            "sold": 0,
            "returned": 0,
            "reordered": 0,
            "buyback_added": 0,
            "demand": demand,
        })

    # If the baseline 1-per-SKU would exceed the configured budget, scale costs down
    # only for this synthetic harness so the starting state itself is valid.
    baseline = sum(p["cost"] for p in products)
    if baseline > inventory_budget and baseline > 0:
        scale = inventory_budget / baseline * 0.92
        for p in products:
            p["cost"] = max(1000.0, round(p["cost"] * scale / 1000) * 1000)
            p["sale"] = max(p["cost"] + 1000, round(p["cost"] * rng.uniform(1.18, 1.42) / 1000) * 1000)

    remaining = inventory_budget - sum(p["cost"] for p in products)
    order = list(range(len(products)))
    while remaining >= 1000:
        rng.shuffle(order)
        progressed = False
        for idx in order:
            p = products[idx]
            if p["stock"] >= 12:
                continue
            if p["cost"] <= remaining:
                p["stock"] += 1
                remaining -= p["cost"]
                progressed = True
            if remaining < 1000:
                break
        if not progressed:
            break

    initial_inventory = sum(p["cost"] * p["stock"] for p in products)
    cash = starting_cash - initial_inventory
    min_cash = cash

    revenue = 0.0
    fees = 0.0
    shipping = 0.0
    refunds = 0.0
    operating_expenses = 0.0
    reorder_spend = 0.0
    buyback_spend = 0.0
    cogs = 0.0

    orders = 0
    refund_count = 0
    reorder_count = 0
    buyback_count = 0
    stockout_events = 0
    rejected_reorders = 0
    channel_orders = {name: 0 for name in cfg["channels"]}
    daily = []

    reserve = float(cfg["cash_reserve"])
    min_orders, max_orders = cfg["daily_orders"]
    monthly_fixed = float(cfg["monthly_fixed_cost"])

    for day in range(days):
        # Weekend-style demand bump to make the load bursty rather than flat.
        dow = day % 7
        base_orders = rng.randint(int(min_orders), int(max_orders))
        if dow in (4, 5):
            base_orders = max(base_orders, round(base_orders * 1.25))

        day_revenue = 0.0
        day_orders = 0

        for _ in range(base_orders):
            available = [p for p in products if p["stock"] > 0]
            if not available:
                stockout_events += 1
                break

            # Demand-weighted selection while retaining deterministic RNG.
            total_demand = sum(p["demand"] for p in available)
            pick = rng.random() * total_demand
            acc = 0.0
            product = available[-1]
            for p in available:
                acc += p["demand"]
                if pick <= acc:
                    product = p
                    break

            if product["category"] == "팩":
                qty = rng.randint(1, min(3, int(product["stock"])))
            else:
                qty = 1

            channel = rng.choice(cfg["channels"])
            fee_rate = rng.uniform(float(cfg["fee_range"][0]), float(cfg["fee_range"][1]))
            gross = product["sale"] * qty
            fee = round(gross * fee_rate)
            ship = float(cfg["shipping"])
            sale_cogs = product["cost"] * qty

            product["stock"] -= qty
            product["sold"] += qty
            revenue += gross
            fees += fee
            shipping += ship
            cogs += sale_cogs
            cash += gross - fee - ship
            orders += 1
            day_orders += 1
            day_revenue += gross
            channel_orders[channel] += 1

            if rng.random() < float(cfg["refund_rate"]):
                refund_count += 1
                refund_amount = gross
                refunds += refund_amount
                cash -= refund_amount

                # Most returned products are saleable and go back to stock.
                if rng.random() < 0.78:
                    product["stock"] += qty
                    product["returned"] += qty
                    cogs -= sale_cogs

        # Operating expense accrues every day. If it would breach the reserve,
        # the system records pressure but does not invent funding.
        daily_fixed = monthly_fixed / 30.0
        if cash - daily_fixed >= 0:
            cash -= daily_fixed
            operating_expenses += daily_fixed

        # Customer card buyback path.
        if rng.random() < float(cfg["buyback_chance"]):
            candidates = [p for p in products if p["category"] == "싱글카드"]
            if candidates:
                p = rng.choice(candidates)
                paid = round(p["sale"] * rng.uniform(0.50, 0.68))
                if cash - paid >= reserve:
                    old_qty = p["stock"]
                    new_cost_total = p["cost"] * old_qty + paid
                    p["stock"] += 1
                    p["buyback_added"] += 1
                    p["cost"] = new_cost_total / p["stock"]
                    cash -= paid
                    buyback_spend += paid
                    buyback_count += 1

        # Reorder low stock based on actual cumulative movement.
        for p in products:
            if p["stock"] <= 1 and p["sold"] >= 3:
                qty = min(10, max(3, int(p["sold"] / max(1, (day + 1) / 30.0) / 2) + 2))
                new_unit_cost = max(1000.0, p["cost"] * rng.uniform(0.96, 1.05))
                spend = new_unit_cost * qty
                if cash - spend >= reserve:
                    old_qty = p["stock"]
                    total_cost = p["cost"] * old_qty + new_unit_cost * qty
                    p["stock"] += qty
                    p["reordered"] += qty
                    p["cost"] = total_cost / p["stock"]
                    cash -= spend
                    reorder_spend += spend
                    reorder_count += 1
                else:
                    rejected_reorders += 1

        min_cash = min(min_cash, cash)
        daily.append({
            "day": day + 1,
            "orders": day_orders,
            "revenue": round(day_revenue),
            "cash": round(cash),
        })

    ending_inventory = sum(p["cost"] * p["stock"] for p in products)

    # Cash only tracks cash-flow transactions, so this equation is exact within rounding.
    expected_cash = (
        starting_cash
        - initial_inventory
        + revenue
        - fees
        - shipping
        - refunds
        - operating_expenses
        - reorder_spend
        - buyback_spend
    )

    # Inventory movement identity: initial + reorder + buyback additions - net sold.
    no_negative_stock = all(p["stock"] >= 0 for p in products)
    max_stock = max((p["stock"] for p in products), default=0)
    channels_exercised = sum(1 for v in channel_orders.values() if v > 0)

    checks = {
        "initial_inventory_within_budget": initial_inventory <= inventory_budget + 1.0,
        "no_negative_stock": no_negative_stock,
        "no_negative_cash": min_cash >= -1.0,
        "cash_equation": abs(cash - expected_cash) < 3.0,
        "orders_generated": orders > 0,
        "refund_path_exercised": refund_count > 0,
        "reorder_path_exercised": reorder_count > 0,
        "multi_channel_path": channels_exercised == len(cfg["channels"]),
        "product_catalog_preserved": len(products) == product_count,
        "inventory_values_finite": ending_inventory >= 0 and max_stock < 10_000,
    }
    if float(cfg["buyback_chance"]) >= 0.01:
        checks["buyback_path_exercised"] = buyback_count > 0

    warnings = []
    if min_cash < reserve:
        warnings.append("운영 중 현금이 설정한 안전예비금 아래로 내려간 구간이 있습니다.")
    if rejected_reorders:
        warnings.append(f"현금 예비금 때문에 재발주 {rejected_reorders}회가 보류되었습니다.")
    if stockout_events:
        warnings.append(f"전체 가용 재고가 부족한 주문 시점이 {stockout_events}회 있었습니다.")
    if cash < starting_cash * 0.15:
        warnings.append("종료 현금이 초기자금의 15% 미만입니다. 실제 운영에서는 자금 계획을 재검토해야 합니다.")
    if not warnings:
        warnings.append("무결성 기준상 특별한 운영 경고가 없습니다.")

    return {
        "profile_key": profile_key,
        "profile_label": cfg["label"],
        "description": cfg["description"],
        "seed": int(seed),
        "days": days,
        "starting_cash": round(starting_cash),
        "ending_cash": round(cash),
        "minimum_cash": round(min_cash),
        "inventory_budget": round(inventory_budget),
        "initial_inventory": round(initial_inventory),
        "ending_inventory": round(ending_inventory),
        "revenue": round(revenue),
        "fees": round(fees),
        "shipping": round(shipping),
        "refunds": round(refunds),
        "operating_expenses": round(operating_expenses),
        "reorder_spend": round(reorder_spend),
        "buyback_spend": round(buyback_spend),
        "orders": orders,
        "refund_count": refund_count,
        "reorder_count": reorder_count,
        "buyback_count": buyback_count,
        "rejected_reorders": rejected_reorders,
        "stockout_events": stockout_events,
        "channel_orders": channel_orders,
        "checks": checks,
        "warnings": warnings,
        "pass": all(checks.values()),
        "daily": daily,
    }


def run_release_readiness_suite(seeds_per_profile: int = 3) -> dict:
    seeds_per_profile = max(1, min(5, int(seeds_per_profile)))
    base_seed = 480_000
    results = []
    profile_summaries = []

    for profile_index, key in enumerate(STORE_SIM_PROFILES):
        runs = []
        for i in range(seeds_per_profile):
            seed = base_seed + profile_index * 100 + i
            report = run_store_profile_simulation(key, seed)
            runs.append(report)
            results.append(report)

        profile_summaries.append({
            "profile_key": key,
            "label": STORE_SIM_PROFILES[key]["label"],
            "description": STORE_SIM_PROFILES[key]["description"],
            "days": STORE_SIM_PROFILES[key]["days"],
            "runs": len(runs),
            "passes": sum(1 for r in runs if r["pass"]),
            "orders": sum(r["orders"] for r in runs),
            "refunds": sum(r["refund_count"] for r in runs),
            "reorders": sum(r["reorder_count"] for r in runs),
            "buybacks": sum(r["buyback_count"] for r in runs),
            "minimum_cash": min(r["minimum_cash"] for r in runs),
            "all_pass": all(r["pass"] for r in runs),
            "warnings": sorted({w for r in runs for w in r["warnings"]}),
        })

    total_checks = sum(len(r["checks"]) for r in results)
    passed_checks = sum(sum(1 for ok in r["checks"].values() if ok) for r in results)
    failed_checks = [
        {
            "profile": r["profile_label"],
            "seed": r["seed"],
            "check": name,
        }
        for r in results
        for name, ok in r["checks"].items()
        if not ok
    ]

    return {
        "suite": "TCG Shop Manager Release Readiness Simulation",
        "app_version": VERSION,
        "created_at": now(),
        "profiles": len(STORE_SIM_PROFILES),
        "seeds_per_profile": seeds_per_profile,
        "total_runs": len(results),
        "total_simulated_days": sum(r["days"] for r in results),
        "total_orders": sum(r["orders"] for r in results),
        "total_refunds": sum(r["refund_count"] for r in results),
        "total_reorders": sum(r["reorder_count"] for r in results),
        "total_buybacks": sum(r["buyback_count"] for r in results),
        "total_checks": total_checks,
        "passed_checks": passed_checks,
        "failed_checks": failed_checks,
        "score": round((passed_checks / total_checks * 100.0) if total_checks else 0.0, 1),
        "profile_summaries": profile_summaries,
        "pass": not failed_checks and all(p["all_pass"] for p in profile_summaries),
        "disclaimer": "합성 운영 무결성 시험입니다. 실제 시장수요·매출·세무 결과를 예측하거나 보증하지 않습니다.",
    }



def run_business_simulation(seed:int=20260901, days:int=30, starting_cash:int=8_000_000):
    import random
    rng=random.Random(seed)
    products=[]
    categories=['BOX','팩','싱글카드']
    # 초기재고는 초기자금의 약 55% 이내에서 구성한다. 나머지는 배송비·운영비·재발주를 위한 운전자금이다.
    inventory_budget=max(0, int(starting_cash*0.55))
    for i in range(30):
        cost=rng.randrange(7000,70001,1000)
        margin=rng.uniform(.18,.42)
        sale=int(round(cost*(1+margin)/1000)*1000)
        products.append({'id':i+1,'name':f'연습상품 {i+1:02d}','category':categories[i%3],'cost':float(cost),'sale':sale,'stock':1,'sold':0,'reordered':0})
    # 30종을 최소 1개씩 확보한 뒤 남는 예산 안에서만 추가 재고를 배분한다.
    baseline=sum(p['cost'] for p in products)
    remaining_budget=max(0, inventory_budget-baseline)
    indices=list(range(len(products)))
    rng.shuffle(indices)
    progressed=True
    while progressed and remaining_budget>=7000:
        progressed=False
        rng.shuffle(indices)
        for idx in indices:
            p=products[idx]
            if p['stock']>=14 or p['cost']>remaining_budget:
                continue
            p['stock']+=1
            remaining_budget-=p['cost']
            progressed=True
            if remaining_budget<7000:
                break
    cash=float(starting_cash)
    initial_inventory=sum(p['cost']*p['stock'] for p in products)
    cash-=initial_inventory
    min_cash=cash
    revenue=fees=shipping=refunds=expenses=buybacks=reorder_spend=0.0
    orders=refund_count=reorder_count=buyback_count=0
    daily=[]
    for d in range(days):
        day_orders=rng.randint(2,8)
        actual_orders=0
        day_rev=0
        for _ in range(day_orders):
            available=[p for p in products if p['stock']>0]
            if not available: break
            p=rng.choice(available)
            qty=1 if p['category']=='싱글카드' else rng.randint(1,min(2,p['stock']))
            p['stock']-=qty;p['sold']+=qty;gross=p['sale']*qty
            fee=round(gross*rng.uniform(.02,.055)); ship=3000
            revenue+=gross;fees+=fee;shipping+=ship;cash+=gross-fee-ship;day_rev+=gross;orders+=1;actual_orders+=1
            if rng.random()<0.035:
                amt=int(gross*rng.uniform(.4,1.0)); refunds+=amt;cash-=amt;refund_count+=1
                if rng.random()<0.7: p['stock']+=qty
        if d in (5,12,19,26):
            exp=rng.randrange(20000,70001,5000)
            if cash-exp>=300000:
                expenses+=exp;cash-=exp
        if d in (9,21):
            p=rng.choice(products); paid=int(p['sale']*.62)
            if cash-paid>=300000:
                old_stock=p['stock']; p['stock']+=1
                new_total=p['cost']*old_stock+paid; p['cost']=round(new_total/p['stock'],2)
                buybacks+=paid;cash-=paid;buyback_count+=1
        for p in products:
            if p['stock']<=1 and p['sold']>=3:
                qty=max(3,min(8,p['sold']//2+2)); spend=float(p['cost']*qty)
                if cash-spend>=500000:
                    cash-=spend;reorder_spend+=spend;p['stock']+=qty;p['reordered']+=qty;reorder_count+=1
        min_cash=min(min_cash,cash)
        daily.append({'day':d+1,'orders':actual_orders,'revenue':day_rev,'cash':round(cash)})
    inventory_value=sum(p['cost']*p['stock'] for p in products)
    # 시뮬레이션의 순이익은 운영 판단용 추정치이며 세무 회계값이 아니다.
    cogs=sum(p['cost']*p['sold'] for p in products)
    net_profit=revenue-cogs-fees-shipping-refunds-expenses
    expected_cash=starting_cash-initial_inventory+revenue-fees-shipping-refunds-expenses-buybacks-reorder_spend
    checks={
      'initial_inventory_within_budget': initial_inventory<=inventory_budget+0.01,
      'no_negative_stock': all(p['stock']>=0 for p in products),
      'no_negative_cash': min_cash>=0,
      'cash_equation': abs(cash-expected_cash)<2,
      'products_present':len(products)==30,
      'orders_generated':orders>0,
      'refund_path_exercised':refund_count>0,
      'reorder_path_exercised':reorder_count>0,
      'buyback_path_exercised':buyback_count>0,
    }
    return {'seed':seed,'days':days,'starting_cash':starting_cash,'inventory_budget':round(inventory_budget),'ending_cash':round(cash),'minimum_cash':round(min_cash),'initial_inventory':round(initial_inventory),'inventory_value':round(inventory_value),'revenue':round(revenue),'fees':round(fees),'shipping':round(shipping),'refunds':round(refunds),'expenses':round(expenses),'buybacks':round(buybacks),'reorder_spend':round(reorder_spend),'orders':orders,'refund_count':refund_count,'reorder_count':reorder_count,'buyback_count':buyback_count,'net_profit_estimate':round(net_profit),'checks':checks,'pass':all(checks.values()),'top_products':sorted(products,key=lambda x:x['sold'],reverse=True)[:8],'daily':daily}



def _auto_update_due(conn: sqlite3.Connection) -> bool:
    if setting(conn, "auto_update_check", "1") != "1":
        return False
    url = setting(conn, "update_manifest_url", "").strip()
    if not url:
        return False
    try:
        hours = max(1, min(168, int(setting(conn, "auto_update_check_hours", "6") or 6)))
    except Exception:
        hours = 6
    last = setting(conn, "last_update_check", "").strip()
    if not last:
        return True
    try:
        elapsed = datetime.now() - datetime.fromisoformat(last)
        return elapsed.total_seconds() >= hours * 3600
    except Exception:
        return True


def _auto_update_check_worker() -> None:
    try:
        time.sleep(1.0)
        conn = db()
        if not _auto_update_due(conn):
            conn.close()
            return
        url = setting(conn, "update_manifest_url", "").strip()
        install_id = setting(conn, "install_id", "")
        channel = setting(conn, "update_channel", "stable")
        conn.close()
        info = _fetch_update_manifest(url, install_id, channel)
        conn = db()
        _store_update_info(conn, info)
        set_setting(conn, "last_update_auto_error", "")
        audit(conn, "UPDATE_AUTO_CHECK", f"latest={info.get('version','')}")
        conn.commit(); conn.close()
    except Exception as exc:
        try:
            conn = db(); set_setting(conn, "last_update_check", now()); set_setting(conn, "last_update_auto_error", type(exc).__name__); conn.commit(); conn.close()
        except Exception:
            pass


def _start_auto_update_check() -> None:
    threading.Thread(target=_auto_update_check_worker, name="tcg-update-check", daemon=True).start()

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db(); maybe_auto_backup(); _start_auto_update_check(); yield

app = FastAPI(title=APP_NAME, version=VERSION, lifespan=lifespan)
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
app.mount("/media", StaticFiles(directory=PRODUCT_IMAGE_DIR), name="media")
templates = Jinja2Templates(directory=BASE_DIR / "templates")
templates.env.filters["won"] = won
templates.env.filters["pct"] = pct


@app.exception_handler(HTTPException)
async def http_exception_page(request: Request, exc: HTTPException):
    if request.url.path.startswith("/api/"):
        return JSONResponse({"detail": str(exc.detail)}, status_code=exc.status_code)
    conn = db()
    shop = setting(conn, "shop_name", "TCG Shop Manager")
    conn.close()
    return templates.TemplateResponse(
        request=request,
        name="error.html",
        context={
            "shop_name": shop,
            "version": VERSION,
            "code": exc.status_code,
            "message": str(exc.detail),
            "support_id": "",
        },
        status_code=exc.status_code,
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_page(request: Request, exc: RequestValidationError):
    if request.url.path.startswith("/api/"):
        return JSONResponse({"detail": "입력값을 확인해주세요."}, status_code=422)
    conn = db()
    shop = setting(conn, "shop_name", "TCG Shop Manager")
    conn.close()
    return templates.TemplateResponse(
        request=request,
        name="error.html",
        context={
            "shop_name": shop,
            "version": VERSION,
            "code": 422,
            "message": "입력한 내용을 다시 확인해주세요. 필수 항목이 비어 있거나 형식이 올바르지 않습니다.",
            "support_id": "",
        },
        status_code=422,
    )


@app.exception_handler(Exception)
async def unexpected_exception_page(request: Request, exc: Exception):
    support_id = datetime.now().strftime("%Y%m%d-%H%M%S-") + secrets.token_hex(3)
    try:
        log_file = DATA_DIR / "logs" / "app_errors.log"
        with log_file.open("a", encoding="utf-8") as f:
            f.write(f"\\n[{now()}] support_id={support_id} path={request.url.path}\\n")
            f.write("".join(traceback.format_exception(type(exc), exc, exc.__traceback__)))
    except Exception:
        pass
    conn = db()
    shop = setting(conn, "shop_name", "TCG Shop Manager")
    conn.close()
    return templates.TemplateResponse(
        request=request,
        name="error.html",
        context={
            "shop_name": shop,
            "version": VERSION,
            "code": 500,
            "message": "예상하지 못한 오류가 발생했습니다. 매장 데이터는 그대로 보존됩니다.",
            "support_id": support_id,
        },
        status_code=500,
    )




def _onboarding_complete(conn: sqlite3.Connection) -> bool:
    return setting(conn, "onboarding_completed", "1") == "1"


def _active_owner_count(conn: sqlite3.Connection) -> int:
    return int(conn.execute(
        "SELECT COUNT(*) c FROM staff_users WHERE role='owner' AND active=1"
    ).fetchone()["c"])




def _b64u_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _b64u_decode(value: str) -> bytes:
    value = value.strip()
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def verify_license_token(token: str, install_id: str) -> dict:
    token = (token or "").strip()
    parts = token.split(".")
    if len(parts) != 3 or parts[0] != "TCG5":
        raise ValueError("라이선스 키 형식이 올바르지 않습니다.")
    try:
        payload_raw = _b64u_decode(parts[1])
        signature = _b64u_decode(parts[2])
        payload = json.loads(payload_raw.decode("utf-8"))
    except Exception as exc:
        raise ValueError("라이선스 키를 읽을 수 없습니다.") from exc

    if not LICENSE_PUBLIC_KEY_FILE.exists():
        raise ValueError("라이선스 공개키 파일이 없습니다.")
    try:
        public_key = serialization.load_pem_public_key(LICENSE_PUBLIC_KEY_FILE.read_bytes())
        if not isinstance(public_key, Ed25519PublicKey):
            raise ValueError("라이선스 공개키 형식 오류")
        public_key.verify(signature, payload_raw)
    except InvalidSignature as exc:
        raise ValueError("라이선스 서명이 유효하지 않습니다.") from exc

    if payload.get("product") != "tcg-shop-manager":
        raise ValueError("다른 제품용 라이선스입니다.")
    if int(payload.get("format", 0)) != 1:
        raise ValueError("지원하지 않는 라이선스 형식입니다.")
    if payload.get("type") != "perpetual":
        raise ValueError("영구 라이선스가 아닙니다.")
    licensed_install = str(payload.get("install_id", "")).strip()
    if not licensed_install or licensed_install != str(install_id).strip():
        raise ValueError("이 PC의 설치 ID와 라이선스가 일치하지 않습니다.")
    if not str(payload.get("holder", "")).strip():
        raise ValueError("라이선스 사용자 정보가 없습니다.")
    if not str(payload.get("license_id", "")).strip():
        raise ValueError("라이선스 ID가 없습니다.")
    return payload


def _trial_days_left(conn: sqlite3.Connection) -> int:
    started = _parse_dt(setting(conn, "trial_started_at", ""))
    if not started:
        started = datetime.now()
        set_setting(conn, "trial_started_at", started.isoformat(timespec="seconds"))
    elapsed = max(0, (datetime.now() - started).days)
    return max(0, TRIAL_DAYS - elapsed)


def _license_state(conn: sqlite3.Connection) -> dict:
    install_id = setting(conn, "install_id", "")
    token = setting(conn, "license_key", "").strip()
    enforcement = setting(conn, "license_enforcement", "0") == "1"
    if token:
        try:
            payload = verify_license_token(token, install_id)
            return {
                "state": "licensed",
                "valid": True,
                "enforced": enforcement,
                "label": "영구 라이선스 활성",
                "holder": str(payload.get("holder", "")),
                "license_id": str(payload.get("license_id", "")),
                "issued_at": str(payload.get("issued_at", "")),
                "trial_days_left": 0,
                "message": "이 설치에 유효한 서명 라이선스가 적용되어 있습니다.",
            }
        except Exception as exc:
            return {
                "state": "invalid",
                "valid": False,
                "enforced": enforcement,
                "label": "라이선스 확인 필요",
                "holder": setting(conn, "license_holder", ""),
                "license_id": setting(conn, "license_id", ""),
                "issued_at": setting(conn, "license_issued_at", ""),
                "trial_days_left": _trial_days_left(conn),
                "message": str(exc),
            }

    if not enforcement:
        return {
            "state": "legacy",
            "valid": True,
            "enforced": False,
            "label": "기존 설치 · 라이선스 전환 대기",
            "holder": "",
            "license_id": "",
            "issued_at": "",
            "trial_days_left": 0,
            "message": "v5.0 이전부터 사용하던 설치는 갑자기 잠기지 않도록 라이선스 강제를 유예합니다.",
        }

    days_left = _trial_days_left(conn)
    return {
        "state": "trial" if days_left > 0 else "expired",
        "valid": days_left > 0,
        "enforced": True,
        "label": f"평가판 · {days_left}일 남음" if days_left > 0 else "평가 기간 종료",
        "holder": "",
        "license_id": "",
        "issued_at": "",
        "trial_days_left": days_left,
        "message": "평가 기간 동안 전체 기능을 사용할 수 있습니다." if days_left > 0 else "라이선스를 등록하면 기존 데이터 그대로 운영을 계속할 수 있습니다.",
    }


def _sync_license_settings(conn: sqlite3.Connection) -> dict:
    state = _license_state(conn)
    set_setting(conn, "license_status", state["label"])
    if state["state"] == "licensed":
        set_setting(conn, "license_holder", state["holder"])
        set_setting(conn, "license_id", state["license_id"])
        set_setting(conn, "license_issued_at", state["issued_at"])
        set_setting(conn, "license_verified_at", now())
    return state



def context_base(conn: sqlite3.Connection, active: str):
    plugin_menu = []
    try:
        plugin_menu = [dict(r) for r in _plugin_registry(conn, enabled_only=True)]
    except sqlite3.Error:
        plugin_menu = []
    return {
        "active": active,
        "version": VERSION,
        "shop_name": setting(conn, "shop_name", "내 TCG 온라인샵"),
        "role_labels": ROLE_LABELS,
        "plugin_menu": plugin_menu,
        "license_state": _license_state(conn),
    }


@app.middleware("http")
async def staff_auth_middleware(request: Request, call_next):
    path = request.url.path
    if path.startswith("/static/") or path.startswith("/media/") or path in {"/health", "/login", "/logout", "/system/shutdown"} or path.startswith("/setup") or path.startswith("/signup"):
        return await call_next(request)
    conn = db()
    try:
        onboarding_complete = _onboarding_complete(conn)
        enabled = setting(conn, "auth_enabled", "0") == "1"
        active_users = int(conn.execute("SELECT COUNT(*) c FROM staff_users WHERE active=1").fetchone()["c"])
    finally:
        conn.close()
    if not onboarding_complete:
        return RedirectResponse("/login", status_code=303)
    if not enabled or active_users == 0:
        request.session["permissions"] = ["*"]
        request.session.setdefault("display_name", "로컬 관리자")
        token = CURRENT_ACTOR.set({"id": None, "username": "local-admin"})
        try:
            return await call_next(request)
        finally:
            CURRENT_ACTOR.reset(token)
    uid = request.session.get("user_id")
    if not uid:
        return RedirectResponse(f"/login?next={request.url.path}", status_code=303)
    conn = db()
    user = conn.execute("SELECT * FROM staff_users WHERE id=? AND active=1", (uid,)).fetchone()
    if not user:
        conn.close(); request.session.clear(); return RedirectResponse("/login", 303)
    perms = _user_permissions(conn, int(user["id"]), str(user["role"]))
    conn.close()
    request.session["permissions"] = sorted(perms)
    request.session["display_name"] = user["display_name"]
    request.session["role"] = user["role"]
    needed = _route_permission(path)
    if path.startswith("/plugin/"):
        parts = [p for p in path.split("/") if p]
        if len(parts) >= 2:
            needed = _plugin_permission(parts[1])
    if needed and needed not in perms:
        err_conn = db()
        try:
            err_ctx = context_base(err_conn, "")
        finally:
            err_conn.close()
        err_ctx.update(code=403, message="이 메뉴에 접근할 권한이 없습니다.", support_id="")
        return templates.TemplateResponse(
            request=request,
            name="error.html",
            context=err_ctx,
            status_code=403,
        )
    token = CURRENT_ACTOR.set({"id": int(user["id"]), "username": str(user["username"])})
    try:
        return await call_next(request)
    finally:
        CURRENT_ACTOR.reset(token)




@app.middleware("http")
async def commercial_license_guard(request: Request, call_next):
    if request.method.upper() not in {"POST", "PUT", "PATCH", "DELETE"}:
        return await call_next(request)

    path = request.url.path
    allowed_when_expired = (
        path.startswith("/license/")
        or path in {"/license/save", "/system/shutdown"}
        or path.startswith("/backup/")
        or path.startswith("/support/diagnostics")
        or path.startswith("/export/")
        or path.startswith("/login")
        or path.startswith("/logout")
        or path.startswith("/setup")
        or path.startswith("/signup")
    )
    if allowed_when_expired:
        return await call_next(request)

    conn = db()
    try:
        state = _license_state(conn)
        if state["valid"]:
            return await call_next(request)
        ctx = context_base(conn, "")
    finally:
        conn.close()

    ctx.update(
        code=402,
        message="평가 기간이 종료되었거나 라이선스를 확인할 수 없습니다. 설정 · 백업에서 영구 라이선스를 등록해주세요.",
        support_id="",
    )
    return templates.TemplateResponse(
        request=request,
        name="error.html",
        context=ctx,
        status_code=402,
    )


@app.middleware("http")
async def local_mutation_origin_guard(request: Request, call_next):
    """Block cross-site browser POSTs against the local management server."""
    if request.method.upper() in {"POST", "PUT", "PATCH", "DELETE"}:
        fetch_site = (request.headers.get("sec-fetch-site") or "").lower()
        if fetch_site == "cross-site":
            conn = db()
            try:
                ctx = context_base(conn, "")
            finally:
                conn.close()
            ctx.update(code=403, message="외부 웹사이트에서 시작된 요청을 차단했습니다.", support_id="")
            return templates.TemplateResponse(
                request=request, name="error.html", context=ctx, status_code=403
            )

        expected_host = request.url.netloc.lower()
        for header_name in ("origin", "referer"):
            raw = (request.headers.get(header_name) or "").strip()
            if not raw:
                continue
            try:
                from urllib.parse import urlparse
                parsed = urlparse(raw)
                source_host = parsed.netloc.lower()
            except Exception:
                source_host = ""
            if source_host and source_host != expected_host:
                conn = db()
                try:
                    ctx = context_base(conn, "")
                finally:
                    conn.close()
                ctx.update(code=403, message="외부 웹사이트에서 시작된 요청을 차단했습니다.", support_id="")
                return templates.TemplateResponse(
                    request=request, name="error.html", context=ctx, status_code=403
                )
            break
    return await call_next(request)


# Session middleware must wrap the authorization middleware so request.session exists.
app.add_middleware(SessionMiddleware, secret_key=_session_secret(), same_site="strict", https_only=False, max_age=60*60*12)



@app.get("/setup", response_class=HTMLResponse)
def setup_page(request: Request):
    conn = db()
    owner_count = _active_owner_count(conn)
    completed = _onboarding_complete(conn)
    conn.close()
    if owner_count == 0 and not completed:
        return RedirectResponse("/signup", 303)
    return RedirectResponse("/settings", 303)


@app.post("/setup")
def setup_submit(
    request: Request,
    shop_name: str = Form(...),
    owner_name: str = Form(...),
    username: str = Form(""),
    password: str = Form(""),
    auto_backup: str = Form("0"),
    enable_login: str = Form("0"),
    reorder_target_days: int = Form(21),
    stale_stock_days: int = Form(60),
):
    shop_name = shop_name.strip()
    owner_name = owner_name.strip()
    username = username.strip()
    if not shop_name:
        return RedirectResponse("/setup?error=shop_name", 303)
    if not owner_name:
        return RedirectResponse("/setup?error=owner_name", 303)

    conn = db()
    try:
        if _onboarding_complete(conn):
            return RedirectResponse("/settings", 303)

        owner_count = _active_owner_count(conn)
        if owner_count == 0:
            if len(username) < 3 or not re.fullmatch(r"[A-Za-z0-9_.-]+", username):
                return RedirectResponse("/setup?error=username", 303)
            if len(password) < 8:
                return RedirectResponse("/setup?error=password", 303)
            if conn.execute("SELECT 1 FROM staff_users WHERE username=? COLLATE NOCASE", (username,)).fetchone():
                return RedirectResponse("/setup?error=username_exists", 303)
            salt, digest = _password_hash(password)
            conn.execute(
                """INSERT INTO staff_users(
                    username,display_name,role,password_salt,password_hash,active,created_at,updated_at
                ) VALUES(?,?,?,?,?,'1',?,?)""",
                (username, owner_name, "owner", salt, digest, now(), now())
            )

        set_setting(conn, "shop_name", shop_name)
        set_setting(conn, "owner_name", owner_name)
        set_setting(conn, "auto_backup", "1" if auto_backup == "1" else "0")
        set_setting(conn, "reorder_target_days", str(max(7, min(90, reorder_target_days))))
        set_setting(conn, "stale_stock_days", str(max(30, min(365, stale_stock_days))))
        set_setting(conn, "auth_enabled", "1" if enable_login == "1" else "0")
        set_setting(conn, "onboarding_completed", "1")
        set_setting(conn, "getting_started_dismissed", "0")
        set_setting(conn, "schema_app_version", VERSION)
        audit(conn, "ONBOARDING_COMPLETE", f"shop={shop_name}")
        conn.commit()
    finally:
        conn.close()

    request.session.clear()
    if enable_login == "1":
        return RedirectResponse("/login", 303)
    return RedirectResponse("/", 303)



def _parse_dt(value: str) -> datetime | None:
    try:
        return datetime.fromisoformat(str(value))
    except Exception:
        return None


def _user_locked(user) -> tuple[bool, int]:
    until = _parse_dt(str(user["locked_until"] or ""))
    if not until:
        return False, 0
    remaining = int((until - datetime.now()).total_seconds())
    return remaining > 0, max(0, remaining)



@app.get("/signup", response_class=HTMLResponse)
def signup_page(request: Request, error: str = ""):
    conn = db()
    owner_count = _active_owner_count(conn)
    if owner_count > 0:
        conn.close()
        return RedirectResponse("/login", 303)
    ctx = {
        "version": VERSION,
        "error": error,
        "shop_name": setting(conn, "shop_name", ""),
        "owner_name": setting(conn, "owner_name", ""),
    }
    conn.close()
    return templates.TemplateResponse(request=request, name="signup.html", context=ctx)


@app.post("/signup")
def signup_submit(
    request: Request,
    shop_name: str = Form(...),
    owner_name: str = Form(...),
    username: str = Form(...),
    password: str = Form(...),
    password_confirm: str = Form(...),
    auto_backup: str = Form("1"),
    reorder_target_days: int = Form(21),
    stale_stock_days: int = Form(60),
):
    shop_name = shop_name.strip()
    owner_name = owner_name.strip()
    username = username.strip()

    conn = db()
    try:
        if _active_owner_count(conn) > 0:
            return RedirectResponse("/login", 303)

        if not shop_name:
            return RedirectResponse("/signup?error=shop_name", 303)
        if not owner_name:
            return RedirectResponse("/signup?error=owner_name", 303)
        if len(username) < 3 or not re.fullmatch(r"[A-Za-z0-9_.-]+", username):
            return RedirectResponse("/signup?error=username", 303)
        if len(password) < 8:
            return RedirectResponse("/signup?error=password", 303)
        if password != password_confirm:
            return RedirectResponse("/signup?error=password_confirm", 303)
        if conn.execute(
            "SELECT 1 FROM staff_users WHERE username=? COLLATE NOCASE",
            (username,),
        ).fetchone():
            return RedirectResponse("/signup?error=username_exists", 303)

        salt, digest = _password_hash(password)
        cur = conn.execute(
            """INSERT INTO staff_users(
                username,display_name,role,password_salt,password_hash,active,
                failed_login_count,locked_until,created_at,updated_at
            ) VALUES(?,?,?,?,?,1,0,'',?,?)""",
            (username, owner_name, "owner", salt, digest, now(), now()),
        )

        set_setting(conn, "shop_name", shop_name)
        set_setting(conn, "owner_name", owner_name)
        set_setting(conn, "auto_backup", "1" if auto_backup == "1" else "0")
        set_setting(conn, "reorder_target_days", str(max(7, min(90, reorder_target_days))))
        set_setting(conn, "stale_stock_days", str(max(30, min(365, stale_stock_days))))
        set_setting(conn, "auth_enabled", "1")
        set_setting(conn, "onboarding_completed", "1")
        set_setting(conn, "schema_app_version", VERSION)
        audit(conn, "OWNER_SIGNUP", f"#{cur.lastrowid} {username} shop={shop_name}")
        conn.commit()
    finally:
        conn.close()

    request.session.clear()
    return RedirectResponse("/login?registered=1", 303)


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request, next: str = "/", error: str = "", registered: int = 0):
    conn = db()
    owner_count = _active_owner_count(conn)
    onboarding_complete = _onboarding_complete(conn)
    raw_shop_name = setting(conn, "shop_name", "내 TCG 온라인샵")
    shop_name = "TCG Shop Manager" if owner_count == 0 and not onboarding_complete else raw_shop_name
    enabled = setting(conn, "auth_enabled", "0") == "1"
    conn.close()
    return templates.TemplateResponse(
        request=request,
        name="login.html",
        context={
            "shop_name": shop_name,
            "version": VERSION,
            "next": next if next.startswith("/") and not next.startswith("//") else "/",
            "error": error,
            "enabled": enabled,
            "can_signup": owner_count == 0,
            "registered": bool(registered),
        },
    )


@app.post("/login")
def login_submit(request: Request, username: str = Form(...), password: str = Form(...), next: str = Form("/")):
    username = username.strip()
    safe_next = next if next.startswith("/") and not next.startswith("//") else "/"
    conn = db()
    user = conn.execute(
        "SELECT * FROM staff_users WHERE username=? COLLATE NOCASE AND active=1",
        (username,)
    ).fetchone()

    if user:
        locked, remaining = _user_locked(user)
        if locked:
            conn.execute(
                "INSERT INTO staff_activity(user_id,username,action,detail,created_at) VALUES(?,?,?,?,?)",
                (user["id"], user["username"], "LOGIN_BLOCKED", f"잠금 상태 로그인 시도 · 약 {max(1, remaining//60 + 1)}분 남음", now())
            )
            conn.commit(); conn.close()
            return RedirectResponse(f"/login?error=locked&next={safe_next}", 303)

    valid = bool(user and _verify_password(password, user["password_salt"], user["password_hash"]))
    if not valid:
        if user:
            failures = int(user["failed_login_count"] or 0) + 1
            locked_until = ""
            error_code = "1"
            if failures >= 5:
                locked_until = (datetime.now() + timedelta(minutes=5)).isoformat(timespec="seconds")
                error_code = "locked"
            conn.execute(
                "UPDATE staff_users SET failed_login_count=?,locked_until=?,updated_at=? WHERE id=?",
                (failures, locked_until, now(), user["id"])
            )
            conn.execute(
                "INSERT INTO staff_activity(user_id,username,action,detail,created_at) VALUES(?,?,?,?,?)",
                (user["id"], user["username"], "LOGIN_FAILED", f"실패 {failures}회", now())
            )
            conn.commit(); conn.close()
            return RedirectResponse(f"/login?error={error_code}&next={safe_next}", 303)
        conn.close()
        return RedirectResponse(f"/login?error=1&next={safe_next}", 303)

    perms = _user_permissions(conn, int(user["id"]), str(user["role"]))
    conn.execute(
        "UPDATE staff_users SET last_login_at=?,failed_login_count=0,locked_until='',updated_at=? WHERE id=?",
        (now(), now(), user["id"])
    )
    conn.execute(
        "INSERT INTO staff_activity(user_id,username,action,detail,created_at) VALUES(?,?,?,?,?)",
        (user["id"], user["username"], "LOGIN", "로그인", now())
    )
    conn.commit(); conn.close()
    request.session.clear()
    request.session.update({
        "user_id": int(user["id"]),
        "username": user["username"],
        "display_name": user["display_name"],
        "role": user["role"],
        "permissions": sorted(perms)
    })
    return RedirectResponse(safe_next, 303)


@app.get("/logout")
def logout(request: Request):
    request.session.clear(); return RedirectResponse("/login", 303)


@app.get("/staff", response_class=HTMLResponse)
def staff_page(request: Request, saved: int = 0, need_owner: int = 0):
    conn = db()
    users = conn.execute("SELECT * FROM staff_users ORDER BY CASE role WHEN 'owner' THEN 0 WHEN 'manager' THEN 1 ELSE 2 END, display_name").fetchall()
    owner_count = int(conn.execute("SELECT COUNT(*) c FROM staff_users WHERE role='owner' AND active=1").fetchone()["c"])
    overrides = {int(u["id"]): {r["permission"]: int(r["allowed"]) for r in conn.execute("SELECT permission,allowed FROM staff_permissions WHERE user_id=?", (u["id"],)).fetchall()} for u in users}
    activities = conn.execute("SELECT * FROM staff_activity ORDER BY id DESC LIMIT 80").fetchall()
    ctx = context_base(conn, "staff")
    ctx.update(
        users=users,
        overrides=overrides,
        permissions=_all_permissions(conn),
        role_labels=ROLE_LABELS,
        role_presets=ROLE_PRESETS,
        activities=activities,
        auth_enabled=setting(conn,"auth_enabled","0")=="1",
        owner_count=owner_count,
        setup_required=(owner_count == 0),
        need_owner=bool(need_owner),
        saved=saved,
    )
    conn.close()
    return templates.TemplateResponse(request=request, name="staff.html", context=ctx)


@app.post("/staff/add")
def staff_add(display_name: str=Form(...), username: str=Form(...), password: str=Form(...), role: str=Form("staff")):
    display_name=display_name.strip(); username=username.strip()
    if role not in ROLE_PRESETS: raise HTTPException(400,"올바르지 않은 역할입니다.")
    if len(username)<3 or not re.fullmatch(r"[A-Za-z0-9_.-]+", username): raise HTTPException(400,"아이디는 영문/숫자/._- 조합 3자 이상이어야 합니다.")
    if len(password)<8: raise HTTPException(400,"비밀번호는 8자 이상이어야 합니다.")
    conn=db()
    owner_count=int(conn.execute("SELECT COUNT(*) c FROM staff_users WHERE role='owner' AND active=1").fetchone()["c"])
    if owner_count == 0:
        role = "owner"
    salt,digest=_password_hash(password)
    try:
        cur=conn.execute("INSERT INTO staff_users(username,display_name,role,password_salt,password_hash,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",(username,display_name,role,salt,digest,now(),now()))
        audit(conn,"STAFF_ADD",f"#{cur.lastrowid} {username} role={role}"); conn.commit()
    except sqlite3.IntegrityError:
        conn.rollback(); conn.close(); raise HTTPException(400,"이미 사용 중인 아이디입니다.")
    conn.close(); return RedirectResponse("/staff?saved=1",303)


@app.post("/staff/{uid}/save")
async def staff_save(uid: int, request: Request):
    form=await request.form(); display_name=str(form.get("display_name","")).strip(); role=str(form.get("role","staff")); active=1 if form.get("active")=="1" else 0
    if role not in ROLE_PRESETS: raise HTTPException(400,"올바르지 않은 역할입니다.")
    conn=db(); target=conn.execute("SELECT * FROM staff_users WHERE id=?",(uid,)).fetchone()
    if not target: conn.close(); raise HTTPException(404,"직원을 찾을 수 없습니다.")
    if target["role"]=="owner" and (role!="owner" or not active):
        owners=int(conn.execute("SELECT COUNT(*) c FROM staff_users WHERE role='owner' AND active=1 AND id!=?",(uid,)).fetchone()["c"])
        if owners<1: conn.close(); raise HTTPException(400,"활성 소유자 계정은 최소 1개가 필요합니다.")
    conn.execute("UPDATE staff_users SET display_name=?,role=?,active=?,updated_at=? WHERE id=?",(display_name,role,active,now(),uid))
    # Store only differences from role preset.
    conn.execute("DELETE FROM staff_permissions WHERE user_id=?",(uid,))
    base=set(ROLE_PRESETS[role]) | _plugin_role_defaults(conn, role)
    for key,_ in _all_permissions(conn):
        desired=form.get(f"perm_{key}")=="1"
        if desired != (key in base):
            conn.execute("INSERT INTO staff_permissions(user_id,permission,allowed) VALUES(?,?,?)",(uid,key,1 if desired else 0))
    audit(conn,"STAFF_EDIT",f"#{uid} role={role} active={active}"); conn.commit(); conn.close(); return RedirectResponse("/staff?saved=1",303)


@app.post("/staff/{uid}/make-owner")
def staff_make_owner(uid: int):
    conn = db()
    owner_count = int(conn.execute("SELECT COUNT(*) c FROM staff_users WHERE role='owner' AND active=1").fetchone()["c"])
    if owner_count > 0:
        conn.close()
        raise HTTPException(400, "이미 활성 소유자 계정이 있습니다.")
    target = conn.execute("SELECT * FROM staff_users WHERE id=?", (uid,)).fetchone()
    if not target:
        conn.close()
        raise HTTPException(404, "직원을 찾을 수 없습니다.")
    conn.execute("UPDATE staff_users SET role='owner',active=1,updated_at=? WHERE id=?", (now(), uid))
    conn.execute("DELETE FROM staff_permissions WHERE user_id=?", (uid,))
    audit(conn, "STAFF_BOOTSTRAP_OWNER", f"#{uid} {target['username']}")
    conn.commit()
    conn.close()
    return RedirectResponse("/staff?saved=1", 303)


@app.post("/staff/{uid}/password")
def staff_password(uid:int, password:str=Form(...)):
    if len(password)<8: raise HTTPException(400,"비밀번호는 8자 이상이어야 합니다.")
    salt,digest=_password_hash(password); conn=db(); cur=conn.execute("UPDATE staff_users SET password_salt=?,password_hash=?,failed_login_count=0,locked_until='',updated_at=? WHERE id=?",(salt,digest,now(),uid))
    if cur.rowcount!=1: conn.close(); raise HTTPException(404,"직원을 찾을 수 없습니다.")
    audit(conn,"STAFF_PASSWORD_RESET",f"#{uid}"); conn.commit(); conn.close(); return RedirectResponse("/staff?saved=1",303)


@app.post("/staff/auth")
def staff_auth(request: Request, enabled: int=Form(0)):
    conn=db()
    if enabled:
        owners=int(conn.execute("SELECT COUNT(*) c FROM staff_users WHERE role='owner' AND active=1").fetchone()["c"])
        if owners<1:
            conn.close()
            return RedirectResponse("/staff?need_owner=1",303)
    set_setting(conn,"auth_enabled","1" if enabled else "0")
    audit(conn,"AUTH_MODE", "enabled" if enabled else "disabled")
    conn.commit()
    conn.close()
    if enabled:
        request.session.clear()
        return RedirectResponse("/login",303)
    return RedirectResponse("/staff?saved=1",303)

@app.get("/health")
def health():
    conn=db()
    try:
        state=_license_state(conn)
        license_health=state["state"]
    finally:
        conn.close()
    return {"ok": True, "app_id": "tcg-shop-manager", "app": APP_NAME, "version": VERSION, "pid": os.getpid(), "base": str(BASE_DIR), "db": str(DB_PATH), "license_state": license_health}

def _terminate_server_process() -> None:
    try:
        os.kill(os.getpid(), signal.SIGTERM)
    except Exception:
        os._exit(0)


@app.post("/system/shutdown", response_class=HTMLResponse)
def system_shutdown(request: Request):
    host = request.client.host if request.client else ""
    if host not in {"127.0.0.1", "::1", "localhost"}:
        raise HTTPException(403, "로컬 컴퓨터에서만 프로그램을 종료할 수 있습니다.")
    threading.Timer(0.8, _terminate_server_process).start()
    return HTMLResponse(
        """<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>TCG Shop Manager 종료</title>
  <style>
    body{font-family:system-ui,sans-serif;background:#f5f7fb;color:#172033;display:grid;place-items:center;height:100vh;margin:0}
    .box{background:white;border:1px solid #e3e8ef;border-radius:18px;padding:34px 40px;box-shadow:0 14px 40px rgba(0,0,0,.08);text-align:center}
    h1{font-size:24px;margin:0 0 12px}p{font-size:15px;line-height:1.7;color:#657187;margin:0}
  </style>
</head>
<body><div class="box"><h1>프로그램을 종료하고 있습니다.</h1><p>잠시 후 서버가 완전히 종료됩니다.<br>이제 이 탭을 닫고 프로그램 폴더를 삭제해도 됩니다.</p></div></body>
</html>"""
    )


@app.post("/getting-started/dismiss")
def getting_started_dismiss():
    conn = db()
    set_setting(conn, "getting_started_dismissed", "1")
    audit(conn, "GETTING_STARTED_DISMISS", "commercial onboarding guide")
    conn.commit()
    conn.close()
    return RedirectResponse("/", 303)


@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request, period: int=30, top_by: str="qty"):
    conn = db(); today = date.today().isoformat(); month = today[:7]
    period = period if period in {7,30,90} else 30
    top_by = top_by if top_by in {"qty","revenue","profit"} else "qty"
    cutoff30 = (date.today()-timedelta(days=29)).isoformat()
    sales = conn.execute("""
      SELECT
       COALESCE(SUM(CASE WHEN substr(order_date,1,7)=? AND status!='취소' THEN gross_revenue END),0) month_revenue,
       COALESCE(SUM(CASE WHEN substr(order_date,1,7)=? AND status!='취소' THEN net_profit END),0) month_sales_profit
      FROM orders
    """, (month, month)).fetchone()
    month_expenses = conn.execute("SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE substr(expense_date,1,7)=?", (month,)).fetchone()["v"]
    inv = conn.execute("""SELECT COUNT(*) product_count, COALESCE(SUM(stock),0) stock_count,
      COALESCE(SUM(CASE WHEN active=1 AND stock<=low_stock_threshold THEN 1 ELSE 0 END),0) low_count,
      COALESCE(SUM(stock*avg_cost),0) inventory_value FROM products WHERE active=1""").fetchone()
    fulfillment = conn.execute("""SELECT
      COALESCE(SUM(CASE WHEN status='결제완료' THEN 1 ELSE 0 END),0) paid,
      COALESCE(SUM(CASE WHEN status='포장중' THEN 1 ELSE 0 END),0) packing,
      COALESCE(SUM(CASE WHEN status='발송완료' THEN 1 ELSE 0 END),0) shipped FROM orders""").fetchone()
    purchase_waiting = conn.execute("SELECT COUNT(*) c FROM purchases WHERE status='발주'").fetchone()["c"]
    k30 = conn.execute("""SELECT COUNT(*) order_count, COALESCE(SUM(gross_revenue),0) revenue, COALESCE(SUM(net_profit),0) net_profit
      FROM orders WHERE status!='취소' AND order_date>=?""", (cutoff30,)).fetchone()
    margin = float(k30['net_profit'] or 0)/float(k30['revenue'] or 1)*100 if float(k30['revenue'] or 0)>0 else 0
    rows = conn.execute("SELECT * FROM products WHERE active=1 ORDER BY stock ASC,name").fetchall()
    enriched = enrich_products(conn, rows)
    reorder = sorted([p for p in enriched if p['reorder_qty']>0], key=lambda p: (p['days_cover'] if p['days_cover'] is not None else 99999, -p['sold_30d']))[:4]
    stale_days = max(30, int(setting(conn,'stale_stock_days','60') or 60))
    stale_cutoff=(date.today()-timedelta(days=stale_days)).isoformat()
    stale_count=conn.execute("""SELECT COUNT(*) c FROM products p WHERE p.active=1 AND p.stock>0 AND NOT EXISTS(
      SELECT 1 FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.product_id=p.id AND o.status!='취소' AND o.order_date>=?)""",(stale_cutoff,)).fetchone()['c']
    # Dashboard trend + popular products (v3.6.1)
    trend_start=(date.today()-timedelta(days=period-1))
    trend_rows=conn.execute("""SELECT substr(order_date,1,10) d, COALESCE(SUM(gross_revenue),0) revenue, COALESCE(SUM(net_profit),0) profit
      FROM orders WHERE status!='취소' AND order_date>=? GROUP BY substr(order_date,1,10) ORDER BY d""",(trend_start.isoformat(),)).fetchall()
    trend_map={r['d']:(float(r['revenue'] or 0),float(r['profit'] or 0)) for r in trend_rows}
    trend=[]
    for i in range(period):
        d=trend_start+timedelta(days=i); rev,prof=trend_map.get(d.isoformat(),(0.0,0.0))
        trend.append({'date':d.isoformat(),'label':f"{d.month}/{d.day}",'revenue':rev,'profit':prof})
    chart_max=max([max(x['revenue'],x['profit'],0) for x in trend] or [1]) or 1
    def _points(key):
        n=max(1,len(trend)-1); pts=[]
        for i,x in enumerate(trend):
            px=10+(i/n)*580; py=170-(max(0,float(x[key]))/chart_max)*145
            pts.append(f"{px:.1f},{py:.1f}")
        return ' '.join(pts)
    chart_revenue_points=_points('revenue'); chart_profit_points=_points('profit')
    popular=conn.execute("""SELECT p.id,p.name,p.sku,p.image_filename,p.language,p.category,
        COALESCE(SUM(oi.quantity),0) qty, COALESCE(SUM(oi.revenue),0) revenue, COALESCE(SUM(oi.gross_profit),0) profit
      FROM order_items oi JOIN orders o ON o.id=oi.order_id JOIN products p ON p.id=oi.product_id
      WHERE o.status!='취소' AND o.order_date>=? GROUP BY p.id
      ORDER BY CASE WHEN ?='revenue' THEN revenue WHEN ?='profit' THEN profit ELSE qty END DESC, revenue DESC LIMIT 5""",(cutoff30,top_by,top_by)).fetchall()
    cashflow=cashflow_summary(conn); alerts=alert_items(conn)[:4]
    month_net=float(sales['month_sales_profit'])-float(month_expenses or 0)
    show_getting_started = (
        setting(conn, "getting_started_dismissed", "1") != "1"
        and int(inv["product_count"] or 0) == 0
    )
    ctx=context_base(conn,'dashboard')
    ctx.update(cashflow=cashflow, alerts=alerts, sales=sales, month_net=month_net, inv=inv, purchase_waiting=purchase_waiting,
               fulfillment=fulfillment, margin=margin, reorder=reorder, stale_count=stale_count, stale_days=stale_days,
               period=period, top_by=top_by, trend=trend, chart_max=chart_max, chart_revenue_points=chart_revenue_points,
               chart_profit_points=chart_profit_points, popular=popular, update_banner=_update_banner(conn),
               show_getting_started=show_getting_started)
    conn.close(); return templates.TemplateResponse(request=request,name='dashboard.html',context=ctx)

@app.get("/products", response_class=HTMLResponse)
def products(request: Request, q: str="", category: str="", language: str="", only_low: int=0, archived: int=0):
    conn=db(); sql="SELECT * FROM products WHERE active=?"; params=[0 if archived else 1]
    if q:
        sql += " AND (name LIKE ? OR set_name LIKE ? OR sku LIKE ? OR barcode LIKE ? OR card_number LIKE ?)"; like=f"%{q}%"; params += [like]*5
    if category: sql += " AND category=?"; params.append(category)
    if language: sql += " AND language=?"; params.append(language)
    if only_low and not archived: sql += " AND stock<=low_stock_threshold"
    sql += " ORDER BY id DESC"
    rows=conn.execute(sql,params).fetchall(); enriched=enrich_products(conn,rows) if not archived else [dict(r) for r in rows]
    map_counts={int(r['product_id']):int(r['c']) for r in conn.execute("SELECT product_id,COUNT(*) c FROM channel_product_mappings WHERE active=1 GROUP BY product_id").fetchall()}
    for item in enriched: item['channel_mapping_count']=map_counts.get(int(item['id']),0)
    ctx=context_base(conn,'products');ctx.update(products=enriched,q=q,category=category,language=language,only_low=only_low,archived=archived)
    conn.close();return templates.TemplateResponse(request=request,name='products.html',context=ctx)

@app.post("/products/add")
def product_add(name: str=Form(...), set_name: str=Form(""), category: str=Form("BOX"), language: str=Form("한국어"), sku: str=Form(""), barcode: str=Form(""), card_number: str=Form(""), rarity: str=Form(""), card_condition: str=Form(""), opening_cost: float=Form(0), sale_price: int=Form(0), stock: int=Form(0), low_stock_threshold: int=Form(2), notes: str=Form(""), image: UploadFile | None=File(None)):
    conn=db();image_filename=''
    try:
        final_sku=sku.strip() or generate_sku(conn,category,language,set_name)
        cur=conn.execute("""INSERT INTO products(name,set_name,category,language,sku,barcode,card_number,rarity,card_condition,avg_cost,sale_price,stock,low_stock_threshold,notes,image_filename,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(name.strip(),set_name.strip(),category,language,final_sku,barcode.strip(),card_number.strip(),rarity.strip(),card_condition.strip(),max(0,opening_cost),max(0,sale_price),max(0,stock),max(0,low_stock_threshold),notes.strip(),'',now(),now()))
        pid=cur.lastrowid;image_filename=_save_product_image(pid,image)
        if image_filename:conn.execute("UPDATE products SET image_filename=? WHERE id=?",(image_filename,pid))
        if stock>0:conn.execute("INSERT INTO inventory_movements(product_id,movement_type,quantity,unit_cost,reason,created_at) VALUES(?,?,?,?,?,?)",(pid,'초기재고',stock,max(0,opening_cost),'상품 등록 시 초기재고',now()))
        audit(conn,'PRODUCT_ADD',f'#{pid} {name} sku={final_sku}');conn.commit()
    except Exception:
        conn.rollback();_delete_product_image(image_filename);conn.close();raise
    conn.close();return RedirectResponse('/products',303)

@app.post("/products/{pid}/edit")
def product_edit(pid:int, name: str=Form(...), set_name: str=Form(""), category: str=Form("BOX"), language: str=Form("한국어"), sku: str=Form(""), barcode: str=Form(""), card_number: str=Form(""), rarity: str=Form(""), card_condition: str=Form(""), sale_price: int=Form(0), low_stock_threshold: int=Form(2), notes: str=Form(""), remove_image: str=Form("0"), image: UploadFile | None=File(None)):
    conn=db(); p=conn.execute("SELECT * FROM products WHERE id=? AND active=1",(pid,)).fetchone()
    if not p: conn.close(); raise HTTPException(404,"상품을 찾을 수 없습니다.")
    old_image=p['image_filename'] or ''; new_image=old_image; created_image=''
    try:
        if remove_image=='1': new_image=''
        uploaded=_save_product_image(pid,image)
        if uploaded:
            created_image=uploaded; new_image=uploaded
        cur=conn.execute("""UPDATE products SET name=?,set_name=?,category=?,language=?,sku=?,barcode=?,card_number=?,rarity=?,card_condition=?,sale_price=?,low_stock_threshold=?,notes=?,image_filename=?,updated_at=? WHERE id=? AND active=1""",(name.strip(),set_name.strip(),category,language,sku.strip(),barcode.strip(),card_number.strip(),rarity.strip(),card_condition.strip(),max(0,sale_price),max(0,low_stock_threshold),notes.strip(),new_image,now(),pid))
        if not cur.rowcount: raise HTTPException(404,"상품을 찾을 수 없습니다.")
        audit(conn,"PRODUCT_EDIT",f"#{pid} {name}"); conn.commit()
        if old_image and old_image!=new_image: _delete_product_image(old_image)
    except Exception:
        conn.rollback();
        if created_image: _delete_product_image(created_image)
        conn.close(); raise
    conn.close(); return RedirectResponse("/products",303)


@app.post("/products/{pid}/duplicate")
def product_duplicate(pid:int):
    conn=db();p=conn.execute("SELECT * FROM products WHERE id=?",(pid,)).fetchone()
    if not p:conn.close();raise HTTPException(404,'상품을 찾을 수 없습니다.')
    image_filename=''
    try:
        sku=generate_sku(conn,p['category'],p['language'],p['set_name'])
        cur=conn.execute("""INSERT INTO products(name,set_name,category,language,sku,barcode,card_number,rarity,card_condition,avg_cost,sale_price,stock,low_stock_threshold,notes,image_filename,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (f"{p['name']} 복사본",p['set_name'],p['category'],p['language'],sku,'',p['card_number'],p['rarity'],p['card_condition'],float(p['avg_cost']),int(p['sale_price']),0,int(p['low_stock_threshold']),p['notes'],'',now(),now()))
        new_id=cur.lastrowid
        if p['image_filename']:
            old=PRODUCT_IMAGE_DIR/Path(p['image_filename']).name
            if old.exists():
                image_filename=f"product_{new_id}_{datetime.now().strftime('%Y%m%d%H%M%S%f')}{old.suffix.lower()}";shutil.copy2(old,PRODUCT_IMAGE_DIR/image_filename);conn.execute("UPDATE products SET image_filename=? WHERE id=?",(image_filename,new_id))
        audit(conn,'PRODUCT_DUPLICATE',f'#{pid} -> #{new_id}');conn.commit()
    except Exception:
        conn.rollback();_delete_product_image(image_filename);conn.close();raise
    conn.close();return RedirectResponse('/products',303)

@app.post("/products/{pid}/adjust")
def product_adjust(pid:int, amount:int=Form(...), reason:str=Form("수동 재고 조정")):
    if amount==0: return RedirectResponse("/products",303)
    conn=db(); p=conn.execute("SELECT * FROM products WHERE id=? AND active=1",(pid,)).fetchone()
    if not p: conn.close(); raise HTTPException(404,"상품을 찾을 수 없습니다.")
    new=max(0,int(p['stock'])+amount); actual=new-int(p['stock'])
    conn.execute("UPDATE products SET stock=?,updated_at=? WHERE id=?",(new,now(),pid))
    conn.execute("INSERT INTO inventory_movements(product_id,movement_type,quantity,unit_cost,reason,created_at) VALUES(?,?,?,?,?,?)",(pid,"수동조정",actual,float(p['avg_cost']),reason.strip(),now()))
    audit(conn,"STOCK_ADJUST",f"#{pid} {actual:+d} / {reason}"); conn.commit(); conn.close(); return RedirectResponse("/products",303)

@app.post("/products/{pid}/archive")
def product_archive(pid:int):
    conn=db()
    cur=conn.execute("UPDATE products SET active=0,updated_at=? WHERE id=? AND active=1",(now(),pid))
    if not cur.rowcount:
        conn.close(); raise HTTPException(404,"활성 상품을 찾을 수 없습니다.")
    audit(conn,"PRODUCT_ARCHIVE",f"#{pid}"); conn.commit(); conn.close(); return RedirectResponse("/products",303)

@app.post("/products/{pid}/restore")
def product_restore(pid:int):
    conn=db()
    cur=conn.execute("UPDATE products SET active=1,updated_at=? WHERE id=? AND active=0",(now(),pid))
    if not cur.rowcount:
        conn.close(); raise HTTPException(404,"보관된 상품을 찾을 수 없습니다.")
    audit(conn,"PRODUCT_RESTORE",f"#{pid}"); conn.commit(); conn.close(); return RedirectResponse("/products?archived=1",303)

@app.get("/purchases", response_class=HTMLResponse)
def purchases(request:Request):
    conn=db(); rows=conn.execute("SELECT * FROM purchases ORDER BY id DESC").fetchall(); products=conn.execute("SELECT * FROM products WHERE active=1 ORDER BY name").fetchall(); suppliers=conn.execute("SELECT * FROM suppliers ORDER BY name").fetchall(); ctx=context_base(conn,"purchases");ctx.update(purchases=rows,products=products,suppliers=suppliers,today=date.today().isoformat());conn.close();return templates.TemplateResponse(request=request,name="purchases.html",context=ctx)

@app.post("/suppliers/add")
def supplier_add(name:str=Form(...),contact:str=Form(""),notes:str=Form("")):
    conn=db(); conn.execute("INSERT INTO suppliers(name,contact,notes,created_at) VALUES(?,?,?,?)",(name.strip(),contact.strip(),notes.strip(),now())); conn.commit(); conn.close(); return RedirectResponse("/purchases",303)

@app.post("/purchases/add")
async def purchase_add(request:Request):
    form=await request.form(); supplier_id_raw=str(form.get('supplier_id','')).strip(); supplier_id=int(supplier_id_raw) if supplier_id_raw else None; order_date=str(form.get('order_date') or date.today().isoformat()); shipping=max(0,int(form.get('shipping_cost') or 0)); other=max(0,int(form.get('other_cost') or 0)); memo=str(form.get('memo') or '').strip(); pids=form.getlist('product_id'); qtys=form.getlist('quantity'); costs=form.getlist('unit_cost')
    if not pids or not(len(pids)==len(qtys)==len(costs)): raise HTTPException(400,"발주 상품 형식이 올바르지 않습니다.")
    conn=db(); sup=conn.execute("SELECT * FROM suppliers WHERE id=?",(supplier_id,)).fetchone() if supplier_id else None; items=[]; subtotal=0
    for a,b,c in zip(pids,qtys,costs):
        pid=int(a);qty=max(1,int(b));unit=max(0,int(c));p=conn.execute("SELECT * FROM products WHERE id=? AND active=1",(pid,)).fetchone()
        if not p: conn.close(); raise HTTPException(400,f"상품 #{pid} 없음")
        line=qty*unit; subtotal+=line; items.append((pid,p['name'],qty,unit,line))
    total=subtotal+shipping+other; cur=conn.execute("INSERT INTO purchases(supplier_id,supplier_name,order_date,status,shipping_cost,other_cost,item_subtotal,total_cost,memo,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",(supplier_id,sup['name'] if sup else '',order_date,'발주',shipping,other,subtotal,total,memo,now())); purchase_id=cur.lastrowid
    extra=shipping+other
    for pid,name,qty,unit,line in items:
        alloc=(extra*(line/subtotal)) if subtotal else (extra/len(items)); landed=(line+alloc)/qty
        conn.execute("INSERT INTO purchase_items(purchase_id,product_id,product_name,quantity,unit_cost,line_cost,allocated_extra,landed_unit_cost) VALUES(?,?,?,?,?,?,?,?)",(purchase_id,pid,name,qty,unit,line,alloc,landed))
    audit(conn,"PURCHASE_CREATE",f"#{purchase_id} total={total}");conn.commit();conn.close();return RedirectResponse(f"/purchases/{purchase_id}",303)

@app.get("/purchases/{purchase_id}", response_class=HTMLResponse)
def purchase_detail(purchase_id:int,request:Request):
    conn=db(); p=conn.execute("SELECT * FROM purchases WHERE id=?",(purchase_id,)).fetchone();
    if not p: conn.close(); raise HTTPException(404,"발주를 찾을 수 없습니다.")
    items=conn.execute("SELECT * FROM purchase_items WHERE purchase_id=?",(purchase_id,)).fetchall();ctx=context_base(conn,"purchases");ctx.update(purchase=p,items=items);conn.close();return templates.TemplateResponse(request=request,name="purchase_detail.html",context=ctx)

@app.get("/purchases/{purchase_id}/edit", response_class=HTMLResponse)
def purchase_edit_page(purchase_id:int, request:Request):
    conn=db(); p=conn.execute("SELECT * FROM purchases WHERE id=?",(purchase_id,)).fetchone()
    if not p: conn.close(); raise HTTPException(404,"발주를 찾을 수 없습니다.")
    if p['status']=='취소': conn.close(); raise HTTPException(400,"취소된 발주는 수정할 수 없습니다.")
    items=conn.execute("SELECT * FROM purchase_items WHERE purchase_id=? ORDER BY id",(purchase_id,)).fetchall()
    products=conn.execute("SELECT * FROM products WHERE active=1 OR id IN (SELECT product_id FROM purchase_items WHERE purchase_id=?) ORDER BY name",(purchase_id,)).fetchall()
    suppliers=conn.execute("SELECT * FROM suppliers ORDER BY name").fetchall()
    ctx=context_base(conn,"purchases");ctx.update(purchase=p,items=items,products=products,suppliers=suppliers,full_edit=(p['status']=='발주'))
    conn.close();return templates.TemplateResponse(request=request,name="purchase_edit.html",context=ctx)

@app.post("/purchases/{purchase_id}/edit")
async def purchase_edit_save(purchase_id:int, request:Request):
    form=await request.form(); conn=db()
    try:
        conn.execute('BEGIN'); p=conn.execute("SELECT * FROM purchases WHERE id=?",(purchase_id,)).fetchone()
        if not p: raise ValueError("발주를 찾을 수 없습니다.")
        if p['status']=='취소': raise ValueError("취소된 발주는 수정할 수 없습니다.")
        supplier_id_raw=str(form.get('supplier_id','')).strip(); supplier_id=int(supplier_id_raw) if supplier_id_raw else None
        sup=conn.execute("SELECT * FROM suppliers WHERE id=?",(supplier_id,)).fetchone() if supplier_id else None
        order_date=str(form.get('order_date') or p['order_date']); memo=str(form.get('memo') or '').strip()
        # 입고완료 후에는 재고/평균원가를 건드리지 않는 기본 정보만 수정한다.
        if p['status']!='발주':
            received_date=str(form.get('received_date') or p['received_date']).strip()
            conn.execute("UPDATE purchases SET supplier_id=?,supplier_name=?,order_date=?,received_date=?,memo=? WHERE id=?",(supplier_id,sup['name'] if sup else '',order_date,received_date,memo,purchase_id))
            audit(conn,"PURCHASE_EDIT_META",f"#{purchase_id}");conn.commit();conn.close();return RedirectResponse(f"/purchases/{purchase_id}",303)

        shipping=max(0,int(form.get('shipping_cost') or 0)); other=max(0,int(form.get('other_cost') or 0)); pids=form.getlist('product_id'); qtys=form.getlist('quantity'); costs=form.getlist('unit_cost')
        if not pids or not(len(pids)==len(qtys)==len(costs)): raise ValueError("발주 상품 형식이 올바르지 않습니다.")
        items=[]; subtotal=0
        for a,b,c in zip(pids,qtys,costs):
            pid=int(a); qty=max(1,int(b)); unit=max(0,int(c)); prod=conn.execute("SELECT * FROM products WHERE id=?",(pid,)).fetchone()
            if not prod: raise ValueError(f"상품 #{pid} 없음")
            line=qty*unit; subtotal+=line; items.append((pid,prod['name'],qty,unit,line))
        total=subtotal+shipping+other
        conn.execute("UPDATE purchases SET supplier_id=?,supplier_name=?,order_date=?,shipping_cost=?,other_cost=?,item_subtotal=?,total_cost=?,memo=? WHERE id=?",(supplier_id,sup['name'] if sup else '',order_date,shipping,other,subtotal,total,memo,purchase_id))
        conn.execute("DELETE FROM purchase_items WHERE purchase_id=?",(purchase_id,))
        extra=shipping+other
        for pid,name,qty,unit,line in items:
            alloc=(extra*(line/subtotal)) if subtotal else (extra/len(items)); landed=(line+alloc)/qty
            conn.execute("INSERT INTO purchase_items(purchase_id,product_id,product_name,quantity,unit_cost,line_cost,allocated_extra,landed_unit_cost) VALUES(?,?,?,?,?,?,?,?)",(purchase_id,pid,name,qty,unit,line,alloc,landed))
        audit(conn,"PURCHASE_EDIT",f"#{purchase_id} total={total}");conn.commit()
    except Exception as e:
        conn.rollback();conn.close();raise HTTPException(400,str(e))
    conn.close();return RedirectResponse(f"/purchases/{purchase_id}",303)

@app.post("/purchases/{purchase_id}/receive")
def purchase_receive(purchase_id:int):
    conn=db();
    try:
        conn.execute('BEGIN'); p=conn.execute("SELECT * FROM purchases WHERE id=?",(purchase_id,)).fetchone()
        if not p: raise ValueError("발주를 찾을 수 없습니다.")
        if p['status']!='발주': raise ValueError("이미 입고 처리되었거나 취소된 발주입니다.")
        items=conn.execute("SELECT * FROM purchase_items WHERE purchase_id=?",(purchase_id,)).fetchall()
        for i in items:
            prod=conn.execute("SELECT * FROM products WHERE id=?",(i['product_id'],)).fetchone(); old_qty=int(prod['stock']); old_cost=float(prod['avg_cost']); add_qty=int(i['quantity']); add_cost=float(i['landed_unit_cost']); new_qty=old_qty+add_qty; new_cost=((old_qty*old_cost)+(add_qty*add_cost))/new_qty if new_qty else add_cost
            conn.execute("UPDATE products SET stock=?,avg_cost=?,updated_at=? WHERE id=?",(new_qty,new_cost,now(),i['product_id']))
            conn.execute("INSERT INTO inventory_movements(product_id,movement_type,quantity,unit_cost,reference_type,reference_id,reason,created_at) VALUES(?,?,?,?,?,?,?,?)",(i['product_id'],'입고',add_qty,add_cost,'purchase',purchase_id,'발주 입고',now()))
        conn.execute("UPDATE purchases SET status='입고완료',received_date=? WHERE id=?",(date.today().isoformat(),purchase_id));audit(conn,"PURCHASE_RECEIVE",f"#{purchase_id}");conn.commit()
    except Exception as e:
        conn.rollback();conn.close();raise HTTPException(400,str(e))
    conn.close();return RedirectResponse(f"/purchases/{purchase_id}",303)

@app.post("/purchases/{purchase_id}/cancel")
def purchase_cancel(purchase_id:int):
    conn=db();p=conn.execute("SELECT * FROM purchases WHERE id=?",(purchase_id,)).fetchone();
    if not p or p['status']!='발주': conn.close(); raise HTTPException(400,"취소 가능한 발주가 아닙니다.")
    conn.execute("UPDATE purchases SET status='취소' WHERE id=?",(purchase_id,));audit(conn,"PURCHASE_CANCEL",f"#{purchase_id}");conn.commit();conn.close();return RedirectResponse(f"/purchases/{purchase_id}",303)

@app.get("/orders", response_class=HTMLResponse)
def orders(request:Request,status:str="",imported:int=0,bulk:int=0):
    conn=db()
    if status and status not in set(ORDER_STATUSES)|{'취소'}:conn.close();raise HTTPException(400,'잘못된 주문 상태 필터입니다.')
    rows=conn.execute("SELECT * FROM orders WHERE status=? ORDER BY id DESC",(status,)).fetchall() if status else conn.execute("SELECT * FROM orders ORDER BY id DESC").fetchall()
    products=conn.execute("SELECT * FROM products WHERE active=1 AND stock>0 ORDER BY name").fetchall();channels=conn.execute("SELECT * FROM channel_profiles WHERE active=1 ORDER BY name").fetchall()
    counts=conn.execute("""SELECT COUNT(*) total,COALESCE(SUM(CASE WHEN status='결제완료' THEN 1 ELSE 0 END),0) paid,COALESCE(SUM(CASE WHEN status='포장중' THEN 1 ELSE 0 END),0) packing,COALESCE(SUM(CASE WHEN status='발송완료' THEN 1 ELSE 0 END),0) shipped,COALESCE(SUM(CASE WHEN status='거래완료' THEN 1 ELSE 0 END),0) done FROM orders""").fetchone()
    ctx=context_base(conn,'orders');ctx.update(orders=rows,products=products,channels=channels,today=date.today().isoformat(),status_filter=status,counts=counts,imported=imported,bulk=bulk)
    conn.close();return templates.TemplateResponse(request=request,name='orders.html',context=ctx)


@app.post("/orders/bulk-status")
async def order_bulk_status(request:Request):
    form=await request.form(); ids=[]
    for raw in form.getlist('order_id'):
        try: ids.append(int(raw))
        except Exception: pass
    status=str(form.get('status') or '').strip()
    if not ids: raise HTTPException(400,'선택한 주문이 없습니다.')
    if status not in ORDER_STATUSES: raise HTTPException(400,'일괄 변경 가능한 상태가 아닙니다.')
    conn=db()
    try:
        conn.execute('BEGIN');changed=0
        for oid in sorted(set(ids)):
            o=conn.execute("SELECT * FROM orders WHERE id=?",(oid,)).fetchone()
            if not o or o['status']=='취소':continue
            shipped_at=o['shipped_at'];completed_at=o['completed_at']
            if status=='발송완료' and not shipped_at:shipped_at=now()
            if status=='거래완료':
                if not shipped_at:shipped_at=now()
                if not completed_at:completed_at=now()
            if status in {'결제완료','포장중'}: completed_at=''
            conn.execute("UPDATE orders SET status=?,shipped_at=?,completed_at=?,updated_at=? WHERE id=?",(status,shipped_at,completed_at,now(),oid));changed+=1
        audit(conn,'ORDER_BULK_STATUS',f'{changed} orders -> {status}');conn.commit()
    except Exception as exc:
        conn.rollback();conn.close();raise HTTPException(400,str(exc))
    conn.close();return RedirectResponse(f'/orders?bulk={changed}',303)

@app.post("/orders/add")
async def order_add(request:Request):
    form=await request.form();channel=str(form.get('channel') or '직접입력');external=str(form.get('external_order_no') or '').strip();order_date=str(form.get('order_date') or date.today().isoformat());discount=max(0,int(form.get('discount') or 0));shipping_charged=max(0,int(form.get('shipping_charged') or 0));shipping_paid=max(0,int(form.get('shipping_paid') or 0));fee_rate=max(0,float(form.get('fee_rate') or 0));fixed_fee=max(0,int(form.get('fixed_fee') or 0));other=max(0,int(form.get('other_cost') or 0));memo=str(form.get('memo') or '').strip();pids=form.getlist('product_id');qtys=form.getlist('quantity');prices=form.getlist('unit_sale_price')
    if not pids or not(len(pids)==len(qtys)==len(prices)): raise HTTPException(400,"주문 상품 형식이 올바르지 않습니다.")
    conn=db();
    try:
        conn.execute('BEGIN'); items=[];items_revenue=0;cogs=0.0;requested={}
        for a,b,c in zip(pids,qtys,prices):
            pid=int(a);qty=max(1,int(b));price=max(0,int(c));p=conn.execute("SELECT * FROM products WHERE id=? AND active=1",(pid,)).fetchone()
            if not p: raise ValueError(f"상품 #{pid} 없음")
            requested[pid]=requested.get(pid,0)+qty
            if int(p['stock'])<requested[pid]: raise ValueError(f"{p['name']} 재고 부족: 현재 {p['stock']}개 / 주문 합계 {requested[pid]}개")
            rev=qty*price; item_cogs=qty*float(p['avg_cost']); items_revenue+=rev;cogs+=item_cogs;items.append((pid,p['name'],qty,price,float(p['avg_cost']),rev,item_cogs,rev-item_cogs))
        taxable=max(0,items_revenue-discount+shipping_charged); platform_fee=round(taxable*(fee_rate/100.0)+fixed_fee);gross_revenue=taxable;gross_profit=gross_revenue-cogs;net_profit=gross_profit-platform_fee-shipping_paid-other
        cur=conn.execute("""INSERT INTO orders(channel,external_order_no,order_date,status,items_revenue,discount,shipping_charged,gross_revenue,cogs,platform_fee,shipping_paid,other_cost,gross_profit,net_profit,fee_rate,fixed_fee,memo,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(channel,external,order_date,'결제완료',items_revenue,discount,shipping_charged,gross_revenue,cogs,platform_fee,shipping_paid,other,gross_profit,net_profit,fee_rate,fixed_fee,memo,now(),now()));oid=cur.lastrowid
        for pid,name,qty,price,ucost,rev,icogs,gp in items:
            conn.execute("INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_sale_price,unit_cost,revenue,cogs,gross_profit) VALUES(?,?,?,?,?,?,?,?,?)",(oid,pid,name,qty,price,ucost,rev,icogs,gp));conn.execute("UPDATE products SET stock=stock-?,updated_at=? WHERE id=?",(qty,now(),pid));conn.execute("INSERT INTO inventory_movements(product_id,movement_type,quantity,unit_cost,reference_type,reference_id,reason,created_at) VALUES(?,?,?,?,?,?,?,?)",(pid,'판매',-qty,ucost,'order',oid,channel,now()))
        audit(conn,"ORDER_CREATE",f"#{oid} revenue={gross_revenue} net={net_profit:.0f}");conn.commit()
    except Exception as e:
        conn.rollback();conn.close();raise HTTPException(400,str(e))
    conn.close();return RedirectResponse(f"/orders/{oid}",303)

@app.get("/orders/{oid}", response_class=HTMLResponse)
def order_detail(oid:int,request:Request):
    conn=db();o=conn.execute("SELECT * FROM orders WHERE id=?",(oid,)).fetchone();
    if not o:conn.close();raise HTTPException(404,"주문 없음")
    items=conn.execute("SELECT * FROM order_items WHERE order_id=?",(oid,)).fetchall();ctx=context_base(conn,"orders");ctx.update(order=o,items=items,couriers=COURIERS,statuses=ORDER_STATUSES);conn.close();return templates.TemplateResponse(request=request,name="order_detail.html",context=ctx)

@app.get("/orders/{oid}/edit", response_class=HTMLResponse)
def order_edit_page(oid:int, request:Request):
    conn=db(); o=conn.execute("SELECT * FROM orders WHERE id=?",(oid,)).fetchone()
    if not o: conn.close(); raise HTTPException(404,"주문 없음")
    if o['status']=='취소': conn.close(); raise HTTPException(400,"취소된 주문은 수정할 수 없습니다.")
    items=conn.execute("SELECT * FROM order_items WHERE order_id=? ORDER BY id",(oid,)).fetchall()
    products=conn.execute("SELECT * FROM products WHERE active=1 OR id IN (SELECT product_id FROM order_items WHERE order_id=?) ORDER BY name",(oid,)).fetchall()
    channels=conn.execute("SELECT * FROM channel_profiles WHERE active=1 OR name=? ORDER BY name",(o['channel'],)).fetchall()
    restored={}
    for i in items: restored[i['product_id']]=restored.get(i['product_id'],0)+int(i['quantity'])
    product_rows=[]
    for p in products:
        d=dict(p); d['editable_stock']=int(p['stock'])+restored.get(p['id'],0); product_rows.append(d)
    ctx=context_base(conn,"orders");ctx.update(order=o,items=items,products=product_rows,channels=channels,couriers=COURIERS)
    conn.close();return templates.TemplateResponse(request=request,name="order_edit.html",context=ctx)

@app.post("/orders/{oid}/edit")
async def order_edit_save(oid:int, request:Request):
    form=await request.form(); conn=db()
    try:
        conn.execute('BEGIN'); o=conn.execute("SELECT * FROM orders WHERE id=?",(oid,)).fetchone()
        if not o: raise ValueError("주문 없음")
        if o['status']=='취소': raise ValueError("취소된 주문은 수정할 수 없습니다.")
        old_items=conn.execute("SELECT * FROM order_items WHERE order_id=?",(oid,)).fetchall()
        old_qty={}; old_cost_num={}
        for i in old_items:
            pid=int(i['product_id']); q=int(i['quantity']); old_qty[pid]=old_qty.get(pid,0)+q; old_cost_num[pid]=old_cost_num.get(pid,0.0)+q*float(i['unit_cost'])
        old_unit_cost={pid:(old_cost_num[pid]/old_qty[pid]) for pid in old_qty}

        channel=str(form.get('channel') or '직접입력'); external=str(form.get('external_order_no') or '').strip(); order_date=str(form.get('order_date') or o['order_date']);discount=max(0,int(form.get('discount') or 0));shipping_charged=max(0,int(form.get('shipping_charged') or 0));shipping_paid=max(0,int(form.get('shipping_paid') or 0));fee_rate=max(0,float(form.get('fee_rate') or 0));fixed_fee=max(0,int(form.get('fixed_fee') or 0));other=max(0,int(form.get('other_cost') or 0));memo=str(form.get('memo') or '').strip();courier=str(form.get('courier') or '').strip();tracking_number=str(form.get('tracking_number') or '').strip();pids=form.getlist('product_id');qtys=form.getlist('quantity');prices=form.getlist('unit_sale_price')
        if not pids or not(len(pids)==len(qtys)==len(prices)): raise ValueError("주문 상품 형식이 올바르지 않습니다.")
        requested={}; raw=[]
        for a,b,c in zip(pids,qtys,prices):
            pid=int(a);qty=max(1,int(b));price=max(0,int(c));prod=conn.execute("SELECT * FROM products WHERE id=?",(pid,)).fetchone()
            if not prod: raise ValueError(f"상품 #{pid} 없음")
            if not int(prod['active']) and pid not in old_qty: raise ValueError(f"{prod['name']} 상품은 보관 처리되어 새로 추가할 수 없습니다.")
            requested[pid]=requested.get(pid,0)+qty
            available=int(prod['stock'])+old_qty.get(pid,0)
            if requested[pid]>available: raise ValueError(f"{prod['name']} 재고 부족: 수정 가능 {available}개 / 주문 합계 {requested[pid]}개")
            ucost=old_unit_cost.get(pid,float(prod['avg_cost']))
            raw.append((pid,prod['name'],qty,price,ucost))

        # 현재 재고에는 기존 주문의 판매 차감이 반영되어 있으므로, 신·구 수량 차이만 원자적으로 조정한다.
        for pid in set(old_qty)|set(requested):
            stock_delta=old_qty.get(pid,0)-requested.get(pid,0)
            if stock_delta:
                prod=conn.execute("SELECT * FROM products WHERE id=?",(pid,)).fetchone(); unit_cost=old_unit_cost.get(pid,float(prod['avg_cost']))
                conn.execute("UPDATE products SET stock=stock+?,updated_at=? WHERE id=?",(stock_delta,now(),pid))
                conn.execute("INSERT INTO inventory_movements(product_id,movement_type,quantity,unit_cost,reference_type,reference_id,reason,created_at) VALUES(?,?,?,?,?,?,?,?)",(pid,'판매수정',stock_delta,unit_cost,'order',oid,'주문 수정에 따른 재고 정정',now()))

        items_revenue=0;cogs=0.0;items=[]
        for pid,name,qty,price,ucost in raw:
            rev=qty*price; item_cogs=qty*ucost; items_revenue+=rev;cogs+=item_cogs;items.append((pid,name,qty,price,ucost,rev,item_cogs,rev-item_cogs))
        gross_revenue=max(0,items_revenue-discount+shipping_charged);platform_fee=round(gross_revenue*(fee_rate/100.0)+fixed_fee);gross_profit=gross_revenue-cogs;net_profit=gross_profit-platform_fee-shipping_paid-other
        conn.execute("UPDATE orders SET channel=?,external_order_no=?,order_date=?,items_revenue=?,discount=?,shipping_charged=?,gross_revenue=?,cogs=?,platform_fee=?,shipping_paid=?,other_cost=?,gross_profit=?,net_profit=?,fee_rate=?,fixed_fee=?,memo=?,courier=?,tracking_number=?,updated_at=? WHERE id=?",(channel,external,order_date,items_revenue,discount,shipping_charged,gross_revenue,cogs,platform_fee,shipping_paid,other,gross_profit,net_profit,fee_rate,fixed_fee,memo,courier,tracking_number,now(),oid))
        conn.execute("DELETE FROM order_items WHERE order_id=?",(oid,))
        for pid,name,qty,price,ucost,rev,icogs,gp in items:
            conn.execute("INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_sale_price,unit_cost,revenue,cogs,gross_profit) VALUES(?,?,?,?,?,?,?,?,?)",(oid,pid,name,qty,price,ucost,rev,icogs,gp))
        audit(conn,"ORDER_EDIT",f"#{oid} revenue={gross_revenue} net={net_profit:.0f}");conn.commit()
    except Exception as e:
        conn.rollback();conn.close();raise HTTPException(400,str(e))
    conn.close();return RedirectResponse(f"/orders/{oid}",303)

@app.post("/orders/{oid}/status")
def order_status(oid:int,status:str=Form(...),courier:str=Form(""),tracking_number:str=Form("")):
    if status not in ORDER_STATUSES: raise HTTPException(400,"잘못된 상태")
    conn=db(); o=conn.execute("SELECT * FROM orders WHERE id=?",(oid,)).fetchone()
    if not o: conn.close(); raise HTTPException(404,"주문 없음")
    if o['status']=='취소': conn.close(); raise HTTPException(400,"취소된 주문은 처리할 수 없습니다.")
    courier=(courier or o['courier'] or '').strip(); tracking_number=(tracking_number or o['tracking_number'] or '').strip()
    shipped_at=o['shipped_at'] or ''; completed_at=o['completed_at'] or ''
    if status=='발송완료' and not shipped_at: shipped_at=now()
    if status=='거래완료':
        if not shipped_at: shipped_at=now()
        if not completed_at: completed_at=now()
    if status in {'결제완료','포장중'}:
        shipped_at=''
        completed_at=''
    elif status=='발송완료':
        completed_at=''
    conn.execute("UPDATE orders SET status=?,courier=?,tracking_number=?,shipped_at=?,completed_at=?,updated_at=? WHERE id=?",(status,courier,tracking_number,shipped_at,completed_at,now(),oid))
    audit(conn,"ORDER_STATUS",f"#{oid} {status} {courier} {tracking_number}");conn.commit();conn.close();return RedirectResponse(f"/orders/{oid}",303)

@app.post("/orders/{oid}/cancel")
def order_cancel(oid:int):
    conn=db();
    try:
        conn.execute('BEGIN');o=conn.execute("SELECT * FROM orders WHERE id=?",(oid,)).fetchone()
        if not o:raise ValueError("주문 없음")
        if o['status']=='취소':raise ValueError("이미 취소됨")
        for i in conn.execute("SELECT * FROM order_items WHERE order_id=?",(oid,)).fetchall():
            conn.execute("UPDATE products SET stock=stock+?,updated_at=? WHERE id=?",(i['quantity'],now(),i['product_id']));conn.execute("INSERT INTO inventory_movements(product_id,movement_type,quantity,unit_cost,reference_type,reference_id,reason,created_at) VALUES(?,?,?,?,?,?,?,?)",(i['product_id'],'판매취소',i['quantity'],i['unit_cost'],'order',oid,'주문 취소',now()))
        conn.execute("UPDATE orders SET status='취소',updated_at=? WHERE id=?",(now(),oid));audit(conn,"ORDER_CANCEL",f"#{oid}");conn.commit()
    except Exception as e:
        conn.rollback();conn.close();raise HTTPException(400,str(e))
    conn.close();return RedirectResponse(f"/orders/{oid}",303)

@app.get("/expenses", response_class=HTMLResponse)
def expenses(request:Request):
    conn=db();rows=conn.execute("SELECT * FROM expenses ORDER BY expense_date DESC,id DESC").fetchall();month=date.today().isoformat()[:7];total=conn.execute("SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE substr(expense_date,1,7)=?",(month,)).fetchone()['v'];ctx=context_base(conn,"expenses");ctx.update(expenses=rows,month_total=total,today=date.today().isoformat());conn.close();return templates.TemplateResponse(request=request,name="expenses.html",context=ctx)

@app.post("/expenses/add")
def expense_add(expense_date:str=Form(...),category:str=Form("기타"),description:str=Form(...),amount:int=Form(...),memo:str=Form("")):
    conn=db();conn.execute("INSERT INTO expenses(expense_date,category,description,amount,memo,created_at) VALUES(?,?,?,?,?,?)",(expense_date,category,description.strip(),max(0,amount),memo.strip(),now()));audit(conn,"EXPENSE_ADD",f"{description} {amount}");conn.commit();conn.close();return RedirectResponse("/expenses",303)

@app.post("/expenses/{eid}/delete")
def expense_delete(eid:int):
    conn=db();conn.execute("DELETE FROM expenses WHERE id=?",(eid,));audit(conn,"EXPENSE_DELETE",f"#{eid}");conn.commit();conn.close();return RedirectResponse("/expenses",303)

@app.get("/reports", response_class=HTMLResponse)
def reports(request:Request):
    conn=db();cutoff30=(date.today()-timedelta(days=29)).isoformat();cutoff60=(date.today()-timedelta(days=59)).isoformat()
    monthly=conn.execute("""SELECT substr(order_date,1,7) month,COUNT(*) orders,SUM(gross_revenue) revenue,SUM(cogs) cogs,SUM(platform_fee+shipping_paid+other_cost) selling_cost,SUM(net_profit) sales_profit FROM orders WHERE status!='취소' GROUP BY substr(order_date,1,7) ORDER BY month DESC LIMIT 24""").fetchall()
    exp={r['month']:r['expense'] for r in conn.execute("SELECT substr(expense_date,1,7) month,SUM(amount) expense FROM expenses GROUP BY substr(expense_date,1,7)")};monthly2=[dict(r)|{'expense':exp.get(r['month'],0),'final_profit':float(r['sales_profit'] or 0)-exp.get(r['month'],0)} for r in monthly]
    channels=conn.execute("SELECT channel,COUNT(*) orders,SUM(gross_revenue) revenue,SUM(net_profit) profit FROM orders WHERE status!='취소' GROUP BY channel ORDER BY revenue DESC").fetchall()
    top=conn.execute("""SELECT oi.product_id,oi.product_name,SUM(oi.quantity) qty,SUM(oi.revenue) revenue,SUM(oi.gross_profit) gross_profit FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.status!='취소' GROUP BY oi.product_id,oi.product_name ORDER BY revenue DESC LIMIT 15""").fetchall()
    k=conn.execute("SELECT COUNT(*) orders,COALESCE(SUM(gross_revenue),0) revenue,COALESCE(SUM(net_profit),0) profit FROM orders WHERE status!='취소' AND order_date>=?",(cutoff30,)).fetchone(); aov=float(k['revenue'] or 0)/int(k['orders'] or 1) if int(k['orders'] or 0) else 0; margin=float(k['profit'] or 0)/float(k['revenue'] or 1)*100 if float(k['revenue'] or 0)>0 else 0
    inv=conn.execute("SELECT COALESCE(SUM(stock*avg_cost),0) cost_value,COALESCE(SUM(stock*sale_price),0) retail_value,COALESCE(SUM(stock),0) units FROM products WHERE active=1").fetchone()
    slow=conn.execute("""SELECT p.*,COALESCE(s.qty,0) sold_60 FROM products p LEFT JOIN (SELECT oi.product_id,SUM(oi.quantity) qty FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.status!='취소' AND o.order_date>=? GROUP BY oi.product_id) s ON s.product_id=p.id WHERE p.active=1 AND p.stock>0 ORDER BY sold_60 ASC,(p.stock*p.avg_cost) DESC LIMIT 12""",(cutoff60,)).fetchall()
    ctx=context_base(conn,'reports');ctx.update(monthly=monthly2,channels=channels,top=top,k30=k,aov=aov,margin=margin,inv=inv,slow=slow);conn.close();return templates.TemplateResponse(request=request,name='reports.html',context=ctx)

@app.get("/inventory-log", response_class=HTMLResponse)
def inventory_log(request:Request):
    conn=db();rows=conn.execute("SELECT m.*,p.name product_name FROM inventory_movements m JOIN products p ON p.id=m.product_id ORDER BY m.id DESC LIMIT 500").fetchall();ctx=context_base(conn,"inventory-log");ctx.update(rows=rows);conn.close();return templates.TemplateResponse(request=request,name="inventory_log.html",context=ctx)


@app.get("/connections", response_class=HTMLResponse)
def connections_page(request:Request, saved:int=0):
    conn=db();rows=conn.execute("""SELECT c.*,COALESCE(s.orders,0) order_count,COALESCE(s.revenue,0) revenue,COALESCE(m.mapping_count,0) mapping_count FROM channel_profiles c LEFT JOIN (SELECT channel,COUNT(*) orders,SUM(gross_revenue) revenue FROM orders WHERE status!='취소' GROUP BY channel) s ON s.channel=c.name LEFT JOIN (SELECT channel_id,COUNT(*) mapping_count FROM channel_product_mappings WHERE active=1 GROUP BY channel_id) m ON m.channel_id=c.id ORDER BY c.name""").fetchall();ctx=context_base(conn,'connections');ctx.update(channels=rows,saved=saved);conn.close();return templates.TemplateResponse(request=request,name='connections.html',context=ctx)

@app.post("/connections/{cid}/save")
def connection_save(cid:int,adapter_mode:str=Form('manual'),external_shop_id:str=Form(''),connector_notes:str=Form('')):
    if adapter_mode not in {'manual','csv','api'}:raise HTTPException(400,'지원하지 않는 연결 방식입니다.')
    status={'manual':'수동 운영','csv':'CSV 준비','api':'API 설정 필요'}[adapter_mode]
    conn=db();cur=conn.execute("UPDATE channel_profiles SET adapter_mode=?,external_shop_id=?,connector_notes=?,connector_status=? WHERE id=?",(adapter_mode,external_shop_id.strip(),connector_notes.strip(),status,cid))
    if not cur.rowcount:conn.close();raise HTTPException(404,'판매 채널을 찾을 수 없습니다.')
    audit(conn,'CONNECTOR_SAVE',f'#{cid} mode={adapter_mode}');conn.commit();conn.close();return RedirectResponse('/connections?saved=1',303)

@app.post("/connections/{cid}/mark-sync")
def connection_mark_sync(cid:int):
    conn=db();c=conn.execute("SELECT * FROM channel_profiles WHERE id=?",(cid,)).fetchone()
    if not c:conn.close();raise HTTPException(404,'판매 채널을 찾을 수 없습니다.')
    status='수동 확인 완료' if c['adapter_mode']=='manual' else ('CSV 확인 완료' if c['adapter_mode']=='csv' else 'API 설정 필요')
    conn.execute("UPDATE channel_profiles SET last_sync_at=?,connector_status=? WHERE id=?",(now(),status,cid));audit(conn,'CONNECTOR_CHECK',f'#{cid} {status}');conn.commit();conn.close();return RedirectResponse('/connections',303)

@app.get("/data-health", response_class=HTMLResponse)
def data_health(request:Request, fixed:int=0):
    conn=db();checks=[]
    integrity=conn.execute('PRAGMA integrity_check').fetchone()[0];checks.append({'name':'SQLite 데이터 무결성','ok':str(integrity).lower()=='ok','detail':str(integrity)})
    neg=conn.execute("SELECT COUNT(*) c FROM products WHERE stock<0").fetchone()['c'];checks.append({'name':'음수 재고','ok':neg==0,'detail':f'{neg}건'})
    dup=conn.execute("SELECT COUNT(*) c FROM (SELECT sku FROM products WHERE active=1 AND trim(sku)!='' GROUP BY sku HAVING COUNT(*)>1)").fetchone()['c'];checks.append({'name':'활성 상품 SKU 중복','ok':dup==0,'detail':f'{dup}개 SKU'})
    missing=conn.execute("SELECT COUNT(*) c FROM products WHERE active=1 AND trim(sku)='' ").fetchone()['c'];checks.append({'name':'SKU 미지정 상품','ok':missing==0,'detail':f'{missing}종'})
    orphan=conn.execute("SELECT COUNT(*) c FROM order_items oi LEFT JOIN orders o ON o.id=oi.order_id LEFT JOIN products p ON p.id=oi.product_id WHERE o.id IS NULL OR p.id IS NULL").fetchone()['c'];checks.append({'name':'주문 참조 무결성','ok':orphan==0,'detail':f'{orphan}건 오류'})
    badstatus=conn.execute("SELECT COUNT(*) c FROM orders WHERE status NOT IN ('결제완료','포장중','발송완료','거래완료','취소')").fetchone()['c'];checks.append({'name':'주문 상태 값','ok':badstatus==0,'detail':f'{badstatus}건 비정상'})
    missing_images=0
    for r in conn.execute("SELECT image_filename FROM products WHERE trim(image_filename)!=''"):
        if not (PRODUCT_IMAGE_DIR/Path(r['image_filename']).name).exists():missing_images+=1
    checks.append({'name':'상품 이미지 파일','ok':missing_images==0,'detail':f'{missing_images}건 누락'})
    last_backup=setting(conn,'last_backup_date','');checks.append({'name':'자동 백업 기록','ok':bool(last_backup),'detail':last_backup or '아직 백업 기록 없음'})
    ctx=context_base(conn,'data-health');ctx.update(checks=checks,all_ok=all(c['ok'] for c in checks),fixed=fixed);conn.close();return templates.TemplateResponse(request=request,name='data_health.html',context=ctx)

@app.post("/data-health/fix-skus")
def data_health_fix_skus():
    conn=db();rows=conn.execute("SELECT * FROM products WHERE active=1 AND trim(sku)='' ORDER BY id").fetchall();count=0
    for p in rows:
        conn.execute("UPDATE products SET sku=?,updated_at=? WHERE id=?",(generate_sku(conn,p['category'],p['language'],p['set_name']),now(),p['id']));count+=1
    audit(conn,'DATA_HEALTH_FIX_SKU',f'{count} products');conn.commit();conn.close();return RedirectResponse(f'/data-health?fixed={count}',303)


@app.get("/plugins", response_class=HTMLResponse)
def plugins_page(request: Request, installed: int = 0, saved: int = 0, error: str = ""):
    conn = db()
    rows = _plugin_registry(conn)
    ctx = context_base(conn, "plugins")
    ctx.update(plugins=rows, installed=installed, saved=saved, error=error, plugin_dir=str(PLUGIN_DIR))
    conn.close()
    return templates.TemplateResponse(request=request, name="plugins.html", context=ctx)


@app.post("/plugins/install")
async def plugin_install(file: UploadFile = File(...)):
    if Path(file.filename or "").suffix.lower() not in {".tcgplugin", ".zip"}:
        raise HTTPException(400, "기능팩 파일은 .tcgplugin 또는 .zip 형식이어야 합니다.")
    raw = await file.read()
    if len(raw) > 20 * 1024 * 1024:
        raise HTTPException(400, "기능팩은 20MB 이하만 지원합니다.")
    tmp = Path(tempfile.mkstemp(prefix="tcg_plugin_", suffix=".zip")[1])
    try:
        tmp.write_bytes(raw)
        with zipfile.ZipFile(tmp, "r") as z:
            names = z.namelist()
            if "manifest.json" not in names:
                raise HTTPException(400, "기능팩에 manifest.json이 없습니다.")
            for name in names:
                p = Path(name)
                if p.is_absolute() or ".." in p.parts:
                    raise HTTPException(400, "안전하지 않은 기능팩 경로가 포함되어 있습니다.")
            doc = json.loads(z.read("manifest.json").decode("utf-8"))
            plugin_id = _safe_plugin_id(str(doc.get("id","")))
            display_name = str(doc.get("name", plugin_id)).strip()[:100]
            plugin_version = str(doc.get("version","1.0.0")).strip()[:30]
            min_v = str(doc.get("min_app_version","")).strip()[:30]
            max_v = str(doc.get("max_app_version","")).strip()[:30]
            if min_v and _version_tuple(VERSION) < _version_tuple(min_v):
                raise HTTPException(400, f"이 기능팩은 TCG Shop Manager {min_v} 이상이 필요합니다.")
            if max_v and _version_tuple(VERSION) > _version_tuple(max_v):
                raise HTTPException(400, f"이 기능팩은 TCG Shop Manager {max_v} 이하에서만 사용할 수 있습니다.")
            fields = _plugin_fields(doc)
            if not fields:
                raise HTTPException(400, "기능팩에는 최소 1개의 데이터 필드가 필요합니다.")
            target = PLUGIN_DIR / plugin_id
            staged = Path(tempfile.mkdtemp(prefix="tcg_plugin_stage_", dir=str(PLUGIN_DIR)))
            try:
                z.extractall(staged)
                (staged / "manifest.json").write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
                if target.exists():
                    shutil.rmtree(target)
                staged.replace(target)
            finally:
                if staged.exists():
                    shutil.rmtree(staged, ignore_errors=True)
        conn = db()
        roles = doc.get("default_roles", ["owner","manager"])
        if not isinstance(roles, list):
            roles = ["owner","manager"]
        conn.execute(
            """INSERT INTO plugin_registry(plugin_id,display_name,version,description,menu_label,icon,min_app_version,max_app_version,default_roles,enabled,status,last_error,installed_at,updated_at)
               VALUES(?,?,?,?,?,?,?,?,?,0,'정상','',?,?)
               ON CONFLICT(plugin_id) DO UPDATE SET display_name=excluded.display_name,version=excluded.version,description=excluded.description,menu_label=excluded.menu_label,icon=excluded.icon,min_app_version=excluded.min_app_version,max_app_version=excluded.max_app_version,default_roles=excluded.default_roles,status='정상',last_error='',updated_at=excluded.updated_at""",
            (
                plugin_id, display_name, plugin_version, str(doc.get("description",""))[:500],
                str(doc.get("menu_label",display_name))[:80], str(doc.get("icon","◆"))[:8],
                min_v, max_v, ",".join(str(x) for x in roles if x in {"owner","manager","staff"}),
                now(), now()
            )
        )
        audit(conn, "PLUGIN_INSTALL", f"{plugin_id} v{plugin_version}")
        conn.commit(); conn.close()
        return RedirectResponse("/plugins?installed=1", 303)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, f"기능팩 설치 실패: {exc}")
    finally:
        try: tmp.unlink()
        except OSError: pass


@app.post("/plugins/{plugin_id}/toggle")
def plugin_toggle(plugin_id: str):
    plugin_id = _safe_plugin_id(plugin_id)
    conn = db()
    row = conn.execute("SELECT * FROM plugin_registry WHERE plugin_id=?", (plugin_id,)).fetchone()
    if not row:
        conn.close(); raise HTTPException(404, "기능팩을 찾을 수 없습니다.")
    target = 0 if int(row["enabled"]) else 1
    status = "정상"; err = ""
    if target:
        try:
            doc = _load_plugin_manifest(plugin_id)
            min_v = str(doc.get("min_app_version",""))
            max_v = str(doc.get("max_app_version",""))
            if min_v and _version_tuple(VERSION) < _version_tuple(min_v):
                raise ValueError(f"본체 {min_v} 이상 필요")
            if max_v and _version_tuple(VERSION) > _version_tuple(max_v):
                raise ValueError(f"본체 {max_v} 이하 필요")
            if not _plugin_fields(doc):
                raise ValueError("필드 정의 없음")
        except Exception as exc:
            target = 0; status = "오류 격리"; err = str(exc)[:500]
    conn.execute("UPDATE plugin_registry SET enabled=?,status=?,last_error=?,updated_at=? WHERE plugin_id=?", (target,status,err,now(),plugin_id))
    audit(conn, "PLUGIN_TOGGLE", f"{plugin_id} enabled={target} status={status}")
    conn.commit(); conn.close()
    return RedirectResponse("/plugins?saved=1", 303)


@app.post("/plugins/{plugin_id}/remove")
def plugin_remove(plugin_id: str):
    plugin_id = _safe_plugin_id(plugin_id)
    conn = db()
    row = conn.execute("SELECT * FROM plugin_registry WHERE plugin_id=?", (plugin_id,)).fetchone()
    if not row:
        conn.close(); raise HTTPException(404, "기능팩을 찾을 수 없습니다.")
    conn.execute("DELETE FROM staff_permissions WHERE permission=?", (_plugin_permission(plugin_id),))
    conn.execute("DELETE FROM plugin_registry WHERE plugin_id=?", (plugin_id,))
    audit(conn, "PLUGIN_REMOVE", plugin_id)
    conn.commit(); conn.close()
    shutil.rmtree(PLUGIN_DIR / plugin_id, ignore_errors=True)
    return RedirectResponse("/plugins?saved=1", 303)


@app.get("/plugin/{plugin_id}", response_class=HTMLResponse)
def plugin_workspace(plugin_id: str, request: Request, saved: int = 0):
    plugin_id = _safe_plugin_id(plugin_id)
    conn = db()
    row = conn.execute("SELECT * FROM plugin_registry WHERE plugin_id=? AND enabled=1 AND status='정상'", (plugin_id,)).fetchone()
    if not row:
        conn.close(); raise HTTPException(404, "활성 기능팩을 찾을 수 없습니다.")
    try:
        manifest = _load_plugin_manifest(plugin_id)
        fields = _plugin_fields(manifest)
    except Exception as exc:
        conn.execute("UPDATE plugin_registry SET enabled=0,status='오류 격리',last_error=?,updated_at=? WHERE plugin_id=?", (str(exc)[:500],now(),plugin_id))
        conn.commit(); conn.close()
        raise HTTPException(500, "기능팩을 안전하게 격리했습니다. 기능팩 관리 화면을 확인하세요.")
    records = conn.execute("SELECT * FROM plugin_records WHERE plugin_id=? ORDER BY id DESC LIMIT 200", (plugin_id,)).fetchall()
    decoded = []
    for rec in records:
        try: payload = json.loads(rec["payload_json"])
        except Exception: payload = {}
        decoded.append({"id":rec["id"],"payload":payload,"created_by":rec["created_by"],"created_at":rec["created_at"]})
    ctx = context_base(conn, f"plugin:{plugin_id}")
    ctx.update(plugin=dict(row), manifest=manifest, fields=fields, records=decoded, saved=saved)
    conn.close()
    return templates.TemplateResponse(request=request, name="plugin_workspace.html", context=ctx)


@app.post("/plugin/{plugin_id}/records/add")
async def plugin_record_add(plugin_id: str, request: Request):
    plugin_id = _safe_plugin_id(plugin_id)
    conn = db()
    row = conn.execute("SELECT * FROM plugin_registry WHERE plugin_id=? AND enabled=1", (plugin_id,)).fetchone()
    if not row:
        conn.close(); raise HTTPException(404, "활성 기능팩을 찾을 수 없습니다.")
    manifest = _load_plugin_manifest(plugin_id)
    fields = _plugin_fields(manifest)
    form = await request.form()
    payload = {}
    for f in fields:
        val = str(form.get(f["key"], "")).strip()
        if f["required"] and not val:
            conn.close(); raise HTTPException(400, f"{f['label']} 항목은 필수입니다.")
        if f["type"] == "number" and val:
            try: float(val)
            except ValueError:
                conn.close(); raise HTTPException(400, f"{f['label']} 항목은 숫자여야 합니다.")
        payload[f["key"]] = val
    actor = CURRENT_ACTOR.get()
    conn.execute("INSERT INTO plugin_records(plugin_id,payload_json,created_by,created_at,updated_at) VALUES(?,?,?,?,?)",
                 (plugin_id,json.dumps(payload,ensure_ascii=False),actor.get("username") or "local-admin",now(),now()))
    audit(conn, "PLUGIN_RECORD_ADD", plugin_id)
    conn.commit(); conn.close()
    return RedirectResponse(f"/plugin/{plugin_id}?saved=1", 303)


@app.post("/plugin/{plugin_id}/records/{record_id}/delete")
def plugin_record_delete(plugin_id: str, record_id: int):
    plugin_id = _safe_plugin_id(plugin_id)
    conn = db()
    conn.execute("DELETE FROM plugin_records WHERE id=? AND plugin_id=?", (record_id, plugin_id))
    audit(conn, "PLUGIN_RECORD_DELETE", f"{plugin_id} #{record_id}")
    conn.commit(); conn.close()
    return RedirectResponse(f"/plugin/{plugin_id}", 303)



def _append_query(url: str, params: dict[str, str]) -> str:
    from urllib.parse import urlencode, urlparse, parse_qsl, urlunparse
    parsed = urlparse(url)
    q = dict(parse_qsl(parsed.query, keep_blank_values=True))
    q.update(params)
    return urlunparse(parsed._replace(query=urlencode(q)))




def _b64url_decode_update(value: str) -> bytes:
    value = str(value or "").strip()
    return base64.urlsafe_b64decode(value + ("=" * (-len(value) % 4)))


def _verify_signed_update_manifest(doc: dict, *, allow_unsigned_local: bool = False) -> dict:
    """Verify the publisher's Ed25519 release statement.

    v5.0.5 can consume the flat compatibility fields. v5.2+ additionally
    requires the signed block for non-local update endpoints.
    """
    signed = doc.get("signed")
    signature = str(doc.get("signature", "")).strip()
    if not isinstance(signed, dict) or not signature:
        if allow_unsigned_local:
            return doc
        raise ValueError("signed update manifest required")
    if not UPDATE_PUBLIC_KEY.exists():
        raise ValueError("update public key missing")
    key = serialization.load_pem_public_key(UPDATE_PUBLIC_KEY.read_bytes())
    if not isinstance(key, Ed25519PublicKey):
        raise ValueError("update public key invalid")
    raw = json.dumps(signed, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")
    try:
        key.verify(_b64url_decode_update(signature), raw)
    except Exception as exc:
        raise ValueError("update manifest signature invalid") from exc
    if signed.get("product") != "tcg-shop-manager" or signed.get("format") != 1:
        raise ValueError("update manifest product/format mismatch")
    # Compatibility flat fields must agree with the signed statement.
    for key_name in ["version","channel","severity","notes","package_url","sha256","rollout","published_at"]:
        if key_name in doc and str(doc.get(key_name, "")) != str(signed.get(key_name, "")):
            raise ValueError(f"signed manifest mismatch: {key_name}")
    return signed

def _fetch_update_manifest(url: str, install_id: str, channel: str) -> dict:
    full = _append_query(url, {
        "install_id": install_id,
        "current_version": VERSION,
        "channel": channel,
    })
    req = urllib.request.Request(full, headers={"User-Agent": f"TCG-Shop-Manager/{VERSION}"})
    with urllib.request.urlopen(req, timeout=6) as resp:
        data = resp.read(256 * 1024 + 1)
    if len(data) > 256 * 1024:
        raise ValueError("manifest too large")
    doc = json.loads(data.decode("utf-8"))
    if not isinstance(doc, dict):
        raise ValueError("manifest root must be object")
    local = full.startswith("http://127.0.0.1") or full.startswith("http://localhost")
    signed = _verify_signed_update_manifest(doc, allow_unsigned_local=local)
    latest = str(signed.get("version","")).strip()
    if not latest:
        raise ValueError("version missing")
    severity = str(signed.get("severity","optional")).strip()
    if severity not in {"optional","recommended","required"}:
        severity = "optional"
    package_url = str(signed.get("package_url","")).strip()
    sha256 = str(signed.get("sha256","")).strip().lower()
    if package_url and not (package_url.startswith("https://") or package_url.startswith("http://127.0.0.1") or package_url.startswith("http://localhost")):
        raise ValueError("package_url must use HTTPS")
    if sha256 and not re.fullmatch(r"[0-9a-f]{64}", sha256):
        raise ValueError("invalid sha256")
    return {
        "version": latest,
        "notes": str(signed.get("notes",""))[:6000],
        "severity": severity,
        "package_url": package_url,
        "sha256": sha256,
        "channel": str(signed.get("channel",channel))[:30],
        "rollout": str(signed.get("rollout",""))[:30],
        "published_at": str(signed.get("published_at",""))[:80],
        "signature_verified": bool(doc.get("signature")),
    }


def _store_update_info(conn: sqlite3.Connection, info: dict) -> None:
    set_setting(conn, "last_update_check", now())
    set_setting(conn, "latest_known_version", info.get("version",""))
    set_setting(conn, "latest_update_notes", info.get("notes",""))
    set_setting(conn, "latest_update_severity", info.get("severity",""))
    set_setting(conn, "latest_update_package_url", info.get("package_url",""))
    set_setting(conn, "latest_update_sha256", info.get("sha256",""))
    set_setting(conn, "latest_update_rollout", info.get("rollout",""))
    set_setting(conn, "latest_update_channel", info.get("channel",""))
    set_setting(conn, "latest_update_required", "1" if info.get("severity")=="required" and _version_tuple(info.get("version","")) > _version_tuple(VERSION) else "0")
    set_setting(conn, "latest_update_signature_verified", "1" if info.get("signature_verified") else "0")


def _update_banner(conn: sqlite3.Connection) -> dict | None:
    latest = setting(conn, "latest_known_version", "").strip()
    if not latest or _version_tuple(latest) <= _version_tuple(VERSION):
        return None
    return {
        "version": latest,
        "notes": setting(conn,"latest_update_notes",""),
        "severity": setting(conn,"latest_update_severity","optional") or "optional",
        "package_url": setting(conn,"latest_update_package_url",""),
        "required": setting(conn,"latest_update_required","0")=="1",
    }



def _sha256_path(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _update_status_path() -> Path:
    return UPDATE_DIR / "update_status.json"


def _read_update_status() -> dict:
    path = _update_status_path()
    if not path.exists():
        return {}
    try:
        doc = json.loads(path.read_text(encoding="utf-8"))
        return doc if isinstance(doc, dict) else {}
    except Exception:
        return {}


def _write_update_status(state: str, message: str, target_version: str = "") -> None:
    payload = {
        "state": state,
        "message": message,
        "current_version": VERSION,
        "target_version": target_version,
        "updated_at": now(),
    }
    tmp = _update_status_path().with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, _update_status_path())


def _package_root_from_zip(z: zipfile.ZipFile) -> str:
    names = [n for n in z.namelist() if n and not n.endswith("/")]
    if not names:
        raise ValueError("업데이트 ZIP이 비어 있습니다.")
    for name in names:
        p = Path(name)
        if p.is_absolute() or ".." in p.parts:
            raise ValueError("업데이트 ZIP에 안전하지 않은 경로가 있습니다.")
    if "MANIFEST.json" in names and "VERSION" in names and "app.py" in names:
        return ""
    roots = {Path(n).parts[0] for n in names if len(Path(n).parts) >= 2}
    candidates = []
    for root in roots:
        if f"{root}/MANIFEST.json" in names and f"{root}/VERSION" in names and f"{root}/app.py" in names:
            candidates.append(root)
    if len(candidates) != 1:
        raise ValueError("업데이트 ZIP의 프로그램 루트를 확인할 수 없습니다.")
    return candidates[0]


def _read_update_package_meta(path: Path) -> dict:
    try:
        with zipfile.ZipFile(path, "r") as z:
            bad = z.testzip()
            if bad:
                raise ValueError(f"업데이트 ZIP 손상: {bad}")
            root = _package_root_from_zip(z)
            prefix = f"{root}/" if root else ""
            version = z.read(prefix + "VERSION").decode("utf-8").strip()
            manifest = json.loads(z.read(prefix + "MANIFEST.json").decode("utf-8"))
            if not isinstance(manifest, dict) or manifest.get("version") != version:
                raise ValueError("업데이트 VERSION과 MANIFEST 버전이 일치하지 않습니다.")
            if _version_tuple(version) <= _version_tuple(VERSION):
                raise ValueError("현재 버전보다 새로운 패키지가 아닙니다.")
            files = manifest.get("files", {})
            if not isinstance(files, dict) or not files:
                raise ValueError("업데이트 MANIFEST 파일 목록이 없습니다.")
            required = ["app.py", "launcher.pyw", "requirements.txt", "VERSION"]
            names = set(z.namelist())
            for rel in required:
                if prefix + rel not in names:
                    raise ValueError(f"업데이트 필수 파일 누락: {rel}")
            return {"version": version, "root": root, "manifest": manifest}
    except zipfile.BadZipFile as exc:
        raise ValueError("업데이트 ZIP 형식이 올바르지 않습니다.") from exc


def _downloaded_update_path(conn: sqlite3.Connection) -> tuple[Path, str, str]:
    version = setting(conn, "latest_known_version", "").strip()
    expected = setting(conn, "latest_update_sha256", "").strip().lower()
    safe_v = re.sub(r"[^0-9A-Za-z_.-]+", "_", version)
    return UPDATE_DIR / f"TCG_Shop_Manager_v{safe_v}.zip", version, expected

@app.get("/update-center", response_class=HTMLResponse)
def update_center(request:Request, checked:int=0, downloaded:int=0, error:str=''):
    conn=db()
    sv={r['key']:r['value'] for r in conn.execute("SELECT * FROM settings")}
    package_path, package_version, expected_sha = _downloaded_update_path(conn)
    update_status = _read_update_status()
    ctx=context_base(conn,'update-center')
    ctx.update(
        settings=sv, checked=checked, downloaded=downloaded, error=error, current_version=VERSION,
        update_banner=_update_banner(conn), update_status=update_status,
        package_ready=bool(
            package_path.exists() and expected_sha
            and update_status.get("state") == "downloaded"
            and update_status.get("target_version") == package_version
        ),
        package_version=package_version, bootstrap_version=BOOTSTRAP_VERSION,
        official_update_manifest_url=OFFICIAL_UPDATE_MANIFEST_URL,
        commercial_edition=COMMERCIAL_EDITION,
    )
    conn.close()
    return templates.TemplateResponse(request=request,name='update_center.html',context=ctx)


@app.post("/update-center/config")
def update_config(update_manifest_url:str=Form(''),update_channel:str=Form('stable'),auto_update_check:str=Form('0'),auto_update_check_hours:int=Form(6)):
    url=update_manifest_url.strip() or OFFICIAL_UPDATE_MANIFEST_URL
    if url and not (url.startswith('https://') or url.startswith('http://127.0.0.1') or url.startswith('http://localhost')):
        raise HTTPException(400,'업데이트 주소는 HTTPS만 지원합니다.')
    conn=db()
    set_setting(conn,'update_manifest_url',url)
    set_setting(conn,'update_channel',update_channel if update_channel in {'stable','preview'} else 'stable')
    set_setting(conn,'auto_update_check','1' if auto_update_check=='1' else '0')
    set_setting(conn,'auto_update_check_hours',str(max(1,min(168,int(auto_update_check_hours or 6)))))
    conn.commit();conn.close()
    return RedirectResponse('/update-center',303)


@app.post("/update-center/check")
def update_check():
    conn=db()
    url=setting(conn,'update_manifest_url','').strip()
    install_id=setting(conn,'install_id','')
    channel=setting(conn,'update_channel','stable')
    conn.close()
    if not url:
        return RedirectResponse('/update-center?error=manifest_url_missing',303)
    try:
        info=_fetch_update_manifest(url, install_id, channel)
        conn=db();_store_update_info(conn, info);conn.commit();conn.close()
        return RedirectResponse('/update-center?checked=1',303)
    except Exception:
        conn=db();set_setting(conn,'last_update_check',now());conn.commit();conn.close()
        return RedirectResponse('/update-center?error=check_failed',303)


@app.post("/update-center/download")
def update_download():
    conn=db()
    url=setting(conn,'latest_update_package_url','').strip()
    expected=setting(conn,'latest_update_sha256','').strip().lower()
    version=setting(conn,'latest_known_version','').strip()
    conn.close()
    if not url or not expected or not re.fullmatch(r'[0-9a-f]{64}',expected):
        return RedirectResponse('/update-center?error=package_missing',303)
    if not (url.startswith('https://') or url.startswith('http://127.0.0.1') or url.startswith('http://localhost')):
        return RedirectResponse('/update-center?error=package_url',303)
    target=UPDATE_DIR/f"TCG_Shop_Manager_v{re.sub(r'[^0-9A-Za-z_.-]+','_',version)}.zip"
    tmp=target.with_suffix('.download')
    try:
        req=urllib.request.Request(url,headers={'User-Agent':f'TCG-Shop-Manager/{VERSION}'})
        h=hashlib.sha256();total=0
        with urllib.request.urlopen(req,timeout=30) as resp, tmp.open('wb') as out:
            while True:
                chunk=resp.read(1024*1024)
                if not chunk: break
                total+=len(chunk)
                if total>500*1024*1024: raise ValueError('update package too large')
                h.update(chunk);out.write(chunk)
        if h.hexdigest().lower()!=expected:
            raise ValueError('sha256 mismatch')
        tmp.replace(target)
        meta = _read_update_package_meta(target)
        if meta["version"] != version:
            raise ValueError('manifest/package version mismatch')
        _write_update_status("downloaded", f"v{version} 패키지 다운로드 및 사전 검증 완료", version)
        conn=db();audit(conn,'UPDATE_PACKAGE_DOWNLOAD',f'v{version} sha256 + package preflight verified');conn.commit();conn.close()
        return RedirectResponse('/update-center?downloaded=1',303)
    except Exception as exc:
        try: tmp.unlink()
        except OSError: pass
        try: _write_update_status("error", f"업데이트 다운로드/검증 실패: {exc}", version)
        except Exception: pass
        return RedirectResponse('/update-center?error=download_failed',303)




@app.get("/update-center/status")
def update_status_api():
    status = _read_update_status()
    status["server_version"] = VERSION
    status["server_online"] = True
    return JSONResponse(status)


@app.post("/update-center/apply", response_class=HTMLResponse)
def update_apply(request: Request):
    host = request.client.host if request.client else ""
    if host not in {"127.0.0.1", "::1", "localhost", "testclient"}:
        raise HTTPException(403, "로컬 컴퓨터에서만 업데이트를 적용할 수 있습니다.")

    conn = db()
    package_path, version, expected = _downloaded_update_path(conn)
    conn.close()
    if not package_path.exists() or not expected or not re.fullmatch(r"[0-9a-f]{64}", expected):
        return RedirectResponse("/update-center?error=package_missing", 303)
    if _sha256_path(package_path).lower() != expected:
        _write_update_status("error", "업데이트 패키지 SHA-256이 다시 확인했을 때 일치하지 않았습니다.", version)
        return RedirectResponse("/update-center?error=download_failed", 303)

    try:
        meta = _read_update_package_meta(package_path)
        version = meta["version"]
        backup = create_backup(f"pre_update_v{version.replace('.', '_')}")
        _validate_backup_archive(backup)

        helper_src = BASE_DIR / "update_helper.py"
        if not helper_src.exists():
            raise ValueError("업데이트 실행 도우미가 없습니다.")
        runtime_dir = DATA_DIR / "runtime"
        runtime_dir.mkdir(parents=True, exist_ok=True)
        helper_copy = runtime_dir / f"update_helper_{datetime.now().strftime('%Y%m%d_%H%M%S')}.py"
        shutil.copy2(helper_src, helper_copy)
        status_path = _update_status_path()
        port = int(os.environ.get("TCG_SHOP_PORT", "8765"))
        _write_update_status("starting", f"v{version} 자동 업데이트를 준비하고 있습니다.", version)

        flags = 0
        if os.name == "nt":
            flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "CREATE_NO_WINDOW", 0)
        cmd = [
            sys.executable, str(helper_copy),
            "--base", str(BASE_DIR), "--package", str(package_path),
            "--target-version", version, "--expected-sha256", expected,
            "--data-dir", str(DATA_DIR), "--backup", str(backup),
            "--status", str(status_path), "--port", str(port),
            "--old-pid", str(os.getpid()), "--python", sys.executable,
            "--ui-mode", os.environ.get("TCG_SHOP_UI_MODE", "browser"),
        ]
        subprocess.Popen(
            cmd, cwd=str(runtime_dir), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            close_fds=(os.name != "nt"), creationflags=flags,
        )
        conn=db();audit(conn,'UPDATE_APPLY_START',f'{VERSION} -> {version}; backup={backup.name}');conn.commit();conn.close()
    except Exception as exc:
        _write_update_status("error", f"자동 업데이트 시작 실패: {exc}", version)
        return RedirectResponse("/update-center?error=apply_failed", 303)

    return HTMLResponse(f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>업데이트 적용 중</title><style>
body{{font-family:system-ui,sans-serif;background:#f5f7fb;color:#172033;display:grid;place-items:center;min-height:100vh;margin:0}}
.box{{width:min(560px,calc(100% - 40px));background:#fff;border:1px solid #e1e6ee;border-radius:18px;padding:34px;box-shadow:0 20px 50px rgba(20,30,50,.08)}}
h1{{font-size:23px;margin:0 0 8px}}p{{color:#667085;line-height:1.65}}.stage{{font-weight:700;color:#28364f;margin-top:18px}}
.bar{{height:10px;border-radius:99px;background:#eef0f6;overflow:hidden;margin:12px 0}}.fill{{height:100%;width:4%;background:#4b46a3;border-radius:99px;transition:width .35s ease}}
.meta{{display:flex;justify-content:space-between;gap:10px;color:#8b94a5;font-size:12px}}small{{color:#8b94a5}}.ok{{color:#13735a}}.bad{{color:#a63434}}
</style></head><body><div class="box">
<h1>TCG Shop Manager를 업데이트하고 있습니다.</h1>
<p>v{VERSION} → v{version}<br>새 버전 확인에 실패하면 이전 프로그램과 업데이트 직전 데이터로 자동 복구합니다.</p>
<div id="stage" class="stage">업데이트 도우미를 시작하고 있습니다.</div>
<div class="bar"><div id="fill" class="fill"></div></div>
<div class="meta"><span id="progress">0%</span><span id="elapsed">0초</span></div>
<p id="message">잠시 기다려주세요.</p>
<small>프로그램이 재시작되는 몇 초 동안 연결이 끊겨도 정상입니다. 완료/복구 후 이 화면이 자동으로 이동합니다.</small>
</div>
<script>
const terminal = new Set(["success","rolled_back","rollback_failed","error"]);
let lastProgress=3;
function label(state){{
 const labels={{starting:"준비",preflight:"패키지 검증",preflight_done:"패키지 검증 완료",dependencies:"필수 구성요소 변경",dependencies_skipped:"필수 구성요소 확인 완료",dependencies_ready:"필수 구성요소 확인 완료",stopping:"기존 프로그램 종료",swapping:"프로그램 교체",launching:"새 버전 시작",verifying:"정상 기동 확인",rollback:"자동 복구",success:"업데이트 완료",rolled_back:"자동 복구 완료",rollback_failed:"복구 확인 필요",error:"업데이트 중단"}};
 return labels[state]||"업데이트 처리";
}}
async function poll(){{
 try{{
   const r=await fetch("/update-center/status?ts="+Date.now(),{{cache:"no-store"}});
   if(!r.ok) throw new Error("offline");
   const s=await r.json();
   const p=Number.isFinite(Number(s.progress))?Number(s.progress):lastProgress;
   lastProgress=Math.max(lastProgress,p);
   document.getElementById("fill").style.width=Math.max(4,lastProgress)+"%";
   document.getElementById("progress").textContent=Math.round(lastProgress)+"%";
   document.getElementById("stage").textContent=label(s.state);
   document.getElementById("message").textContent=s.message||"처리 중입니다.";
   document.getElementById("elapsed").textContent=(s.elapsed_seconds??0)+"초";
   if(terminal.has(s.state)){{
     if(s.state==="success"||s.state==="rolled_back") document.getElementById("stage").classList.add("ok");
     else document.getElementById("stage").classList.add("bad");
     setTimeout(()=>location.href="/update-center",1200); return;
   }}
 }}catch(e){{
   document.getElementById("stage").textContent="프로그램 재시작 중";
   document.getElementById("message").textContent="로컬 서버가 새 버전으로 전환되고 있습니다. 연결이 다시 열리면 자동으로 계속 확인합니다.";
   lastProgress=Math.max(lastProgress,55);
   document.getElementById("fill").style.width=lastProgress+"%";
   document.getElementById("progress").textContent=Math.round(lastProgress)+"%";
 }}
 setTimeout(poll,700);
}}
poll();
</script></body></html>''')


@app.post("/license/save")
def license_save(license_key:str=Form(...)):
    key=license_key.strip()
    conn=db()
    install_id=setting(conn,'install_id','')
    try:
        payload=verify_license_token(key, install_id)
    except ValueError as exc:
        audit(conn,'LICENSE_REJECT',str(exc)[:300])
        conn.commit(); conn.close()
        raise HTTPException(400, str(exc))
    set_setting(conn,'license_key',key)
    set_setting(conn,'license_holder',str(payload.get('holder','')))
    set_setting(conn,'license_id',str(payload.get('license_id','')))
    set_setting(conn,'license_issued_at',str(payload.get('issued_at','')))
    set_setting(conn,'license_verified_at',now())
    set_setting(conn,'license_status','영구 라이선스 활성')
    audit(conn,'LICENSE_ACTIVATE',f"{payload.get('license_id','')} holder={payload.get('holder','')}")
    conn.commit(); conn.close()
    return RedirectResponse('/settings?saved=1#license',303)


@app.post("/license/clear")
def license_clear():
    conn=db()
    old_id=setting(conn,'license_id','')
    for key,value in [
        ('license_key',''),('license_holder',''),('license_id',''),
        ('license_issued_at',''),('license_verified_at',''),('license_status','미등록')
    ]:
        set_setting(conn,key,value)
    audit(conn,'LICENSE_CLEAR',old_id)
    conn.commit(); conn.close()
    return RedirectResponse('/settings?saved=1#license',303)


SUPPORT_PACKAGE_PREFIX = "TCGShopManager_Support_"
SUPPORT_PACKAGE_LIMIT = 10


def _support_fingerprint(value: str) -> str:
    value = str(value or "").strip()
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:12] if value else ""


def _support_recent_error_events(limit: int = 20) -> list[dict]:
    """Privacy-minimized error summary. Raw tracebacks/messages are not packaged."""
    path = DATA_DIR / "logs" / "app_errors.log"
    if not path.exists():
        return []
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []
    events = []
    current = None
    header_re = re.compile(r"^\[(?P<timestamp>[^\]]+)\]\s+support_id=(?P<support_id>[^\s]+)\s+path=(?P<path>\S+)")
    error_re = re.compile(r"^(?P<etype>[A-Za-z_][A-Za-z0-9_.]*(?:Error|Exception|Interrupt|Exit))(?::.*)?$")
    for raw in lines:
        line = raw.strip()
        hm = header_re.match(line)
        if hm:
            current = {
                "timestamp": hm.group("timestamp"),
                "support_id": hm.group("support_id")[:80],
                "route": hm.group("path")[:200],
                "error_type": "UnknownError",
            }
            events.append(current)
            continue
        if current:
            em = error_re.match(line)
            if em:
                current["error_type"] = em.group("etype")[:120]
    return events[-max(1, min(100, int(limit))):]


def _support_manifest_health() -> dict:
    path = BASE_DIR / "MANIFEST.json"
    out = {
        "available": path.exists(), "version": "", "checked_files": 0,
        "missing_count": 0, "mismatch_count": 0,
        "missing_files": [], "mismatch_files": [], "status": "not_available",
    }
    if not path.exists():
        return out
    try:
        doc = json.loads(path.read_text(encoding="utf-8"))
        out["version"] = str(doc.get("version", ""))
        files = doc.get("files", {})
        if not isinstance(files, dict):
            raise ValueError("invalid manifest")
        for rel, expected in files.items():
            out["checked_files"] += 1
            target = BASE_DIR / Path(str(rel))
            if not target.exists() or not target.is_file():
                out["missing_count"] += 1
                if len(out["missing_files"]) < 30:
                    out["missing_files"].append(str(rel))
                continue
            actual = hashlib.sha256(target.read_bytes()).hexdigest()
            if actual.lower() != str(expected).lower():
                out["mismatch_count"] += 1
                if len(out["mismatch_files"]) < 30:
                    out["mismatch_files"].append(str(rel))
        out["status"] = "ok" if out["missing_count"] == 0 and out["mismatch_count"] == 0 else "check"
    except Exception as exc:
        out["status"] = "error"
        out["error_type"] = type(exc).__name__
    return out


def _support_package_inventory() -> list[dict]:
    try:
        paths = sorted(
            [p for p in SUPPORT_DIR.iterdir()
             if p.is_file() and p.suffix.lower() == ".zip"
             and p.name.startswith(SUPPORT_PACKAGE_PREFIX)],
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )[:SUPPORT_PACKAGE_LIMIT]
    except OSError:
        paths = []
    rows = []
    for p in paths:
        try:
            rows.append({
                "name": p.name,
                "size": p.stat().st_size,
                "mtime": datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M"),
                "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
            })
        except OSError:
            pass
    return rows


def create_support_diagnostics() -> Path:
    SUPPORT_DIR.mkdir(parents=True, exist_ok=True)
    support_code = datetime.now().strftime("%Y%m%d-%H%M%S-") + secrets.token_hex(3)
    created_at = now()
    conn = db()
    try:
        quick = str(conn.execute("PRAGMA quick_check").fetchone()[0])
        fk_errors = len(conn.execute("PRAGMA foreign_key_check").fetchall())
        journal_mode = str(conn.execute("PRAGMA journal_mode").fetchone()[0])
        table_names = [
            str(r["name"]) for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' "
                "AND name NOT LIKE 'sqlite_%' ORDER BY name"
            ).fetchall()
        ]
        count_tables = [
            "products","inventory_movements","suppliers","purchases","purchase_items",
            "orders","order_items","expenses","capital_transactions","refunds",
            "buybacks","buyback_items","staff_users","staff_activity","channel_profiles",
            "channel_product_mappings","channel_sync_runs","plugin_registry","plugin_records","audit_log",
        ]
        counts = {}
        for table in count_tables:
            if table not in table_names:
                counts[table] = None
                continue
            try:
                counts[table] = int(conn.execute(f'SELECT COUNT(*) c FROM "{table}"').fetchone()["c"])
            except sqlite3.Error:
                counts[table] = None

        safe_keys = [
            "schema_app_version","auth_enabled","auto_backup","reorder_target_days",
            "stale_stock_days","last_startup_db_check","last_backup_date","update_channel",
            "latest_known_version","latest_update_channel","latest_update_required",
            "latest_update_severity","license_enforcement","onboarding_completed",
        ]
        safe_settings = {k: setting(conn, k, "") for k in safe_keys}
        state = _license_state(conn)
        license_safe = {
            "state": state.get("state",""),
            "label": state.get("label",""),
            "enforced": bool(state.get("enforced",False)),
            "trial_days_left": int(state.get("trial_days_left",0) or 0),
            "install_id_fingerprint": _support_fingerprint(setting(conn,"install_id","")),
            "license_id_fingerprint": _support_fingerprint(state.get("license_id","")),
        }

        plugins = []
        if "plugin_registry" in table_names:
            try:
                for r in conn.execute(
                    "SELECT plugin_id,version,enabled,status,min_app_version,max_app_version "
                    "FROM plugin_registry ORDER BY plugin_id"
                ):
                    plugins.append({
                        "plugin_id": str(r["plugin_id"])[:100],
                        "version": str(r["version"])[:50],
                        "enabled": bool(r["enabled"]),
                        "status": str(r["status"])[:50],
                        "min_app_version": str(r["min_app_version"])[:50],
                        "max_app_version": str(r["max_app_version"])[:50],
                    })
            except sqlite3.Error:
                pass

        backups = [p for p in BACKUP_DIR.iterdir() if p.is_file() and p.suffix.lower() in {".tcgbak",".db",".zip"}]
        images = [p for p in PRODUCT_IMAGE_DIR.iterdir() if p.is_file()]
        disk = shutil.disk_usage(DATA_DIR)
        system_info = {
            "app_name": APP_NAME, "app_version": VERSION,
            "generated_at": created_at, "support_code": support_code,
            "os": platform.system(), "os_release": platform.release(),
            "os_version": platform.version(), "architecture": platform.machine(),
            "python_version": platform.python_version(),
            "python_implementation": platform.python_implementation(),
            "database_size_bytes": DB_PATH.stat().st_size if DB_PATH.exists() else 0,
            "backup_file_count": len(backups),
            "product_image_file_count": len(images),
            "support_package_count_before_this": len(_support_package_inventory()),
            "data_disk_free_bytes": int(disk.free),
        }
        db_health = {
            "quick_check": quick, "quick_check_ok": quick.lower()=="ok",
            "foreign_key_error_count": fk_errors, "journal_mode": journal_mode,
            "table_count": len(table_names),
            "schema_app_version": setting(conn,"schema_app_version",""),
        }
        audit(conn,"SUPPORT_DIAGNOSTICS_CREATE",support_code)
        conn.commit()
    finally:
        conn.close()

    docs = {
        "system_info.json": system_info,
        "database_health.json": db_health,
        "table_counts.json": counts,
        "safe_configuration.json": safe_settings,
        "license_status.json": license_safe,
        "plugins.json": plugins,
        "recent_errors.json": _support_recent_error_events(20),
        "app_manifest_health.json": _support_manifest_health(),
    }
    privacy = """TCG Shop Manager 지원용 진단 패키지
======================================

기술 지원에 필요한 최소 정보만 포함합니다.

포함:
- 앱 / Windows / Python 버전과 CPU 아키텍처
- SQLite quick_check / 외래키 오류 수 / 테이블별 행 개수
- 앱 MANIFEST 무결성 결과
- 안전한 운영 설정 일부
- 기능팩 ID / 버전 / 활성 상태
- 최근 오류의 시각 / support ID / 요청 경로 / 오류 클래스
- 설치 ID / 라이선스 ID의 단방향 SHA-256 지문 일부

포함하지 않음:
- shop.db / 백업 DB / CSV
- 상품명 / SKU / 가격 / 재고 개별 행
- 주문번호 / 주문메모 / 고객 및 판매자 정보
- 공급처 이름 / 연락처
- 매장명 / 운영자명 / 직원 이름 및 아이디
- 비밀번호 / 비밀번호 해시 / 솔트 / 세션 비밀키
- 설치 ID 원문
- 라이선스 키 / 라이선스 사용자명
- 상품 이미지
- 원본 app_errors.log 전체 내용

전달 전 고객이 ZIP을 직접 열어 내용을 확인할 수 있습니다.
"""
    work = Path(tempfile.mkdtemp(prefix="tcg_support_",dir=str(SUPPORT_DIR)))
    try:
        (work/"README_PRIVACY.txt").write_text(privacy,encoding="utf-8")
        for name,value in docs.items():
            (work/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding="utf-8")
        fh = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(work.iterdir()) if p.is_file()}
        (work/"PACKAGE_MANIFEST.json").write_text(json.dumps({
            "format":1,"product":"tcg-shop-manager-support-diagnostics",
            "app_version":VERSION,"support_code":support_code,
            "generated_at":created_at,"files":fh,
        },ensure_ascii=False,indent=2),encoding="utf-8")
        stamp=datetime.now().strftime("%Y%m%d_%H%M%S")
        short=re.sub(r"[^A-Za-z0-9_-]+","",support_code)[-12:]
        out=SUPPORT_DIR/f"{SUPPORT_PACKAGE_PREFIX}{stamp}_{short}.zip"
        with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED) as z:
            for p in sorted(work.iterdir()):
                if p.is_file(): z.write(p,p.name)
        with zipfile.ZipFile(out) as z:
            if z.testzip(): raise RuntimeError("support zip integrity")
        return out
    finally:
        shutil.rmtree(work,ignore_errors=True)


@app.post("/support/diagnostics/create")
def support_diagnostics_create():
    try:
        path=create_support_diagnostics()
    except Exception as exc:
        raise HTTPException(500,f"지원용 진단 패키지를 만들지 못했습니다. 오류 유형: {type(exc).__name__}")
    return RedirectResponse(f"/settings?support_created={path.name}#support",303)


@app.get("/support/diagnostics/{filename}")
def support_diagnostics_download(filename:str):
    safe=Path(filename).name
    if safe!=filename or not safe.startswith(SUPPORT_PACKAGE_PREFIX) or not safe.endswith(".zip"):
        raise HTTPException(404,"지원용 진단 파일을 찾을 수 없습니다.")
    path=SUPPORT_DIR/safe
    if not path.exists() or not path.is_file():
        raise HTTPException(404,"지원용 진단 파일을 찾을 수 없습니다.")
    return FileResponse(path,filename=safe,media_type="application/zip")


@app.post("/support/diagnostics/{filename}/delete")
def support_diagnostics_delete(filename:str):
    safe=Path(filename).name
    if safe!=filename or not safe.startswith(SUPPORT_PACKAGE_PREFIX) or not safe.endswith(".zip"):
        raise HTTPException(404,"지원용 진단 파일을 찾을 수 없습니다.")
    path=SUPPORT_DIR/safe
    if path.exists() and path.is_file(): path.unlink()
    return RedirectResponse("/settings#support",303)


@app.get("/settings", response_class=HTMLResponse)
def settings_page(request:Request, restored:int=0, saved:int=0, support_created:str=""):
    conn=db();_sync_license_settings(conn);conn.commit();svals={r['key']:r['value'] for r in conn.execute("SELECT * FROM settings")};channels=conn.execute("SELECT * FROM channel_profiles ORDER BY name").fetchall();backups=sorted([p for p in BACKUP_DIR.iterdir() if p.is_file() and p.suffix.lower() in {'.tcgbak','.db','.zip'}],key=lambda p:p.stat().st_mtime,reverse=True)[:15]
    support_packages=_support_package_inventory()
    ctx=context_base(conn,'settings');ctx.update(settings=svals,channels=channels,backups=[{'name':p.name,'size':p.stat().st_size,'mtime':datetime.fromtimestamp(p.stat().st_mtime).strftime('%Y-%m-%d %H:%M')} for p in backups],data_dir=str(DATA_DIR),restored=restored,saved=saved,support_created=Path(support_created).name if support_created else "",support_packages=support_packages)
    conn.close();return templates.TemplateResponse(request=request,name='settings.html',context=ctx)

@app.post("/settings/general")
def settings_general(shop_name:str=Form(...),owner_name:str=Form(""),auto_backup:str=Form("0"),reorder_target_days:int=Form(21),stale_stock_days:int=Form(60)):
    conn=db();set_setting(conn,'shop_name',shop_name.strip());set_setting(conn,'owner_name',owner_name.strip());set_setting(conn,'auto_backup','1' if auto_backup=='1' else '0');set_setting(conn,'reorder_target_days',str(max(7,min(90,reorder_target_days))));set_setting(conn,'stale_stock_days',str(max(30,min(365,stale_stock_days))));audit(conn,'SETTINGS_UPDATE','general v2');conn.commit();conn.close();return RedirectResponse('/settings?saved=1',303)

@app.post("/channels/{cid}/edit")
def channel_edit(cid:int,fee_rate:float=Form(0),fixed_fee:int=Form(0),default_shipping_cost:int=Form(0)):
    conn=db();conn.execute("UPDATE channel_profiles SET fee_rate=?,fixed_fee=?,default_shipping_cost=? WHERE id=?",(max(0,fee_rate),max(0,fixed_fee),max(0,default_shipping_cost),cid));conn.commit();conn.close();return RedirectResponse('/settings',303)

@app.post("/channels/add")
def channel_add(name:str=Form(...),fee_rate:float=Form(0),fixed_fee:int=Form(0),default_shipping_cost:int=Form(0)):
    conn=db();
    try:conn.execute("INSERT INTO channel_profiles(name,fee_rate,fixed_fee,default_shipping_cost,created_at) VALUES(?,?,?,?,?)",(name.strip(),max(0,fee_rate),max(0,fixed_fee),max(0,default_shipping_cost),now()));conn.commit()
    except sqlite3.IntegrityError:conn.close();raise HTTPException(400,"이미 같은 채널명이 있습니다.")
    conn.close();return RedirectResponse('/settings',303)

@app.post("/backup/create")
def backup_create():
    create_backup('manual');return RedirectResponse('/settings',303)

@app.get("/backup/{filename}")
def backup_download(filename:str):
    safe=Path(filename).name;path=BACKUP_DIR/safe
    if not path.exists() or path.suffix.lower() not in {'.tcgbak','.db','.zip'}:raise HTTPException(404,"백업 없음")
    return FileResponse(path,filename=safe,media_type='application/octet-stream')

@app.post("/backup/{filename}/restore")
def backup_restore(filename:str):
    safe=Path(filename).name; path=BACKUP_DIR/safe
    if not path.exists() or path.suffix.lower() not in {'.tcgbak','.db','.zip'}:
        raise HTTPException(404,"백업 없음")
    try:
        restore_backup_file(path)
    except Exception as exc:
        raise HTTPException(400,f"백업 복원 실패: {exc}")
    return RedirectResponse('/settings?restored=1',303)

@app.post("/backup/upload-restore")
def backup_upload_restore(file:UploadFile=File(...)):
    suffix=Path(file.filename or '').suffix.lower()
    if suffix not in {'.tcgbak','.db','.zip'}:
        raise HTTPException(400,".tcgbak, .db, .zip 백업만 복원할 수 있습니다.")
    tmp=Path(tempfile.mkstemp(prefix='tcg_uploaded_backup_',suffix=suffix)[1])
    try:
        data=file.file.read(200*1024*1024+1)
        if len(data)>200*1024*1024: raise HTTPException(400,"백업 파일은 200MB 이하만 지원합니다.")
        tmp.write_bytes(data)
        restore_backup_file(tmp)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400,f"백업 복원 실패: {exc}")
    finally:
        try: tmp.unlink()
        except OSError: pass
    return RedirectResponse('/settings?restored=1',303)

@app.get("/export/all.zip")
def export_all():
    conn=db();tables=['products','inventory_movements','suppliers','purchases','purchase_items','orders','order_items','expenses','channel_profiles','capital_transactions','refunds','buybacks','buyback_items','channel_product_mappings','channel_sync_runs','audit_log'];tmp=tempfile.NamedTemporaryFile(delete=False,suffix='.zip');tmp.close()
    with zipfile.ZipFile(tmp.name,'w',zipfile.ZIP_DEFLATED) as z:
        for t in tables:
            rows=conn.execute(f"SELECT * FROM {t}").fetchall();buf=io.StringIO();
            if rows:
                w=csv.writer(buf);w.writerow(rows[0].keys());[w.writerow([r[k] for k in r.keys()]) for r in rows]
            z.writestr(f"{t}.csv",'\ufeff'+buf.getvalue())
        z.writestr('metadata.json',json.dumps({'app':APP_NAME,'version':VERSION,'exported_at':now()},ensure_ascii=False,indent=2))
    conn.close();return FileResponse(tmp.name,filename=f"TCGShopManager_export_{date.today().isoformat()}.zip",media_type='application/zip',background=None)

@app.get("/export/products.csv")
def export_products():
    conn=db();rows=conn.execute("SELECT * FROM products WHERE active=1 ORDER BY id").fetchall();buf=io.StringIO();cols=['name','set_name','category','language','sku','barcode','card_number','rarity','card_condition','avg_cost','sale_price','stock','low_stock_threshold','notes'];w=csv.writer(buf);w.writerow(cols);[w.writerow([r[c] for c in cols]) for r in rows];conn.close();content=('\ufeff'+buf.getvalue()).encode('utf-8');return StreamingResponse(iter([content]),media_type='text/csv; charset=utf-8',headers={'Content-Disposition':'attachment; filename="products.csv"'})

@app.post("/import/products")
async def import_products(file:UploadFile=File(...)):
    raw=await file.read();
    try:text=raw.decode('utf-8-sig')
    except UnicodeDecodeError:raise HTTPException(400,"UTF-8 CSV만 지원합니다.")
    reader=csv.DictReader(io.StringIO(text));
    if not reader.fieldnames or 'name' not in reader.fieldnames:raise HTTPException(400,"name 열이 필요합니다.")
    conn=db();count=0
    for r in reader:
        name=(r.get('name') or '').strip();
        if not name:continue
        avg=float(r.get('avg_cost') or 0);stock=max(0,int(float(r.get('stock') or 0)));cur=conn.execute("""INSERT INTO products(name,set_name,category,language,sku,barcode,card_number,rarity,card_condition,avg_cost,sale_price,stock,low_stock_threshold,notes,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(name,(r.get('set_name') or '').strip(),(r.get('category') or 'BOX').strip(),(r.get('language') or '한국어').strip(),(r.get('sku') or '').strip(),(r.get('barcode') or '').strip(),(r.get('card_number') or '').strip(),(r.get('rarity') or '').strip(),(r.get('card_condition') or '').strip(),max(0,avg),max(0,int(float(r.get('sale_price') or 0))),stock,max(0,int(float(r.get('low_stock_threshold') or 2))),(r.get('notes') or '').strip(),now(),now()));pid=cur.lastrowid
        if stock:conn.execute("INSERT INTO inventory_movements(product_id,movement_type,quantity,unit_cost,reason,created_at) VALUES(?,?,?,?,?,?)",(pid,'CSV초기재고',stock,avg,'CSV 가져오기',now()))
        count+=1
    audit(conn,'PRODUCT_IMPORT',f'{count} rows');conn.commit();conn.close();return RedirectResponse('/products',303)

@app.get("/orders/import-template.csv")
def order_import_template():
    cols=['external_order_no','order_date','channel','sku','quantity','unit_sale_price','discount','shipping_charged','shipping_paid','fee_rate','fixed_fee','other_cost','memo']
    buf=io.StringIO(); w=csv.writer(buf); w.writerow(cols); w.writerow(['EXAMPLE-001',date.today().isoformat(),'네이버 스마트스토어','SKU-001',1,55000,0,3000,3000,'','',0,'샘플 행 - 삭제 후 사용'])
    content=('\ufeff'+buf.getvalue()).encode('utf-8')
    return StreamingResponse(iter([content]),media_type='text/csv; charset=utf-8',headers={'Content-Disposition':'attachment; filename="order_import_template.csv"'})

@app.post("/orders/import")
async def order_import(file:UploadFile=File(...)):
    raw=await file.read()
    if len(raw)>20*1024*1024: raise HTTPException(400,"주문 CSV는 20MB 이하만 지원합니다.")
    try: text=raw.decode('utf-8-sig')
    except UnicodeDecodeError: raise HTTPException(400,"UTF-8 CSV만 지원합니다.")
    reader=csv.DictReader(io.StringIO(text))
    required={'external_order_no','sku','quantity','unit_sale_price'}
    if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
        raise HTTPException(400,"필수 열: external_order_no, sku, quantity, unit_sale_price")
    rows=list(reader)
    if not rows: raise HTTPException(400,"가져올 주문이 없습니다.")

    groups={}
    for idx,r in enumerate(rows,start=2):
        ext=(r.get('external_order_no') or '').strip()
        if not ext: raise HTTPException(400,f"{idx}행: external_order_no가 비어 있습니다.")
        groups.setdefault(ext,[]).append((idx,r))

    conn=db(); imported=0
    try:
        conn.execute('BEGIN')
        for ext, group in groups.items():
            first=group[0][1]
            channel=(first.get('channel') or '직접입력').strip() or '직접입력'
            if conn.execute("SELECT 1 FROM orders WHERE channel=? AND external_order_no=? LIMIT 1",(channel,ext)).fetchone():
                raise ValueError(f"이미 등록된 주문번호입니다: {channel} / {ext}")
            profile=conn.execute("SELECT * FROM channel_profiles WHERE name=?",(channel,)).fetchone()
            def num(name, default=0.0):
                raw=(first.get(name) or '').strip()
                return float(raw) if raw else float(default)
            order_date=(first.get('order_date') or date.today().isoformat()).strip()
            discount=max(0,int(num('discount',0))); shipping_charged=max(0,int(num('shipping_charged',0)))
            shipping_paid=max(0,int(num('shipping_paid', profile['default_shipping_cost'] if profile else 0)))
            fee_rate=max(0,float(num('fee_rate', profile['fee_rate'] if profile else 0)))
            fixed_fee=max(0,int(num('fixed_fee', profile['fixed_fee'] if profile else 0)))
            other=max(0,int(num('other_cost',0))); memo=(first.get('memo') or '').strip()

            items=[]; needs={} ; items_revenue=0; cogs=0.0
            for rowno,r in group:
                sku=(r.get('sku') or '').strip()
                matches=conn.execute("SELECT * FROM products WHERE active=1 AND sku=?",(sku,)).fetchall()
                if len(matches)!=1:
                    raise ValueError(f"{rowno}행 SKU '{sku}'는 활성 상품과 정확히 1개 매칭되어야 합니다. 현재 {len(matches)}개")
                p=matches[0]; qty=max(1,int(float(r.get('quantity') or 1))); price=max(0,int(float(r.get('unit_sale_price') or 0)))
                needs[p['id']]=needs.get(p['id'],0)+qty
                rev=qty*price; icogs=qty*float(p['avg_cost']); items_revenue+=rev; cogs+=icogs
                items.append((p['id'],p['name'],qty,price,float(p['avg_cost']),rev,icogs,rev-icogs))
            for pid,qty in needs.items():
                stock=conn.execute("SELECT stock,name FROM products WHERE id=?",(pid,)).fetchone()
                if not stock or int(stock['stock'])<qty:
                    raise ValueError(f"주문 {ext}: {stock['name'] if stock else pid} 재고 부족 (필요 {qty}, 현재 {stock['stock'] if stock else 0})")
            gross_revenue=max(0,items_revenue-discount+shipping_charged)
            platform_fee=round(gross_revenue*fee_rate/100+fixed_fee)
            gross_profit=gross_revenue-cogs; net_profit=gross_profit-platform_fee-shipping_paid-other
            cur=conn.execute("""INSERT INTO orders(channel,external_order_no,order_date,status,items_revenue,discount,shipping_charged,gross_revenue,cogs,platform_fee,shipping_paid,other_cost,gross_profit,net_profit,fee_rate,fixed_fee,memo,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(channel,ext,order_date,'결제완료',items_revenue,discount,shipping_charged,gross_revenue,cogs,platform_fee,shipping_paid,other,gross_profit,net_profit,fee_rate,fixed_fee,memo,now(),now()))
            oid=cur.lastrowid
            for pid,name,qty,price,ucost,rev,icogs,gp in items:
                conn.execute("INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_sale_price,unit_cost,revenue,cogs,gross_profit) VALUES(?,?,?,?,?,?,?,?,?)",(oid,pid,name,qty,price,ucost,rev,icogs,gp))
                conn.execute("UPDATE products SET stock=stock-?,updated_at=? WHERE id=?",(qty,now(),pid))
                conn.execute("INSERT INTO inventory_movements(product_id,movement_type,quantity,unit_cost,reference_type,reference_id,reason,created_at) VALUES(?,?,?,?,?,?,?,?)",(pid,'판매',-qty,ucost,'order',oid,f'CSV 주문 가져오기 · {channel}',now()))
            audit(conn,'ORDER_IMPORT',f'#{oid} {channel} {ext}'); imported+=1
        conn.commit()
    except Exception as exc:
        conn.rollback(); conn.close(); raise HTTPException(400,f"주문 CSV 가져오기 실패: {exc}")
    conn.close(); return RedirectResponse(f'/orders?imported={imported}',303)

@app.get("/cashflow", response_class=HTMLResponse)
def cashflow_page(request:Request):
    conn=db(); flow=cashflow_summary(conn)
    capital=conn.execute("SELECT * FROM capital_transactions ORDER BY id DESC LIMIT 100").fetchall()
    supplier=conn.execute("""SELECT supplier_name,COUNT(*) orders,COALESCE(SUM(total_cost),0) spend,MAX(order_date) last_order FROM purchases WHERE status!='취소' GROUP BY supplier_name ORDER BY spend DESC""").fetchall()
    refunds=conn.execute("SELECT r.*,o.channel,o.external_order_no FROM refunds r JOIN orders o ON o.id=r.order_id ORDER BY r.id DESC LIMIT 100").fetchall()
    ctx=context_base(conn,'cashflow');ctx.update(flow=flow,capital=capital,supplier=supplier,refunds=refunds);conn.close();return templates.TemplateResponse(request=request,name='cashflow.html',context=ctx)

@app.post("/capital/add")
def capital_add(tx_date:str=Form(...),tx_type:str=Form('투입'),amount:int=Form(...),description:str=Form('')):
    if tx_type not in {'투입','회수'}: raise HTTPException(400,'자금 유형이 올바르지 않습니다.')
    conn=db();conn.execute("INSERT INTO capital_transactions(tx_date,tx_type,amount,description,created_at) VALUES(?,?,?,?,?)",(tx_date,tx_type,max(0,amount),description.strip(),now()));audit(conn,'CAPITAL_ADD',f'{tx_type} {amount}');conn.commit();conn.close();return RedirectResponse('/cashflow',303)

@app.get("/returns", response_class=HTMLResponse)
def returns_page(request:Request):
    conn=db(); rows=conn.execute("SELECT r.*,o.channel,o.external_order_no,o.gross_revenue FROM refunds r JOIN orders o ON o.id=r.order_id ORDER BY r.id DESC").fetchall();orders=conn.execute("SELECT * FROM orders WHERE status!='취소' ORDER BY id DESC LIMIT 200").fetchall();ctx=context_base(conn,'returns');ctx.update(rows=rows,orders=orders);conn.close();return templates.TemplateResponse(request=request,name='returns.html',context=ctx)

@app.post("/returns/add")
def return_add(order_id:int=Form(...),refund_date:str=Form(...),refund_type:str=Form('부분환불'),refund_amount:int=Form(...),shipping_deduction:int=Form(0),restock:str=Form('0'),memo:str=Form('')):
    conn=db();o=conn.execute("SELECT * FROM orders WHERE id=? AND status!='취소'",(order_id,)).fetchone()
    if not o: conn.close();raise HTTPException(404,'주문을 찾을 수 없습니다.')
    net=max(0,int(refund_amount)-max(0,int(shipping_deduction)));restock_flag=1 if restock=='1' else 0
    try:
        conn.execute('BEGIN')
        cur=conn.execute("INSERT INTO refunds(order_id,refund_date,refund_type,refund_amount,shipping_deduction,restock,memo,created_at) VALUES(?,?,?,?,?,?,?,?)",(order_id,refund_date,refund_type,net,max(0,shipping_deduction),restock_flag,memo.strip(),now()))
        rid=cur.lastrowid
        if restock_flag:
            for it in conn.execute("SELECT * FROM order_items WHERE order_id=?",(order_id,)).fetchall():
                conn.execute("UPDATE products SET stock=stock+?,updated_at=? WHERE id=?",(it['quantity'],now(),it['product_id']))
                conn.execute("INSERT INTO inventory_movements(product_id,movement_type,quantity,unit_cost,reference_type,reference_id,reason,created_at) VALUES(?,?,?,?,?,?,?,?)",(it['product_id'],'반품',it['quantity'],it['unit_cost'],'refund',rid,f'주문 #{order_id} 반품',now()))
        audit(conn,'REFUND_ADD',f'order={order_id} amount={net} restock={restock_flag}');conn.commit()
    except Exception:
        conn.rollback();conn.close();raise
    conn.close();return RedirectResponse('/returns',303)

@app.get("/buybacks", response_class=HTMLResponse)
def buybacks_page(request:Request):
    conn=db();rows=conn.execute("SELECT * FROM buybacks ORDER BY id DESC").fetchall();products=conn.execute("SELECT * FROM products WHERE active=1 ORDER BY name").fetchall();ctx=context_base(conn,'buybacks');ctx.update(rows=rows,products=products,default_margin=setting(conn,'default_buyback_margin','30'));conn.close();return templates.TemplateResponse(request=request,name='buybacks.html',context=ctx)

@app.post("/buybacks/add")
def buyback_add(product_id:int=Form(...),buyback_date:str=Form(...),seller_alias:str=Form(''),quantity:int=Form(1),unit_paid:int=Form(...),expected_sale_price:int=Form(...),memo:str=Form('')):
    conn=db();p=conn.execute("SELECT * FROM products WHERE id=? AND active=1",(product_id,)).fetchone()
    if not p:conn.close();raise HTTPException(404,'상품을 찾을 수 없습니다.')
    qty=max(1,quantity);paid=max(0,unit_paid);expected=max(0,expected_sale_price)
    total=qty*paid; expected_total=qty*expected
    try:
        conn.execute('BEGIN');cur=conn.execute("INSERT INTO buybacks(buyback_date,seller_alias,total_paid,expected_sales,expected_profit,memo,created_at) VALUES(?,?,?,?,?,?,?)",(buyback_date,seller_alias.strip(),total,expected_total,expected_total-total,memo.strip(),now()));bid=cur.lastrowid
        conn.execute("INSERT INTO buyback_items(buyback_id,product_id,product_name,quantity,unit_paid,expected_sale_price) VALUES(?,?,?,?,?,?)",(bid,product_id,p['name'],qty,paid,expected))
        old_stock=int(p['stock']);new_stock=old_stock+qty;new_avg=((float(p['avg_cost'])*old_stock)+(paid*qty))/new_stock if new_stock else paid
        conn.execute("UPDATE products SET stock=?,avg_cost=?,updated_at=? WHERE id=?",(new_stock,new_avg,now(),product_id))
        conn.execute("INSERT INTO inventory_movements(product_id,movement_type,quantity,unit_cost,reference_type,reference_id,reason,created_at) VALUES(?,?,?,?,?,?,?,?)",(product_id,'고객매입',qty,paid,'buyback',bid,'고객 카드 매입',now()));audit(conn,'BUYBACK_ADD',f'#{bid} {p["name"]} x{qty}');conn.commit()
    except Exception:
        conn.rollback();conn.close();raise
    conn.close();return RedirectResponse('/buybacks',303)

@app.get("/alerts", response_class=HTMLResponse)
def alerts_page(request:Request):
    conn=db();items=alert_items(conn);ctx=context_base(conn,'alerts');ctx.update(items=items);conn.close();return templates.TemplateResponse(request=request,name='alerts.html',context=ctx)

@app.get("/simulation", response_class=HTMLResponse)
def simulation_page(request:Request):
    conn=db();ctx=context_base(conn,'simulation')
    products=conn.execute("SELECT id,name,sku,avg_cost,sale_price,stock FROM products WHERE active=1 ORDER BY name").fetchall()
    cash=cashflow_summary(conn); conn.close(); reports=[]; whatifs=[]; readiness=None
    simdir=DATA_DIR/'simulations';simdir.mkdir(exist_ok=True)
    for f in sorted(simdir.glob('simulation_*.json'),reverse=True)[:4]:
        try: reports.append(json.loads(f.read_text(encoding='utf-8')))
        except Exception: pass
    for f in sorted(simdir.glob('whatif_*.json'),reverse=True)[:6]:
        try: whatifs.append(json.loads(f.read_text(encoding='utf-8')))
        except Exception: pass
    latest_readiness=sorted(simdir.glob('release_readiness_*.json'),reverse=True)
    if latest_readiness:
        try: readiness=json.loads(latest_readiness[0].read_text(encoding='utf-8'))
        except Exception: readiness=None
    profiles=[
        {"key":key, **value}
        for key,value in STORE_SIM_PROFILES.items()
    ]
    ctx.update(
        reports=reports,whatifs=whatifs,products=products,
        current_cash=max(0,int(cash['available'])),
        readiness=readiness,readiness_profiles=profiles
    )
    return templates.TemplateResponse(request=request,name='simulation.html',context=ctx)

@app.post("/simulation/run")
def simulation_run(days:int=Form(30),starting_cash:int=Form(8000000),seed:int=Form(20260901)):
    report=run_business_simulation(seed=seed,days=max(7,min(180,days)),starting_cash=max(100000,starting_cash))
    simdir=DATA_DIR/'simulations';simdir.mkdir(exist_ok=True)
    path=simdir/f"simulation_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.json"
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return RedirectResponse('/simulation#full-sim',303)

@app.post("/simulation/release-readiness")
def simulation_release_readiness(seeds_per_profile:int=Form(3)):
    report=run_release_readiness_suite(seeds_per_profile=seeds_per_profile)
    simdir=DATA_DIR/'simulations';simdir.mkdir(exist_ok=True)
    path=simdir/f"release_readiness_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.json"
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return RedirectResponse('/simulation#release-readiness',303)


@app.post("/simulation/what-if")
def simulation_what_if(starting_cash:int=Form(8000000),purchase_qty:int=Form(...),unit_cost:int=Form(...),
                       unit_sale_price:int=Form(...),expected_monthly_units:float=Form(...),fee_rate:float=Form(3.0),
                       shipping_per_order:int=Form(3000),fixed_monthly_cost:int=Form(0),horizon_days:int=Form(30),
                       product_name:str=Form("직접 입력 상품")):
    report=run_what_if(starting_cash=starting_cash,purchase_qty=purchase_qty,unit_cost=unit_cost,unit_sale_price=unit_sale_price,
                       expected_monthly_units=expected_monthly_units,fee_rate=fee_rate,shipping_per_order=shipping_per_order,
                       fixed_monthly_cost=fixed_monthly_cost,horizon_days=horizon_days)
    report['product_name']=product_name.strip() or '직접 입력 상품'
    simdir=DATA_DIR/'simulations';simdir.mkdir(exist_ok=True)
    path=simdir/f"whatif_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.json"
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return RedirectResponse('/simulation#whatif-results',303)

@app.get("/singles", response_class=HTMLResponse)
def singles_workstation(request:Request, q:str="", language:str="", card_condition:str=""):
    conn=db();sql="SELECT * FROM products WHERE active=1 AND category='싱글카드'";params=[]
    if q:
        like=f"%{q}%";sql+=" AND (name LIKE ? OR set_name LIKE ? OR card_number LIKE ? OR rarity LIKE ? OR sku LIKE ?)";params += [like]*5
    if language: sql+=" AND language=?";params.append(language)
    if card_condition: sql+=" AND card_condition=?";params.append(card_condition)
    sql+=" ORDER BY updated_at DESC,id DESC"
    rows=[dict(r) for r in conn.execute(sql,params).fetchall()]
    stats=conn.execute("SELECT COUNT(*) kinds,COALESCE(SUM(stock),0) cards,COALESCE(SUM(stock*avg_cost),0) cost_value,COALESCE(SUM(stock*sale_price),0) retail_value FROM products WHERE active=1 AND category='싱글카드'").fetchone()
    conditions=[r['card_condition'] for r in conn.execute("SELECT DISTINCT card_condition FROM products WHERE active=1 AND category='싱글카드' AND card_condition<>'' ORDER BY card_condition").fetchall()]
    recent=rows[:5]
    language_stats={r['language']:r['cards'] for r in conn.execute("SELECT language,COALESCE(SUM(stock),0) cards FROM products WHERE active=1 AND category='싱글카드' GROUP BY language ORDER BY cards DESC").fetchall()}
    ctx=context_base(conn,'singles');ctx.update(rows=rows,recent=recent,stats=stats,conditions=conditions,language_stats=language_stats,q=q,language=language,card_condition=card_condition,default_margin=setting(conn,'default_buyback_margin','30'),today=date.today().isoformat());conn.close()
    return templates.TemplateResponse(request=request,name='singles.html',context=ctx)

@app.post("/singles/intake")
def singles_intake(name:str=Form(...),set_name:str=Form(""),card_number:str=Form(""),rarity:str=Form(""),language:str=Form("한국어"),card_condition:str=Form("NM"),quantity:int=Form(1),unit_cost:int=Form(0),sale_price:int=Form(0),source:str=Form("inventory"),seller_alias:str=Form(""),intake_date:str=Form(""),notes:str=Form("")):
    qty=max(1,int(quantity));cost=max(0,int(unit_cost));price=max(0,int(sale_price));source='buyback' if source=='buyback' else 'inventory'; intake_date=intake_date or date.today().isoformat()
    conn=db()
    match=conn.execute("""SELECT * FROM products WHERE active=1 AND category='싱글카드' AND lower(name)=lower(?) AND lower(set_name)=lower(?) AND lower(card_number)=lower(?) AND language=? AND lower(rarity)=lower(?) AND lower(card_condition)=lower(?) ORDER BY id LIMIT 1""",(name.strip(),set_name.strip(),card_number.strip(),language,rarity.strip(),card_condition.strip())).fetchone()
    try:
        conn.execute('BEGIN')
        if match:
            pid=int(match['id']);old_stock=int(match['stock']);new_stock=old_stock+qty;new_avg=((float(match['avg_cost'])*old_stock)+(cost*qty))/new_stock if new_stock else cost
            conn.execute("UPDATE products SET stock=?,avg_cost=?,sale_price=?,notes=CASE WHEN ?<>'' THEN ? ELSE notes END,updated_at=? WHERE id=?",(new_stock,new_avg,price if price>0 else int(match['sale_price']),notes.strip(),notes.strip(),now(),pid));product_name=match['name']
        else:
            sku=generate_sku(conn,'싱글카드',language,set_name)
            cur=conn.execute("""INSERT INTO products(name,set_name,category,language,sku,card_number,rarity,card_condition,avg_cost,sale_price,stock,low_stock_threshold,notes,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(name.strip(),set_name.strip(),'싱글카드',language,sku,card_number.strip(),rarity.strip(),card_condition.strip(),cost,price,qty,1,notes.strip(),now(),now()));pid=cur.lastrowid;product_name=name.strip()
        movement_type='고객매입' if source=='buyback' else '싱글입고'
        ref_type='buyback' if source=='buyback' else 'single_intake';ref_id=None
        if source=='buyback':
            total=qty*cost;expected=qty*price
            cur=conn.execute("INSERT INTO buybacks(buyback_date,seller_alias,total_paid,expected_sales,expected_profit,memo,created_at) VALUES(?,?,?,?,?,?,?)",(intake_date,seller_alias.strip(),total,expected,expected-total,notes.strip(),now()));ref_id=cur.lastrowid
            conn.execute("INSERT INTO buyback_items(buyback_id,product_id,product_name,quantity,unit_paid,expected_sale_price) VALUES(?,?,?,?,?,?)",(ref_id,pid,product_name,qty,cost,price))
        conn.execute("INSERT INTO inventory_movements(product_id,movement_type,quantity,unit_cost,reference_type,reference_id,reason,created_at) VALUES(?,?,?,?,?,?,?,?)",(pid,movement_type,qty,cost,ref_type,ref_id,'싱글카드 워크스테이션',now()))
        audit(conn,'SINGLE_INTAKE',f'product={pid} source={source} qty={qty} cost={cost}');conn.commit()
    except Exception:
        conn.rollback();conn.close();raise
    conn.close();return RedirectResponse('/singles',303)

@app.get("/connections/{cid}/products", response_class=HTMLResponse)
def channel_products(request:Request,cid:int,saved:int=0,imported:int=0,unmatched:int=0):
    conn=db();channel=conn.execute("SELECT * FROM channel_profiles WHERE id=?",(cid,)).fetchone()
    if not channel:conn.close();raise HTTPException(404,'판매채널을 찾을 수 없습니다.')
    mappings=conn.execute("""SELECT m.*,p.name,p.sku,p.stock,p.sale_price,p.language,p.category,(p.stock-m.remote_stock) stock_delta FROM channel_product_mappings m JOIN products p ON p.id=m.product_id WHERE m.channel_id=? AND m.active=1 ORDER BY p.name""",(cid,)).fetchall()
    products=conn.execute("SELECT * FROM products WHERE active=1 ORDER BY name,language").fetchall()
    runs=conn.execute("SELECT * FROM channel_sync_runs WHERE channel_id=? ORDER BY id DESC LIMIT 8",(cid,)).fetchall()
    ctx=context_base(conn,'connections');ctx.update(channel=channel,mappings=mappings,products=products,runs=runs,saved=saved,imported=imported,unmatched=unmatched);conn.close()
    return templates.TemplateResponse(request=request,name='channel_products.html',context=ctx)

@app.post("/connections/{cid}/products/map")
def channel_product_map(cid:int,product_id:int=Form(...),external_product_id:str=Form(""),external_sku:str=Form(""),remote_name:str=Form(""),notes:str=Form("")):
    if not external_product_id.strip() and not external_sku.strip(): raise HTTPException(400,'외부 상품 ID 또는 외부 SKU 중 하나는 입력해야 합니다.')
    conn=db();channel=conn.execute("SELECT 1 FROM channel_profiles WHERE id=?",(cid,)).fetchone();product=conn.execute("SELECT 1 FROM products WHERE id=? AND active=1",(product_id,)).fetchone()
    if not channel or not product:conn.close();raise HTTPException(404,'판매채널 또는 상품을 찾을 수 없습니다.')
    ext_id=external_product_id.strip(); ext_sku=external_sku.strip()
    if ext_id and conn.execute("SELECT 1 FROM channel_product_mappings WHERE channel_id=? AND active=1 AND product_id<>? AND external_product_id=? LIMIT 1",(cid,product_id,ext_id)).fetchone():
        conn.close();raise HTTPException(400,'이 외부 상품 ID는 같은 채널의 다른 상품에 이미 연결되어 있습니다.')
    if ext_sku and conn.execute("SELECT 1 FROM channel_product_mappings WHERE channel_id=? AND active=1 AND product_id<>? AND external_sku=? LIMIT 1",(cid,product_id,ext_sku)).fetchone():
        conn.close();raise HTTPException(400,'이 외부 SKU는 같은 채널의 다른 상품에 이미 연결되어 있습니다.')
    conn.execute("""INSERT INTO channel_product_mappings(channel_id,product_id,external_product_id,external_sku,remote_name,notes,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(channel_id,product_id) DO UPDATE SET external_product_id=excluded.external_product_id,external_sku=excluded.external_sku,remote_name=excluded.remote_name,notes=excluded.notes,active=1,updated_at=excluded.updated_at""",(cid,product_id,ext_id,ext_sku,remote_name.strip(),notes.strip(),now(),now()));audit(conn,'CHANNEL_MAP',f'channel={cid} product={product_id}');conn.commit();conn.close();return RedirectResponse(f'/connections/{cid}/products?saved=1',303)

@app.post("/connections/{cid}/products/{mid}/remove")
def channel_product_unmap(cid:int,mid:int):
    conn=db();cur=conn.execute("UPDATE channel_product_mappings SET active=0,updated_at=? WHERE id=? AND channel_id=?",(now(),mid,cid));audit(conn,'CHANNEL_UNMAP',f'channel={cid} mapping={mid}');conn.commit();conn.close()
    if not cur.rowcount:raise HTTPException(404,'상품 매핑을 찾을 수 없습니다.')
    return RedirectResponse(f'/connections/{cid}/products',303)

@app.get("/connections/{cid}/snapshot-template.csv")
def channel_snapshot_template(cid:int):
    conn=db();channel=conn.execute("SELECT * FROM channel_profiles WHERE id=?",(cid,)).fetchone();mappings=conn.execute("SELECT * FROM channel_product_mappings WHERE channel_id=? AND active=1 ORDER BY id",(cid,)).fetchall();conn.close()
    if not channel:raise HTTPException(404,'판매채널을 찾을 수 없습니다.')
    buf=io.StringIO();w=csv.writer(buf);w.writerow(['external_product_id','external_sku','remote_name','remote_stock'])
    for m in mappings:w.writerow([m['external_product_id'],m['external_sku'],m['remote_name'],'' if int(m['remote_stock'])<0 else m['remote_stock']])
    content=('\ufeff'+buf.getvalue()).encode('utf-8');return StreamingResponse(iter([content]),media_type='text/csv; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="channel_{cid}_inventory_snapshot.csv"'})

@app.post("/connections/{cid}/snapshot-import")
async def channel_snapshot_import(cid:int,file:UploadFile=File(...)):
    raw=await file.read()
    try:text=raw.decode('utf-8-sig')
    except UnicodeDecodeError:raise HTTPException(400,'UTF-8 CSV만 지원합니다.')
    reader=csv.DictReader(io.StringIO(text));required={'remote_stock'}
    if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):raise HTTPException(400,'remote_stock 열이 필요합니다.')
    conn=db();channel=conn.execute("SELECT * FROM channel_profiles WHERE id=?",(cid,)).fetchone()
    if not channel:conn.close();raise HTTPException(404,'판매채널을 찾을 수 없습니다.')
    mapped=unmatched=diff=0;stamp=now()
    try:
        conn.execute('BEGIN')
        for r in reader:
            ext_id=(r.get('external_product_id') or '').strip();ext_sku=(r.get('external_sku') or '').strip();remote_name=(r.get('remote_name') or '').strip()
            try:remote_stock=max(0,int(float(r.get('remote_stock') or 0)))
            except Exception:raise HTTPException(400,f"재고 숫자가 올바르지 않습니다: {r.get('remote_stock')}")
            m=None
            if ext_id:m=conn.execute("SELECT m.*,p.stock local_stock FROM channel_product_mappings m JOIN products p ON p.id=m.product_id WHERE m.channel_id=? AND m.active=1 AND m.external_product_id=?",(cid,ext_id)).fetchone()
            if m is None and ext_sku:m=conn.execute("SELECT m.*,p.stock local_stock FROM channel_product_mappings m JOIN products p ON p.id=m.product_id WHERE m.channel_id=? AND m.active=1 AND m.external_sku=?",(cid,ext_sku)).fetchone()
            if m is None:unmatched+=1;continue
            mapped+=1;diff += 1 if int(m['local_stock'])!=remote_stock else 0
            conn.execute("UPDATE channel_product_mappings SET remote_stock=?,remote_name=CASE WHEN ?<>'' THEN ? ELSE remote_name END,last_snapshot_at=?,updated_at=? WHERE id=?",(remote_stock,remote_name,remote_name,stamp,stamp,m['id']))
        conn.execute("INSERT INTO channel_sync_runs(channel_id,source_name,mapped_count,unmatched_count,difference_count,created_at) VALUES(?,?,?,?,?,?)",(cid,Path(file.filename or 'snapshot.csv').name,mapped,unmatched,diff,stamp));conn.execute("UPDATE channel_profiles SET last_sync_at=?,connector_status=? WHERE id=?",(stamp,'CSV 스냅샷 확인',cid));audit(conn,'CHANNEL_SNAPSHOT_IMPORT',f'channel={cid} mapped={mapped} unmatched={unmatched} diff={diff}');conn.commit()
    except HTTPException:
        conn.rollback();conn.close();raise
    except Exception:
        conn.rollback();conn.close();raise
    conn.close();return RedirectResponse(f'/connections/{cid}/products?imported={mapped}&unmatched={unmatched}',303)

@app.get("/connections/{cid}/sync-plan.csv")
def channel_sync_plan(cid:int):
    conn=db();channel=conn.execute("SELECT * FROM channel_profiles WHERE id=?",(cid,)).fetchone();rows=conn.execute("""SELECT m.*,p.name,p.sku,p.stock local_stock FROM channel_product_mappings m JOIN products p ON p.id=m.product_id WHERE m.channel_id=? AND m.active=1 ORDER BY p.name""",(cid,)).fetchall();conn.close()
    if not channel:raise HTTPException(404,'판매채널을 찾을 수 없습니다.')
    buf=io.StringIO();w=csv.writer(buf);w.writerow(['external_product_id','external_sku','local_product','local_sku','remote_stock','target_stock','difference','action'])
    for r in rows:
        remote=int(r['remote_stock']);local=int(r['local_stock']);difference='' if remote<0 else local-remote;action='CHECK_REMOTE_FIRST' if remote<0 else ('NO_CHANGE' if remote==local else 'SET_REMOTE_STOCK')
        w.writerow([r['external_product_id'],r['external_sku'],r['name'],r['sku'],'' if remote<0 else remote,local,difference,action])
    content=('\ufeff'+buf.getvalue()).encode('utf-8');return StreamingResponse(iter([content]),media_type='text/csv; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="channel_{cid}_sync_plan.csv"'})

@app.get("/api/channel/{name}")
def channel_profile(name:str):
    conn=db();r=conn.execute("SELECT fee_rate,fixed_fee,default_shipping_cost FROM channel_profiles WHERE name=?",(name,)).fetchone();conn.close();return dict(r) if r else {'fee_rate':0,'fixed_fee':0,'default_shipping_cost':0}

@app.exception_handler(StarletteHTTPException)
async def starlette_http_exception_handler(request: Request, exc: StarletteHTTPException):
    if request.url.path.startswith("/api/"):
        return JSONResponse(status_code=exc.status_code, content={"detail": str(exc.detail)})
    conn = db()
    try:
        ctx = context_base(conn, "")
    finally:
        conn.close()
    ctx.update(
        code=exc.status_code,
        message=str(exc.detail),
        support_id="",
    )
    return templates.TemplateResponse(
        request=request,
        name="error.html",
        context=ctx,
        status_code=exc.status_code,
    )
