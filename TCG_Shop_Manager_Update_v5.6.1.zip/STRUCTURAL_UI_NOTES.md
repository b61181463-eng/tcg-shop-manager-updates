# v5.4.1 Structural UI

This release responds to real Windows screenshots from v5.4.0.

Changes:
- Cache-bust style.css/app.js using ?v={{ version }}
- Remove equal-card-row dashboard structure
- New asymmetric Operations Cockpit + vertical Today Queue
- New four-size Bento business metrics
- New Sales Pulse / Top Cards workspace
- New Signals / Restock lower workspace
- Replace v5.4 login with simpler Vault Gate layout
- No database/business logic changes
