"""Offline release-readiness runner for TCG Shop Manager.

Run:
    python release_readiness_qa.py
"""
import json
import tempfile
import os
from pathlib import Path

tmp = Path(tempfile.mkdtemp(prefix="tcg_release_readiness_"))
os.environ.setdefault("TCG_SHOP_DATA_DIR", str(tmp))

import app

report = app.run_release_readiness_suite(seeds_per_profile=3)
out = Path(__file__).resolve().parent / "RELEASE_READINESS_REPORT.json"
out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

print("PASS" if report["pass"] else "CHECK")
print("score:", report["score"])
print("runs:", report["total_runs"])
print("simulated days:", report["total_simulated_days"])
print("orders:", report["total_orders"])
print("report:", out)
