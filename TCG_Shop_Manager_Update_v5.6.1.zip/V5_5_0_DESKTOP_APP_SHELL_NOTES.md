# TCG Shop Manager v5.5.0 — Desktop App Shell

## What changed
The classic Windows edition is now primarily a native desktop application shell.

Launch flow:
1. Native Card Vault boot splash
2. Local FastAPI backend
3. Microsoft Edge WebView2 desktop window
4. No browser address bar, tabs, favorites bar, or browser chrome

## Desktop behavior
- Standard Windows title bar with minimize / maximize / close
- TCG Shop Manager window title and icon
- Internal navigation remains inside the app window
- External links open in the user's default browser
- WebView2 downloads are enabled for CSV/backups/exports
- Persistent WebView2 profile under the app data directory
- Named-mutex single instance
- Second shortcut launch focuses the existing window where possible
- Closing the app window stops the currently active local backend
- Backend-close logic re-resolves /health, so it remains correct across an in-app update

## Updates
v5.5.0 and later pass UI mode into update_helper.
In desktop mode, the existing WebView window reconnects after the local backend restart;
the updater does not open a new browser tab.

Important transition note:
The v5.4.3 -> v5.5.0 update is executed by the OLD v5.4.3 helper, so that one transition
may still open a browser once after update. Close it and launch the desktop shortcut once.
Future v5.5+ updates stay inside the desktop shell.

## Dependencies
- pywebview 6.2.1 on Windows
- pythonnet 3.1.0 on Windows
- Microsoft Edge WebView2 Runtime (normally present on Windows 10/11)

A browser fallback exists only as a recovery path if WebView2 cannot start.
