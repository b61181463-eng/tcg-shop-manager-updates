﻿param(
  [string]$Target = "$env:LOCALAPPDATA\Programs\TCGShopManager"
)
$ErrorActionPreference = "Stop"
$Source = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Get-Command pythonw.exe -ErrorAction SilentlyContinue)) {
  Write-Host ""
  Write-Host "TCG Shop Manager v5.0.1 설치를 계속하려면 Python 3가 필요합니다."
  Write-Host "상용 EXE/MSI 번들 런타임은 추후 코드서명 패키지에서 제공할 수 있습니다."
  exit 2
}

$Stage = "$Target.installing"
$Previous = "$Target.previous"

if (Test-Path $Stage) { Remove-Item $Stage -Recurse -Force }
if (Test-Path $Previous) { Remove-Item $Previous -Recurse -Force }

New-Item -ItemType Directory -Path $Stage -Force | Out-Null
Get-ChildItem $Source -Force | Where-Object {
  $_.Name -notin @('__pycache__','publisher_data')
} | ForEach-Object {
  Copy-Item $_.FullName -Destination $Stage -Recurse -Force
}

if (-not (Test-Path (Join-Path $Stage "launcher.pyw"))) { throw "launcher.pyw 누락" }
if (-not (Test-Path (Join-Path $Stage "MANIFEST.json"))) { throw "MANIFEST.json 누락" }

if (Test-Path $Target) { Move-Item $Target $Previous }
try {
  Move-Item $Stage $Target
} catch {
  if (Test-Path $Previous) { Move-Item $Previous $Target }
  throw
}

$WshShell = New-Object -ComObject WScript.Shell
$StartMenu = [Environment]::GetFolderPath('Programs')
$ShortcutPath = Join-Path $StartMenu 'TCG Shop Manager.lnk'
$Shortcut = $WshShell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = (Get-Command pythonw.exe).Source
$Shortcut.Arguments = '"' + (Join-Path $Target 'launcher.pyw') + '"'
$Shortcut.WorkingDirectory = $Target
$Shortcut.Save()

if (Test-Path $Previous) { Remove-Item $Previous -Recurse -Force }

Write-Host ""
Write-Host "TCG Shop Manager v5.0.1 설치 완료"
Write-Host "프로그램: $Target"
Write-Host "매장 데이터: $env:LOCALAPPDATA\TCGShopManager"
Write-Host "프로그램을 재설치/업데이트해도 매장 데이터는 별도 보존됩니다."
