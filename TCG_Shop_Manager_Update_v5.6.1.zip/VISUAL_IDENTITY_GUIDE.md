# Card Vault / Collector Terminal

v5.4 시각 정체성 목표:
- 일반 SaaS/ERP 템플릿 느낌 감소
- TCG 매장 운영 콘솔이라는 인상 강화
- 특정 TCG 브랜드/공식 카드 디자인 모사 금지
- holographic spectrum은 얇은 강조선과 장식에만 사용
- 업무 가독성은 light UI로 유지
