# v5.5.4 Neutral Studio + Native Icon Fix
- Final theme isolated into neutral-studio.css loaded last.
- Light-dominant, low-color retail UI; dark sidebar; single brick accent.
- No neon/gold/purple/cyan/glow/grid decoration.
- Taskbar icon discovery uses EnumWindows + current PID, not title matching.
- Repeated WM_SETICON/class icon injection keeps HICON handles alive and refreshes shell.
