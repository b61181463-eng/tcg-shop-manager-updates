# TCG Shop Manager v5.5.0 — Desktop App Shell RC

v5.4.3의 Vault Desk / Card Lab / Typography UI를 유지하면서
실행 방식을 브라우저 중심에서 WebView2 기반 Windows 데스크톱 앱 창으로 전환한 RC입니다.

핵심:
- 주소창/브라우저 탭 없는 전용 Windows 창
- 기존 Card Vault 부트 화면 유지
- 단일 실행 및 기존 창 포커스
- 다운로드 허용 / 외부 링크만 기본 브라우저
- 앱 창 종료 시 로컬 백엔드 정리
- v5.5 이후 업데이트는 데스크톱 창 안에서 재연결
