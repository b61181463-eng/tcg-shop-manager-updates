﻿param(
  [string]$Target = "$env:LOCALAPPDATA\Programs\TCGShopManager",
  [switch]$RemoveData
)
$ErrorActionPreference = "Stop"

$StartMenu = [Environment]::GetFolderPath('Programs')
$ShortcutPath = Join-Path $StartMenu 'TCG Shop Manager.lnk'
if (Test-Path $ShortcutPath) { Remove-Item $ShortcutPath -Force }

if (Test-Path $Target) {
  Remove-Item $Target -Recurse -Force
  Write-Host "프로그램 파일을 제거했습니다: $Target"
}

$Data = "$env:LOCALAPPDATA\TCGShopManager"
if ($RemoveData) {
  if (Test-Path $Data) {
    Remove-Item $Data -Recurse -Force
    Write-Host "매장 데이터도 제거했습니다: $Data"
  }
} else {
  Write-Host "매장 데이터는 보존했습니다: $Data"
  Write-Host "데이터까지 지우려면 관리자 PowerShell에서 .\UNINSTALL_WINDOWS.ps1 -RemoveData 를 실행하세요."
}
