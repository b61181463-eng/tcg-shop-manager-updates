# Windows updater folder-lock hotfix

- Waits for the exact old server PID to disappear.
- Waits for the local listener to close.
- Retries WinError 5/32 directory handoff for up to 25 seconds.
- Restores the old program immediately if the first directory move succeeds but the second fails.
- Starts future Uvicorn processes with their working directory under the persistent runtime folder instead of the program directory.

This addresses transient Windows folder locks during in-place updates.
