from __future__ import annotations

import ctypes
import hashlib
import importlib.util
import json
import os
import socket
import subprocess
import sys
import time
import urllib.request
import webbrowser
from datetime import datetime
from pathlib import Path

BASE = Path(__file__).resolve().parent
REQ = BASE / "requirements.txt"
MANIFEST = BASE / "MANIFEST.json"
HOST = "127.0.0.1"
PORT_FIRST = 8765
PORT_LAST = 8795
EXPECTED_VERSION = "5.5.3"
APP_ID = "tcg-shop-manager"
APP_NAME = "TCG Shop Manager"
SHELL_MUTEX_NAME = "Local\\TCGShopManagerDesktopShell_v2"
WINDOW_TITLE = "TCG Shop Manager"
APP_USER_MODEL_ID = "HaloWorks.TCGShopManager"



class BootSplash:
    """Small native boot window that reflects real launcher progress."""

    def __init__(self) -> None:
        self.root = None
        self.canvas = None
        self.status_var = None
        self.detail_var = None
        self.progress = 0
        self.started = time.time()
        self._icon = None
        try:
            import tkinter as tk
            self.tk = tk
            root = tk.Tk()
            self.root = root
            root.overrideredirect(True)
            root.configure(bg="#07111d")
            root.attributes("-topmost", True)

            width, height = 620, 360
            sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
            x = max(0, (sw - width) // 2)
            y = max(0, (sh - height) // 2 - 20)
            root.geometry(f"{width}x{height}+{x}+{y}")

            frame = tk.Frame(root, bg="#07111d", highlightthickness=1, highlightbackground="#173047")
            frame.pack(fill="both", expand=True)

            top = tk.Frame(frame, bg="#07111d")
            top.pack(fill="x", padx=30, pady=(26, 0))

            icon_path = BASE / "static" / "app-icon-96.png"
            if icon_path.exists():
                try:
                    self._icon = tk.PhotoImage(file=str(icon_path))
                    tk.Label(top, image=self._icon, bg="#07111d").pack(side="left")
                except Exception:
                    pass

            brand = tk.Frame(top, bg="#07111d")
            brand.pack(side="left", padx=(15, 0))
            tk.Label(
                brand, text="TCG SHOP MANAGER", bg="#07111d", fg="#edf7ff",
                font=("Segoe UI", 15, "bold")
            ).pack(anchor="w")
            tk.Label(
                brand, text=f"VAULT DESK  /  v{EXPECTED_VERSION}", bg="#07111d", fg="#6e879d",
                font=("Consolas", 8, "bold")
            ).pack(anchor="w", pady=(3, 0))

            tk.Label(
                frame, text="CARD VAULT BOOT SEQUENCE", bg="#07111d", fg="#27d9d0",
                font=("Consolas", 9, "bold")
            ).pack(anchor="w", padx=32, pady=(42, 0))

            self.status_var = tk.StringVar(value="시스템 준비 중")
            tk.Label(
                frame, textvariable=self.status_var, bg="#07111d", fg="#f5fbff",
                font=("Segoe UI", 22, "bold")
            ).pack(anchor="w", padx=30, pady=(8, 0))

            self.detail_var = tk.StringVar(value="로컬 운영 환경을 확인하고 있습니다.")
            tk.Label(
                frame, textvariable=self.detail_var, bg="#07111d", fg="#7f97aa",
                font=("Segoe UI", 9)
            ).pack(anchor="w", padx=32, pady=(7, 0))

            self.canvas = tk.Canvas(
                frame, height=34, bg="#07111d", highlightthickness=0, bd=0
            )
            self.canvas.pack(fill="x", padx=31, pady=(43, 0))
            self._draw_progress()

            foot = tk.Frame(frame, bg="#07111d")
            foot.pack(fill="x", padx=32, pady=(8, 0))
            tk.Label(
                foot, text="LOCAL-FIRST", bg="#07111d", fg="#5e788f",
                font=("Consolas", 7, "bold")
            ).pack(side="left")
            tk.Label(
                foot, text="HALO WORKS", bg="#07111d", fg="#5e788f",
                font=("Consolas", 7, "bold")
            ).pack(side="right")

            root.update_idletasks()
            root.update()
            try:
                root.attributes("-topmost", False)
            except Exception:
                pass
        except Exception as exc:
            write_log_safe = globals().get("write_log")
            if callable(write_log_safe):
                try:
                    write_log_safe(f"Splash unavailable: {exc!r}")
                except Exception:
                    pass
            self.root = None

    def _draw_progress(self) -> None:
        if not self.canvas:
            return
        try:
            w = max(1, self.canvas.winfo_width() or 556)
            self.canvas.delete("all")
            y = 13
            self.canvas.create_rectangle(0, y, w, y + 4, fill="#13283a", outline="")
            fill_w = int(w * max(0, min(100, self.progress)) / 100)
            if fill_w > 0:
                self.canvas.create_rectangle(0, y, fill_w, y + 4, fill="#27d9d0", outline="")
                glow_start = max(0, fill_w - 48)
                self.canvas.create_rectangle(glow_start, y, fill_w, y + 4, fill="#5a86ff", outline="")
            self.canvas.create_text(
                w, 29, text=f"{int(self.progress):02d}%", anchor="e",
                fill="#6d879e", font=("Consolas", 7, "bold")
            )
        except Exception:
            pass

    def step(self, status: str, detail: str, progress: int) -> None:
        self.progress = progress
        if not self.root:
            return
        try:
            self.status_var.set(status)
            self.detail_var.set(detail)
            self._draw_progress()
            self.root.update_idletasks()
            self.root.update()
        except Exception:
            pass

    def finish(self, detail: str = "운영 데스크를 여는 중입니다.") -> None:
        self.step("준비 완료", detail, 100)
        if not self.root:
            return
        # Keep the branded boot screen visible long enough to register,
        # without artificially slowing a genuinely slow startup.
        minimum = 0.85
        remaining = minimum - (time.time() - self.started)
        end = time.time() + max(0.0, remaining)
        try:
            while time.time() < end:
                self.root.update_idletasks()
                self.root.update()
                time.sleep(0.03)
        except Exception:
            pass
        self.close()

    def close(self) -> None:
        if self.root:
            try:
                self.root.destroy()
            except Exception:
                pass
            self.root = None





def apply_windows_app_identity() -> None:
    """Give the pythonw-hosted desktop shell a stable Windows app identity."""
    if os.name != "nt":
        return
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_USER_MODEL_ID)
        write_log(f"Windows AppUserModelID applied: {APP_USER_MODEL_ID}")
    except Exception as exc:
        write_log(f"AppUserModelID apply failed: {exc!r}")

def isolate_desktop_shell_runtime() -> Path:
    """
    Move the long-lived desktop-shell process completely outside the program directory.

    v5.5 introduced a persistent WebView2 launcher process. If its current working
    directory remains inside %LOCALAPPDATA%\\Programs\\TCGShopManager, Windows keeps
    the program directory busy and the updater cannot atomically rename it.

    This function changes the shell CWD to the persistent data/runtime directory
    before WebView2 is created and mirrors the window icon there so the long-lived
    shell never needs an open resource path under the swappable program directory.
    """
    runtime_dir = get_data_dir() / "runtime" / "desktop-shell"
    runtime_dir.mkdir(parents=True, exist_ok=True)
    try:
        os.chdir(runtime_dir)
        write_log(f"Desktop shell CWD isolated to {runtime_dir}")
    except Exception as exc:
        write_log(f"Desktop shell CWD isolation failed: {exc!r}")
        raise
    return runtime_dir


def shell_icon_path() -> Path | None:
    runtime_dir = get_data_dir() / "runtime" / "desktop-shell"
    runtime_dir.mkdir(parents=True, exist_ok=True)
    preferred = BASE / "static" / "app-icon.ico"
    src = preferred if preferred.exists() else (BASE / "static" / "favicon.ico")
    dst = runtime_dir / "tcg-shop-manager-v552.ico"
    try:
        if src.exists():
            src_hash = hashlib.sha256(src.read_bytes()).hexdigest()
            dst_hash = hashlib.sha256(dst.read_bytes()).hexdigest() if dst.exists() else ""
            if src_hash != dst_hash:
                tmp = dst.with_suffix(".tmp")
                shutil.copy2(src, tmp)
                os.replace(tmp, dst)
            return dst
    except Exception as exc:
        write_log(f"Shell icon staging failed: {exc!r}")
    return None


def acquire_shell_mutex():
    """Hold a Windows named mutex for the entire lifetime of the desktop window."""
    if os.name != "nt":
        return None
    kernel32 = ctypes.windll.kernel32
    handle = kernel32.CreateMutexW(None, False, SHELL_MUTEX_NAME)
    if not handle:
        raise OSError("CreateMutexW failed")
    if kernel32.GetLastError() == 183:  # ERROR_ALREADY_EXISTS
        kernel32.CloseHandle(handle)
        return False
    return handle


def release_shell_mutex(handle) -> None:
    if os.name == "nt" and handle not in (None, False):
        try:
            ctypes.windll.kernel32.ReleaseMutex(handle)
        except Exception:
            pass
        try:
            ctypes.windll.kernel32.CloseHandle(handle)
        except Exception:
            pass


def focus_existing_window() -> bool:
    """Bring the existing native app window forward when the shortcut is clicked twice."""
    if os.name != "nt":
        return False
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.FindWindowW(None, WINDOW_TITLE)
        if not hwnd:
            return False
        SW_RESTORE = 9
        user32.ShowWindow(hwnd, SW_RESTORE)
        user32.SetForegroundWindow(hwnd)
        return True
    except Exception as exc:
        write_log(f"Existing-window focus failed: {exc!r}")
        return False


def desktop_profile_dir() -> Path:
    p = get_data_dir() / "webview-profile"
    p.mkdir(parents=True, exist_ok=True)
    return p


def stop_tcg_server_on_port(port: int) -> None:
    """
    Stop whichever confirmed TCG Shop Manager backend currently owns this shell's port.
    This intentionally re-reads /health so it also stops a backend that was replaced
    by the updater while the desktop window stayed open.
    """
    info = health_info(port, timeout=0.8)
    if not is_tcg_server(info):
        return
    pid = None
    try:
        pid = int(info.get("pid", 0) or 0)
    except Exception:
        pid = None
    if not pid:
        pid = listener_pid_for_port_windows(port)
    if not pid or pid == os.getpid():
        return
    try:
        if os.name == "nt":
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            subprocess.run(
                ["taskkill", "/PID", str(pid), "/F"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=flags,
                timeout=6,
            )
        else:
            import signal
            os.kill(pid, signal.SIGTERM)
        deadline = time.time() + 5.0
        while time.time() < deadline:
            if port_is_free(port):
                break
            time.sleep(0.12)
        write_log(f"Desktop shell close: backend stop requested port={port} pid={pid}")
    except Exception as exc:
        write_log(f"Desktop shell close cleanup failed port={port} pid={pid}: {exc!r}")



def apply_native_window_icon() -> bool:
    """
    Force the actual Win32 WebView2 host window to use the TCG Shop Manager icon.
    AppUserModelID alone does not always override pythonw.exe's taskbar icon.
    """
    if os.name != "nt":
        return False
    try:
        icon = shell_icon_path()
        if not icon or not icon.exists():
            write_log("Native icon apply skipped: staged icon missing")
            return False

        user32 = ctypes.windll.user32
        hwnd = user32.FindWindowW(None, WINDOW_TITLE)
        if not hwnd:
            write_log("Native icon apply skipped: window handle not found")
            return False

        IMAGE_ICON = 1
        LR_LOADFROMFILE = 0x0010
        LR_DEFAULTSIZE = 0x0040
        WM_SETICON = 0x0080
        ICON_SMALL = 0
        ICON_BIG = 1

        big = user32.LoadImageW(None, str(icon), IMAGE_ICON, 256, 256, LR_LOADFROMFILE)
        small = user32.LoadImageW(None, str(icon), IMAGE_ICON, 32, 32, LR_LOADFROMFILE)
        if not big:
            big = user32.LoadImageW(None, str(icon), IMAGE_ICON, 0, 0, LR_LOADFROMFILE | LR_DEFAULTSIZE)
        if not small:
            small = user32.LoadImageW(None, str(icon), IMAGE_ICON, 0, 0, LR_LOADFROMFILE | LR_DEFAULTSIZE)

        if big:
            user32.SendMessageW(hwnd, WM_SETICON, ICON_BIG, big)
        if small:
            user32.SendMessageW(hwnd, WM_SETICON, ICON_SMALL, small)

        # Also update class icons so taskbar/titlebar refresh more reliably.
        GCLP_HICON = -14
        GCLP_HICONSM = -34
        set_class = getattr(user32, "SetClassLongPtrW", None)
        if set_class:
            if big:
                set_class(hwnd, GCLP_HICON, big)
            if small:
                set_class(hwnd, GCLP_HICONSM, small)

        write_log(f"Native Win32 window icon applied hwnd={hwnd}")
        return True
    except Exception as exc:
        write_log(f"Native Win32 icon apply failed: {exc!r}")
        return False


def apply_native_window_icon_delayed(*_args) -> None:
    """Retry after WebView2 creates its top-level window."""
    if os.name != "nt":
        return
    for delay in (0.05, 0.20, 0.50, 1.0):
        try:
            time.sleep(delay)
            if apply_native_window_icon():
                return
        except Exception:
            pass


def open_desktop_window(port: int) -> bool:
    """
    Open the local FastAPI UI in a real native Windows application window.
    Returns True if the WebView2 UI ran; False means caller may use recovery fallback.
    """
    try:
        import webview
    except Exception as exc:
        write_log(f"pywebview import failed: {exc!r}")
        return False

    try:
        # WebView2 desktop-app behavior.
        webview.settings["ALLOW_DOWNLOADS"] = True
        webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = True
        webview.settings["OPEN_DEVTOOLS_IN_DEBUG"] = False
        webview.settings["SHOW_DEFAULT_MENUS"] = False

        window = webview.create_window(
            WINDOW_TITLE,
            url_for(port, "/"),
            width=1500,
            height=940,
            min_size=(1050, 680),
            resizable=True,
            fullscreen=False,
            frameless=False,
            focus=True,
            maximized=False,
            confirm_close=False,
            background_color="#EEF3F7",
            text_select=True,
            zoomable=True,
        )

        def on_closed(*_args):
            # The update helper may have replaced the original child process while
            # this window stayed open, so resolve the current backend from /health.
            stop_tcg_server_on_port(port)

        window.events.closed += on_closed
        try:
            window.events.loaded += apply_native_window_icon_delayed
        except Exception as exc:
            write_log(f"Native icon event hook failed: {exc!r}")

        icon = shell_icon_path()
        write_log(f"Opening native WebView2 shell on port={port}")
        webview.start(
            gui="edgechromium",
            debug=False,
            private_mode=False,
            storage_path=str(desktop_profile_dir()),
            icon=str(icon) if icon and icon.exists() else None,
        )
        return True
    except Exception as exc:
        write_log(f"WebView2 shell failed: {exc!r}")
        return False


def get_data_dir() -> Path:
    if os.name == "nt":
        root = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "TCGShopManager"
    else:
        root = Path.home() / ".local" / "share" / "tcg-shop-manager"
    (root / "logs").mkdir(parents=True, exist_ok=True)
    (root / "runtime").mkdir(parents=True, exist_ok=True)
    return root


def log_path() -> Path:
    return get_data_dir() / "logs" / "launcher.log"


def write_log(text: str) -> None:
    try:
        with log_path().open("a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().isoformat(timespec='seconds')}] {text}\n")
    except Exception:
        pass


def message(title: str, text: str, error: bool = False) -> None:
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        (messagebox.showerror if error else messagebox.showinfo)(title, text, parent=root)
        root.destroy()
    except Exception:
        pass


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def validate_installation() -> bool:
    required = [BASE / "app.py", REQ, BASE / "templates", BASE / "static", MANIFEST, BASE / "VERSION"]
    missing = [p.name for p in required if not p.exists()]
    if missing:
        text = (
            "프로그램 파일 일부를 찾을 수 없습니다.\n\n"
            "ZIP 안에서 직접 실행하지 말고 '모두 압축 풀기' 후 실행해주세요.\n\n"
            f"누락: {', '.join(missing)}"
        )
        write_log("Installation validation failed: " + ", ".join(missing))
        message("TCG Shop Manager", text, True)
        return False

    try:
        manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
        if manifest.get("version") != EXPECTED_VERSION:
            raise ValueError(f"manifest version={manifest.get('version')!r}")
        version_text = (BASE / "VERSION").read_text(encoding="utf-8").strip()
        if version_text != EXPECTED_VERSION:
            raise ValueError(f"VERSION file={version_text!r}")
        bad = []
        for rel, expected in manifest.get("files", {}).items():
            path = BASE / rel
            if not path.is_file() or sha256_file(path) != expected:
                bad.append(rel)
        if bad:
            raise ValueError("hash mismatch: " + ", ".join(bad[:8]))
    except Exception as exc:
        write_log(f"Package consistency check failed: {exc!r}")
        message(
            "TCG Shop Manager 업데이트 오류",
            "서로 다른 버전의 프로그램 파일이 한 폴더에 섞여 있습니다.\n\n"
            "기존 폴더에 일부 파일만 덮어쓰지 말고, 새 ZIP을 별도 폴더에 완전히 압축 해제한 뒤 실행해주세요.\n"
            "매장 데이터는 별도 저장되므로 새 폴더를 사용해도 그대로 유지됩니다.\n\n"
            f"상세: {exc}\n로그: {log_path()}",
            True,
        )
        return False
    return True


def ensure_deps() -> bool:
    needed = ["fastapi", "uvicorn", "jinja2", "multipart", "itsdangerous", "cryptography"]
    if os.name == "nt":
        needed += ["webview", "clr"]
    if all(importlib.util.find_spec(x) for x in needed):
        return True
    try:
        message("TCG Shop Manager", "처음 실행에 필요한 구성 요소를 설치합니다.\n잠시 기다려주세요.")
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-r", str(REQ)],
            cwd=str(BASE), capture_output=True, text=True, creationflags=flags,
        )
        write_log(f"pip exit={result.returncode}\nstdout={result.stdout[-4000:]}\nstderr={result.stderr[-4000:]}")
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "pip 설치 실패")
        return all(importlib.util.find_spec(x) for x in needed)
    except Exception as exc:
        write_log(f"Dependency installation failed: {exc!r}")
        message("TCG Shop Manager 실행 실패", f"필수 구성 요소 설치에 실패했습니다.\n\n{exc}\n\n로그: {log_path()}", True)
        return False


def launcher_log_tail(max_chars: int = 3000) -> str:
    try:
        return log_path().read_text(encoding="utf-8", errors="replace")[-max_chars:]
    except Exception:
        return ""


def url_for(port: int, path: str = "") -> str:
    return f"http://{HOST}:{port}{path}"


def health_info(port: int, timeout: float = 0.35) -> dict | None:
    try:
        with urllib.request.urlopen(url_for(port, "/health"), timeout=timeout) as r:
            if r.status != 200:
                return None
            data = json.loads(r.read().decode("utf-8"))
            return data if isinstance(data, dict) else None
    except Exception:
        return None


def is_tcg_server(info: dict | None) -> bool:
    if not info or not info.get("ok"):
        return False
    if info.get("app_id") == APP_ID:
        return True
    # Compatibility with v1.0-v1.2, whose /health did not expose app_id.
    db_path = str(info.get("db", "")).replace("/", "\\").lower()
    return "tcgshopmanager" in db_path and bool(info.get("version"))


def port_is_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind((HOST, port))
            return True
        except OSError:
            return False



def listener_pid_for_port_windows(port: int) -> int | None:
    """Return the PID listening on a confirmed local port on Windows."""
    if os.name != "nt":
        return None
    try:
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        result = subprocess.run(
            ["netstat", "-ano", "-p", "tcp"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="ignore",
            creationflags=flags,
            timeout=6,
        )
        needle = f":{port}"
        for raw in result.stdout.splitlines():
            line = raw.strip()
            if not line or needle not in line:
                continue
            parts = line.split()
            if len(parts) < 5:
                continue
            local = parts[1]
            if not local.endswith(needle):
                continue
            try:
                return int(parts[-1])
            except ValueError:
                continue
    except Exception as exc:
        write_log(f"netstat PID lookup failed for port {port}: {exc!r}")
    return None


def stop_confirmed_tcg_server(port: int, info: dict) -> bool:
    """Stop only a server whose /health response was already confirmed as this app."""
    pid = None
    try:
        if info.get("pid"):
            pid = int(info["pid"])
    except Exception:
        pid = None
    if pid is None:
        pid = listener_pid_for_port_windows(port)
    if not pid or pid == os.getpid():
        write_log(f"Could not resolve safe PID for old TCG server on port {port}")
        return False

    try:
        if os.name == "nt":
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            result = subprocess.run(
                ["taskkill", "/PID", str(pid), "/F"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="ignore",
                creationflags=flags,
                timeout=8,
            )
            write_log(
                f"Stopping old TCG server port={port} pid={pid} version={info.get('version')} "
                f"taskkill_rc={result.returncode} stdout={result.stdout[-500:]} stderr={result.stderr[-500:]}"
            )
            if result.returncode != 0:
                return False
        else:
            import signal
            os.kill(pid, signal.SIGTERM)

        deadline = time.time() + 5
        while time.time() < deadline:
            if port_is_free(port):
                return True
            time.sleep(0.15)
        return port_is_free(port)
    except Exception as exc:
        write_log(f"Failed to stop old TCG server on port {port}, pid={pid}: {exc!r}")
        return False


def cleanup_older_tcg_servers() -> list[tuple[int, str, bool]]:
    results = []
    for port in range(PORT_FIRST, PORT_LAST + 1):
        info = health_info(port)
        if not is_tcg_server(info):
            continue
        version = str(info.get("version", "?"))
        if version == EXPECTED_VERSION:
            continue
        ok = stop_confirmed_tcg_server(port, info)
        results.append((port, version, ok))
    return results


def find_existing_current() -> int | None:
    for port in range(PORT_FIRST, PORT_LAST + 1):
        info = health_info(port)
        if is_tcg_server(info) and str(info.get("version")) == EXPECTED_VERSION:
            return port
    return None


def find_free_port() -> int | None:
    for port in range(PORT_FIRST, PORT_LAST + 1):
        if port_is_free(port):
            return port
    return None


def start_server(port: int) -> subprocess.Popen:
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    flags |= getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env["TCG_SHOP_OPEN_BROWSER"] = "0"
    env["TCG_SHOP_UI_MODE"] = "desktop"
    env["TCG_SHOP_PORT"] = str(port)
    log = log_path().open("ab", buffering=0)
    write_log(f"Starting v{EXPECTED_VERSION} server with Python={sys.executable}, base={BASE}, port={port}")
    runtime_dir = get_data_dir() / "runtime"
    runtime_dir.mkdir(parents=True, exist_ok=True)
    proc = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "app:app", "--app-dir", str(BASE), "--host", HOST, "--port", str(port), "--log-level", "info"],
        cwd=str(runtime_dir), env=env, stdout=log, stderr=subprocess.STDOUT, creationflags=flags,
    )
    log.close()
    return proc


def wait_for_server(proc: subprocess.Popen, port: int, seconds: float = 25.0) -> bool:
    deadline = time.time() + seconds
    while time.time() < deadline:
        info = health_info(port, timeout=0.8)
        if is_tcg_server(info) and str(info.get("version")) == EXPECTED_VERSION:
            return True
        if proc.poll() is not None:
            write_log(f"Server exited early with code {proc.returncode}")
            return False
        time.sleep(0.25)
    write_log("Server startup timeout")
    return False


def save_runtime(port: int, pid: int) -> None:
    try:
        payload = {
            "app_id": APP_ID,
            "version": EXPECTED_VERSION,
            "port": port,
            "pid": pid,
            "base": str(BASE),
            "started_at": datetime.now().isoformat(timespec="seconds"),
        }
        (get_data_dir() / "runtime" / "server.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as exc:
        write_log(f"Runtime metadata write failed: {exc!r}")


def main() -> None:
    apply_windows_app_identity()
    # IMPORTANT: desktop shell remains alive while the app window is open.
    # Move its working directory outside the swappable program folder first.
    isolate_desktop_shell_runtime()
    mutex = acquire_shell_mutex()
    if mutex is False:
        focus_existing_window()
        return

    splash = BootSplash()
    shell_port = None
    try:
        write_log(f"Desktop launcher v{EXPECTED_VERSION} invoked from {BASE}")

        splash.step("패키지 확인", "프로그램 파일과 버전 무결성을 확인하고 있습니다.", 10)
        if not validate_installation():
            splash.close()
            return

        splash.step("런타임 확인", "WebView2 데스크톱 구성 요소와 로컬 엔진을 확인합니다.", 23)
        if not ensure_deps():
            splash.close()
            return

        splash.step("세션 확인", "이미 실행 중인 로컬 운영 엔진이 있는지 확인합니다.", 36)
        existing = find_existing_current()
        if existing is not None:
            shell_port = existing
            write_log(f"Attaching native shell to existing v{EXPECTED_VERSION} backend port={existing}")
            splash.step("앱 창 준비", "기존 운영 세션을 전용 Windows 창에 연결합니다.", 94)
            splash.finish("주소 표시줄 없는 TCG Shop Manager 창을 여는 중입니다.")
            if not open_desktop_window(existing):
                message(
                    "TCG Shop Manager",
                    "전용 앱 창(WebView2)을 열지 못했습니다.\n"
                    "복구를 위해 이번 실행만 기본 브라우저로 엽니다.\n\n"
                    f"로그: {log_path()}",
                    True,
                )
                webbrowser.open(url_for(existing))
            return

        splash.step("이전 세션 정리", "이전 버전의 로컬 엔진을 안전하게 정리하고 있습니다.", 47)
        cleanup_results = cleanup_older_tcg_servers()
        if cleanup_results:
            write_log("Old server cleanup results: " + ", ".join(
                f"{p}=v{v}:{'stopped' if ok else 'still-running'}" for p, v, ok in cleanup_results
            ))

        splash.step("데이터 볼트 연결", "사용자 데이터와 전용 WebView2 프로필을 준비하고 있습니다.", 59)
        get_data_dir()
        desktop_profile_dir()
        port = find_free_port()
        if port is None:
            splash.close()
            message(
                "TCG Shop Manager 실행 실패",
                f"사용 가능한 로컬 포트를 찾지 못했습니다 ({PORT_FIRST}-{PORT_LAST}).\n로그: {log_path()}",
                True,
            )
            return

        shell_port = port
        splash.step("로컬 엔진 시작", f"FastAPI 운영 엔진을 127.0.0.1:{port}에서 시작합니다.", 71)
        proc = start_server(port)

        deadline = time.time() + 25.0
        ready = False
        while time.time() < deadline:
            elapsed = 25.0 - max(0.0, deadline - time.time())
            progress = min(91, 75 + int((elapsed / 25.0) * 16))
            splash.step("상태 확인", "재고 DB와 운영 화면의 준비 상태를 확인하고 있습니다.", progress)
            info = health_info(port, timeout=0.8)
            if is_tcg_server(info) and str(info.get("version")) == EXPECTED_VERSION:
                ready = True
                break
            if proc.poll() is not None:
                write_log(f"Server exited early with code {proc.returncode}")
                break
            time.sleep(0.22)

        if not ready:
            try:
                if proc.poll() is None:
                    proc.terminate()
            except Exception:
                pass
            splash.close()
            tail = launcher_log_tail()
            detail = (
                "프로그램 서버가 정상적으로 시작되지 않았습니다.\n\n"
                "새 ZIP을 별도 폴더에 완전히 압축 해제했는지 확인해주세요.\n\n"
                f"로그 위치:\n{log_path()}"
            )
            if tail:
                detail += "\n\n최근 오류:\n" + tail[-1600:]
            message("TCG Shop Manager 실행 실패", detail, True)
            return

        save_runtime(port, proc.pid)
        write_log(f"Server v{EXPECTED_VERSION} health PASS port={port}; preparing native desktop shell")
        splash.step("앱 창 준비", "Microsoft Edge WebView2 전용 창을 구성하고 있습니다.", 96)
        splash.finish("주소 표시줄 없는 TCG Shop Manager 창을 여는 중입니다.")

        if not open_desktop_window(port):
            message(
                "TCG Shop Manager",
                "전용 앱 창(WebView2)을 열지 못했습니다.\n"
                "복구를 위해 이번 실행만 기본 브라우저로 엽니다.\n\n"
                "Windows의 Microsoft Edge WebView2 Runtime 상태를 확인해주세요.\n"
                f"로그: {log_path()}",
                True,
            )
            webbrowser.open(url_for(port))
            # Browser fallback must leave the backend alive after launcher exits.
            shell_port = None
            return

    except Exception as exc:
        splash.close()
        write_log(f"Unhandled desktop launcher error: {exc!r}")
        message("TCG Shop Manager 실행 실패", f"{exc}\n\n로그 위치:\n{log_path()}", True)
    finally:
        splash.close()
        # Native shell closes its current backend via the window.closed event.
        # On startup/error before a native window exists, avoid leaving a backend behind.
        if shell_port is not None:
            # If the native window returned normally, this is idempotent.
            stop_tcg_server_on_port(shell_port)
        release_shell_mutex(mutex)


if __name__ == "__main__":
    main()
