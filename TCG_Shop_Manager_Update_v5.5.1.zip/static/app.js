function openModal(id){ document.getElementById(id)?.classList.add('open'); }
function closeModal(m){ m?.classList.remove('open'); }
document.querySelectorAll('[data-open]').forEach(b=>b.addEventListener('click',()=>openModal(b.dataset.open)));
document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>closeModal(b.closest('.modal'))));
document.querySelectorAll('.modal').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)closeModal(m)}));
document.addEventListener('keydown',e=>{if(e.key==='Escape')document.querySelectorAll('.modal.open').forEach(closeModal)});
function money(n){ return Math.round(Number(n||0)).toLocaleString('ko-KR')+'원'; }

document.querySelectorAll('[data-copy-target]').forEach(btn=>btn.addEventListener('click',async()=>{
  const el=document.getElementById(btn.dataset.copyTarget);
  if(!el)return;
  const text=(el.textContent||'').trim();
  try{
    await navigator.clipboard.writeText(text);
    const before=btn.textContent;
    btn.textContent='복사됨';
    setTimeout(()=>btn.textContent=before,1200);
  }catch(e){
    window.prompt('아래 내용을 복사해주세요.',text);
  }
}));


/* v5.5.1 — preserve work position on same-screen actions */
(() => {
  const KEY = 'tcgsm:scroll:' + location.pathname;

  function saveScroll() {
    try {
      sessionStorage.setItem(KEY, JSON.stringify({
        y: Math.max(0, window.scrollY || document.documentElement.scrollTop || 0),
        t: Date.now()
      }));
    } catch (_) {}
  }

  function shouldPreserveLink(a) {
    if (!a || !a.href) return false;
    try {
      const u = new URL(a.href, location.href);
      return u.origin === location.origin &&
             u.pathname === location.pathname &&
             (a.hasAttribute('data-preserve-scroll') || u.search !== location.search);
    } catch (_) {
      return false;
    }
  }

  document.addEventListener('click', (e) => {
    const a = e.target.closest('a');
    if (shouldPreserveLink(a)) saveScroll();
  }, true);

  document.addEventListener('submit', (e) => {
    const form = e.target;
    if (!(form instanceof HTMLFormElement)) return;
    let target;
    try { target = new URL(form.action || location.href, location.href); } catch (_) { return; }
    if (target.origin === location.origin &&
        target.pathname === location.pathname &&
        (form.hasAttribute('data-preserve-scroll') || form.method.toLowerCase() === 'post')) {
      saveScroll();
    }
  }, true);

  window.addEventListener('pagehide', () => {
    // Do not overwrite a just-saved same-page position when navigating to another screen.
    const active = document.activeElement;
    if (active && active.closest && active.closest('[data-preserve-scroll]')) saveScroll();
  });

  window.addEventListener('DOMContentLoaded', () => {
    let saved = null;
    try { saved = JSON.parse(sessionStorage.getItem(KEY) || 'null'); } catch (_) {}
    if (!saved || !Number.isFinite(saved.y) || Date.now() - saved.t > 30000) return;
    sessionStorage.removeItem(KEY);
    requestAnimationFrame(() => requestAnimationFrame(() => {
      window.scrollTo({ top: saved.y, left: 0, behavior: 'auto' });
    }));
  });
})();
