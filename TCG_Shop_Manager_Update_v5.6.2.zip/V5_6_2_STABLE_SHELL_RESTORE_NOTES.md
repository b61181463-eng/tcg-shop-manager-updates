# v5.6.2 Stable Shell Restore

Emergency stability release after real-Windows v5.6.0 Native Host testing.

The v5.6.0 experiment embedded a pywebview/WebView2 top-level window inside a second
Win32 host using SetParent. Real Windows testing showed degraded UX:
- visible lag/stutter
- softer/blurry rendering
- initial sizing/DPI inconsistencies

v5.6.2 removes the Native Host experiment and restores the proven v5.5.5 architecture:

launcher.pyw -> local FastAPI backend -> direct pywebview/WebView2 desktop window

Preserved:
- Gallery Navy UI
- Card Lab layout fixes
- dashboard click fix
- sidebar scroll persistence
- same-page scroll preservation
- Desktop Shell CWD isolation
- WinLock-safe updater
- single-instance behavior
- downloads and external-link handling
- all database/business logic

Removed:
- TCGShopManager.exe Native Host
- SetParent window embedding
- host/child DPI synchronization
- native wrapper resizing loop

Taskbar icon:
Rendering quality and responsiveness take priority. The taskbar icon issue is deferred
to the signed Store/MSIX/native packaging path rather than compromising the live UI.
